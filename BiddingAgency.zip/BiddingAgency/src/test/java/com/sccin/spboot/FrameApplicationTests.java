package com.sccin.spboot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.AntPathMatcher;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FrameApplicationTests {

	@Test
	public void contextLoads() {
		String checkUrl="/front/dist/layuiadmin/**";
		String reqUrl="/front/dist/layuiadmin/layui/css/layui.css";
		boolean flag=new AntPathMatcher("/").match(checkUrl,reqUrl);
		System.out.println(flag);
	}

}
