package com.sccin.spboot.domain.moren;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by ccs on 2018/8/27.
 */
@Entity
@Table(name = "etnlog")
public class Nlog {
    private String id;
    private Timestamp time;
    private Integer type;
    private String arg0;
    private String arg1;
    private String arg2;
    private String arg3;
    private String arg4;
    private String remark;
    private Integer isdel;

    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "ftime", nullable = true, insertable = true, updatable = true)
    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    @Basic
    @Column(name = "ftype", nullable = true, insertable = true, updatable = true)
    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Basic
    @Column(name = "farg0", nullable = true, insertable = true, updatable = true, length = 2048)
    public String getArg0() {
        return arg0;
    }

    public void setArg0(String arg0) {
        this.arg0 = arg0;
    }

    @Basic
    @Column(name = "farg1", nullable = true, insertable = true, updatable = true, length = 2048)
    public String getArg1() {
        return arg1;
    }

    public void setArg1(String arg1) {
        this.arg1 = arg1;
    }

    @Basic
    @Column(name = "farg2", nullable = true, insertable = true, updatable = true, length = 2048)
    public String getArg2() {
        return arg2;
    }

    public void setArg2(String arg2) {
        this.arg2 = arg2;
    }

    @Basic
    @Column(name = "farg3", nullable = true, insertable = true, updatable = true, length = 2048)
    public String getArg3() {
        return arg3;
    }

    public void setArg3(String arg3) {
        this.arg3 = arg3;
    }

    @Basic
    @Column(name = "farg4", nullable = true, insertable = true, updatable = true, length = 4000)
    public String getArg4() {
        return arg4;
    }

    public void setArg4(String arg4) {
        this.arg4 = arg4;
    }

    @Basic
    @Column(name = "fremark", nullable = true, insertable = true, updatable = true, length = 256)
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Basic
    @Column(name = "fisdel", nullable = true, insertable = true, updatable = true)
    public Integer getIsdel() {
        return isdel;
    }

    public void setIsdel(Integer isdel) {
        this.isdel = isdel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Nlog nlog = (Nlog) o;

        if (id != null ? !id.equals(nlog.id) : nlog.id != null) return false;
        if (time != null ? !time.equals(nlog.time) : nlog.time != null) return false;
        if (type != null ? !type.equals(nlog.type) : nlog.type != null) return false;
        if (arg0 != null ? !arg0.equals(nlog.arg0) : nlog.arg0 != null) return false;
        if (arg1 != null ? !arg1.equals(nlog.arg1) : nlog.arg1 != null) return false;
        if (arg2 != null ? !arg2.equals(nlog.arg2) : nlog.arg2 != null) return false;
        if (arg3 != null ? !arg3.equals(nlog.arg3) : nlog.arg3 != null) return false;
        if (arg4 != null ? !arg4.equals(nlog.arg4) : nlog.arg4 != null) return false;
        if (remark != null ? !remark.equals(nlog.remark) : nlog.remark != null) return false;
        if (isdel != null ? !isdel.equals(nlog.isdel) : nlog.isdel != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (time != null ? time.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (arg0 != null ? arg0.hashCode() : 0);
        result = 31 * result + (arg1 != null ? arg1.hashCode() : 0);
        result = 31 * result + (arg2 != null ? arg2.hashCode() : 0);
        result = 31 * result + (arg3 != null ? arg3.hashCode() : 0);
        result = 31 * result + (arg4 != null ? arg4.hashCode() : 0);
        result = 31 * result + (remark != null ? remark.hashCode() : 0);
        result = 31 * result + (isdel != null ? isdel.hashCode() : 0);
        return result;
    }
}
