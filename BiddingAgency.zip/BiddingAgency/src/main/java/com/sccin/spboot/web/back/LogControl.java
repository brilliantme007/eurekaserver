package com.sccin.spboot.web.back;

import com.sccin.spboot.domain.moren.Nlog;
import com.sccin.spboot.service.back.LogsService;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sccin.spboot.web.back.GlobalExcaptionHolder.PAGESIZE;

@Controller
@RequestMapping("/log")
public class LogControl {
    @Autowired
    private LogsService logsService;

    @RequestMapping(value = "/showLogs.html")
    public String showLogs(HttpServletRequest request, @PageableDefault(value = PAGESIZE,sort ={"time"}, direction = Sort.Direction.DESC) Pageable pageable,
            @Param("fmessage") String fmessage,Model model){
        //分页查询
        Page<Nlog> logsInfo = logsService.queryPageLogInfos(fmessage,pageable);

        model.addAttribute("page",pageable.getPageNumber() + 1);
        model.addAttribute("total",logsInfo.getTotalPages());
        model.addAttribute("logs",logsInfo.getContent());

        model.addAttribute("fmessage",fmessage);

        return "back/Log/logInfos";
    }

    @RequestMapping(value = "/detailLogs")
    public @ResponseBody
    AjaxReturnBean detailLogs(@Param("fid") String fid, Model model, HttpServletRequest request) {
        List<Map<String,String>> listLogs = new ArrayList<Map<String,String>>();
        String msg = "";
        boolean fidFlag = fid != null && !fid.trim().equals("");
        if (fidFlag) {
            Nlog logs = logsService.detailLog(fid);
            Map<String,String> mapLogs = new HashMap<String,String>();
            mapLogs.put("ftime", logs.getTime().toString().substring(0, logs.getTime().toString().lastIndexOf(".")));
            mapLogs.put("ftype", logs.getType()+"");
            mapLogs.put("farg0", logs.getArg0());
            mapLogs.put("farg1", logs.getArg1());
            mapLogs.put("farg2", logs.getArg2());
            mapLogs.put("farg3", logs.getArg3());
            mapLogs.put("fmessage", logs.getArg4());
            mapLogs.put("fdescribe", logs.getRemark());
            listLogs.add(mapLogs);
        } else {
            return AjaxReturnBean.createError("请求唯一标识传递失败", null);
        }
        return AjaxReturnBean.createSuccess("success",listLogs);
    }
    @RequestMapping(value = "/deleteLogsByFid")
    public @ResponseBody AjaxReturnBean  deleteLog(@Param("fid") String fid,Model model,HttpServletRequest request){

        boolean fidFlag = fid != null && !fid.trim().equals("");
        if(fidFlag){
            try {
                logsService.delectLogByFid(fid);
                return  AjaxReturnBean.createSuccess("删除日志成功",null);
            } catch (Exception e) {
                return  AjaxReturnBean.createError("删除日志失败", e.toString());
            }
        } else {
            return  AjaxReturnBean.createError("请求唯一标识传递失败", null);
        }

    }
}
