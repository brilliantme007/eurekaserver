package com.sccin.spboot.web.endpoint.interfaces;

import org.springframework.data.repository.query.Param;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

/**
 * 抽取招标代理相关服务
 * @author LiJunhao
 */
@WebService(name = "ProjectExtractService",
            targetNamespace = "http://interfaces.endpoint.web.spboot.sccin.com")
public interface ProjectExtractService {
    /**
     * 根据传入的XML字符串获取项目信息,并对该项目进行招标代理抽取
     * @param XMLStr 传入的XML字符串
     * @param judge 服务保留字段
     * @return 抽取结果
     */
    @WebMethod(operationName = "ExtractAgency")
    @WebResult(name = "result")
    String ExtractAgency(@WebParam(name = "XMLStr") String XMLStr, @WebParam(name = "judge") String judge);
}
