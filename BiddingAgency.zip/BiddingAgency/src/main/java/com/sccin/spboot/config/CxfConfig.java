package com.sccin.spboot.config;


import com.sccin.spboot.web.endpoint.interfaces.ProjectExtractService;
import com.sccin.spboot.web.endpoint.interfaces.SiteDataExchangeService;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import javax.xml.ws.Endpoint;

/**
 * 统一webservice启动入口
 */
@Configuration
public class CxfConfig {

    @Autowired
    private Bus bus;
    @Autowired
    private SiteDataExchangeService siteDataExchangeService;
    @Autowired
    private ProjectExtractService projectExtractService;

    //统一发布地址/pub/services/    如：    http://192.168.0.30:7777/pub/services/SiteDataExchangeService?wsdl
    private static final String WEBSERVICESPACE = "/pub/services/*";

    @Bean
    public ServletRegistrationBean servletRegistrationBean() {
        ServletRegistrationBean bean = new ServletRegistrationBean(new CXFServlet(), WEBSERVICESPACE);
        bean.setLoadOnStartup(0);
        bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return bean;
    }

    /**
     * 接受项目信息和开标信息的服务
     */
    @Bean
    public Endpoint SiteDataExchangeService() {
        EndpointImpl endpoint = new EndpointImpl(bus, siteDataExchangeService);
        endpoint.publish("/SiteDataExchangeService");
        return endpoint;
    }

    /**
     * 接受抽取招标代理的服务
     */
    @Bean
    public Endpoint projectExtractService() {
        EndpointImpl endpoint = new EndpointImpl(bus, projectExtractService);
        endpoint.publish("/ProjectExtractService");
        return endpoint;
    }

}
