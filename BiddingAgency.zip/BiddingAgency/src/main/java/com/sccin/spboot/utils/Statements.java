package com.sccin.spboot.utils;


import org.springframework.core.io.ClassPathResource;
import org.springframework.security.access.ConfigAttribute;
import org.w3c.dom.*;

import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by developer_hyaci on 2017/8/18.
 * 项目中常规性静态描述
 */
public class Statements {

    public static final String LOGINURL = "/login.html";
    public static final String SUCCESSURL = "/loginSuccessAjax.html";
    public static final String FAILURL = "/loginFailAjax.html";
    public static final String LOGOUTSUCCESSURL = "/loginOutAjax.html";
    public static final String INVALIDSESSIONURL = "/invalidSession.html";


    /**
     * 不需要登陆就可以访问的路径
     */
    public static final String[] ALLAUTHS = {"/", "/login.html", "/loginFailAjax.html", "/timeout.html", "/pub/**", "/default/**",
            "/**/ui/**", "/**/css/**", "/**/js/**", "/**/assets/**", "/**/skin/**", "/**/img/**", "/video/**", "/favicon.ico",
            "/fileInfo/lookFile/**", "/fileInfo/downloadFile/**", "/touchScreen/**", "/website/**", "/**/images/**",
            "/front/layuiadmin/**", INVALIDSESSIONURL, LOGOUTSUCCESSURL};

    //权限豁免地址列表()
    public static final List<String> IGNORURL = Arrays.asList("/","/login","/login.html","/ajaxError","/error.html", "/public/**");
    //需登录共有的权限列表
    public static final List<String> LOGINSHAREURLS = Arrays.asList("/loginSuccessAjax.html","/back.html","/loginbase.html","/webback.html","/loginOutAjax.html","/ajaxNoAuth");


    //权限数据url -> roleCodes
    public static final ConcurrentHashMap<String, Collection<ConfigAttribute>> requestMap = new ConcurrentHashMap<>();

    /**
     * 系统启动之后存放与系统中的RSA公私钥相关
     * 该一对公私钥主要用于前台与后台交互时敏感数据的加密
     * key  : modulus|public_exponent|publicKey|privateKey
     * value:模|公钥指数|公钥对象|私钥对象
     * rule :模与公钥指数可以生成公钥对象,加密与解密使用的都是钥对象；
     * 维护机制：项目启动的时候就会生成此信息,每次启动生成的值不一样；
     */
    public static HashMap<String, Object> rsaPairs = new HashMap<>();

    public static String getRSAModulus() {
        if (!rsaPairs.isEmpty() && rsaPairs.get("modulus") != null) {
            return rsaPairs.get("modulus").toString();
        }
        return null;
    }

    public static String getRSAPubExponent() {
        if (!rsaPairs.isEmpty() && rsaPairs.get("public_exponent") != null) {
            return rsaPairs.get("public_exponent").toString();
        }
        return null;
    }

    public static RSAPublicKey getRSAPubKey() {
        if (!rsaPairs.isEmpty() && rsaPairs.get("publicKey") != null) {
            return (RSAPublicKey) rsaPairs.get("publicKey");
        }
        return null;
    }

    public static RSAPrivateKey getRSAPrivateKey() {
        if (!rsaPairs.isEmpty() && rsaPairs.get("privateKey") != null) {
            return (RSAPrivateKey) rsaPairs.get("privateKey");
        }
        return null;
    }

    /**
     * 用户维护当前在线的用户；
     * 0.当登陆成功则在线，但用户失效却存在3种方式
     * 1.登出时，需要将用户的登陆状态置为登出
     * 2.用户没有主动登出，session已失效，以失效session发起请求，也需要将用户的登陆状态置为登出
     * 3.用户没有主动登出，不论session失效未失效，用户都没有再发起请求，此时也需要将用户的登陆状态置为登出
     * 4.应用程序不管合理以及不合理的宕机，此时用户的状态状态也要设置为登出；
     * 第1点以及第2点可以通过session过期进行处理；
     * 第3点必须实时监听当前登陆用户是否已经不在线，监听到不在线时强制session过期
     * 第4点只能默认宕机之后所有在线用户都登出
     * rule:对应0，需要往loginSessionMap中写入当前用户对应的session对象以及操作的时间；
     * 对应1，loginSessionMap需要剔除掉登陆时已写入相关；
     * 对应2，loginSessionMap需要剔除掉登陆时已写入相关；
     * 对应3，需要在DefineGlobalFilter中更新当前登陆用户最新操作时间,并通过轮询任务剔除
     * 对应4，loginSessionMap自动会销毁，如果有实际维护登陆状态的字段，需要在应用启动之初重置为未登陆；
     * key:用户ID,
     * value:key:session;value:session对象；key:time;value:最新访问时间；
     */
    public static HashMap<String, HashMap<String, Object>> loginSessionMap = new HashMap<>();

    public static void addLoginSessionMap(String userId, HttpSession sesssion) {
        HashMap item = new HashMap<String, Object>();
        item.put("session", sesssion);
        item.put("time", LocalDateTime.now());
        loginSessionMap.put(userId, item);
    }

    public static void upLoginSessionMap(String userId) {
        if (loginSessionMap.containsKey(userId)) {
            loginSessionMap.get(userId).put("time", LocalDateTime.now());
        }
    }

    public static void removeLoginSessionMap(String userId) {
        if (loginSessionMap.containsKey(userId)) {
            loginSessionMap.remove(userId);
        }
    }

    public static LocalDateTime getLoginSessionMapTime(String userId) {
        if (loginSessionMap.containsKey(userId)) {
            return (LocalDateTime) loginSessionMap.get(userId).get("time");
        }
        return null;
    }

    public static HttpSession getLoginSessionMapSession(String userId) {
        if (loginSessionMap.containsKey(userId)) {
            return (HttpSession) loginSessionMap.get(userId).get("session");
        }
        return null;
    }

    /**
     * 缓存menu主体XML结构
     * map->
     * key:menuCode(即元素name)  value:对应的menu主体 map->
     * key:label , name , xml , category->List(Map) -> map
     * key: name ,label ,field
     */
    public static final List<HashMap<String, Object>> menusMap = new ArrayList<>();
    /**
     * 缓存menu主体的所有分类
     * key:menuCode value:list<map>
     * map->key:name、label、typeNo、type、nature
     */
    public static final HashMap<String, List<Map<String, String>>> categorysMap = new HashMap<>();

    /**
     * 根据menuCode获取栏目类型列表（当栏目只有一个default类型时，label返回栏目名称而不是类型名称）
     * map->
     * key:name(类型code)、label(名称)
     *
     * @param menuCode
     * @return
     */
    public static List<Map<String, Object>> getCategorysByMenuCode(String menuCode) {
        List<Map<String, Object>> list = new ArrayList<>();
        for (HashMap map : menusMap) {
            if (map.get("name").equals(menuCode)) {
                List<Map<String, Object>> categorys = (List<Map<String, Object>>) map.get("category");
                for (Map<String, Object> cate : categorys) {
                    Map<String, Object> obj = new HashMap<>();
                    String name = cate.get("name").toString();
                    String label;
                    if (categorys.size() == 1 && "DEFAULT".equals(categorys.get(0).get("name"))) {
                        label = map.get("label").toString();
                    } else {
                        label = cate.get("label").toString();
                    }
                    if (name.contains("_")) {
                        name = name.substring(0, name.indexOf("_")); //父类型code
                        label = cate.get("preLabel").toString();    //父类型名
                    }
                    obj.put("name", name);
                    obj.put("label", label);
                    if (!list.contains(obj)) {
                        list.add(obj);
                    }
                }
            }
        }
        return list;
    }

    /**
     * 缓存页面需要显示的数据结构
     * key:areacode(默认default),value:Map(key:menumcode_typecode(即栏目code_内容类型) value:对应的内容需要显示的信息List)
     */
    public static Map<String, Map<String, List<Map<String, Object>>>> homePageDatas = new HashMap<>();
    /**
     * 缓存每个内容的一段时间类的阅读次数
     * key:fid(该内容的fid) value:这段时间的浏览次数
     */
    public static Map<String, Integer> readViews = new HashMap<>();

    /**
     * 缓存每年的统计数据
     * key:年份(2018) value:map(key:menumcode,value:项目数)
     */
    public static Map<String, Map<String, Integer>> tradeData = new HashMap<>();

    /**
     * 查询码计数器
     */
    public static Integer feedBackNum = 1;

    /**
     * 缓存保证金退还数据
     */
    public static List<Map<String, Object>> depositRefundInfo = new ArrayList<>();

    /**
     * 用于查询库级别信息时，通过判断输入查询条件来判断状态
     * 状态code说明：
     * 1：库级别名称和库级别数都不没有输入
     * 2：库级别名称和库级别数都有输入
     * 3：输入了库级别名称，没有输入库级别数
     * 4：输入了库级别数，没有输入库级别名称
     * 使用：Statements.STATMAP.put("flage", 1);
     */
    public static Map<String, Integer> STATMAP = new HashMap<>();


    public static final Map<String, Map<String, String>> STOP_WATCH_MAP;
    public static final List<Map<String, Object>> PROJECT_MAP;

    static {
        //初始化project.xml
        StringBuilder sb = new StringBuilder();
        try (InputStream is = new ClassPathResource("project.xml").getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            while (br.ready()) {
                sb.append(br.readLine());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        PROJECT_MAP = Collections.unmodifiableList(getProject(sb));

        //初始化stopWatch.xml
        StringBuilder sb2 = new StringBuilder();
        try (InputStream is = new ClassPathResource("stopWatch.xml").getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            while (br.ready()) {
                sb2.append(br.readLine());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        STOP_WATCH_MAP = Collections.unmodifiableMap(getStopWatch(sb2));
    }


    /**
     * 解析项目xml字符串，将其中每一个域转化为List
     * List<Map> -> map:
     * key:name, attr -> List<Map> ->map:
     * key:label, type, reffered, isrequired, value
     *
     * @param xmlString 项目xml字符串
     * @return 项目元素下的每一个域的集合
     * @author lijun
     */
    public static List<Map<String, Object>> getProject(StringBuilder xmlString) {
        String xml;
        //过滤注释
        int offset = 0;
        while ((offset = xmlString.indexOf("<!--", offset)) != -1) {
            int end = xmlString.indexOf("-->", offset) + 3;
            xmlString.replace(offset, end, "");
            offset = 0;
        }
        //过滤换行、空格
        xml = xmlString.toString().replaceAll("\\n", "").replaceAll(">\\s+<", "><");
        xml = xml.trim();
        Document document = XMLUtil.queryStringXml(xml);

        List<Map<String, Object>> result = new ArrayList<>();
        //project元素
        NodeList nodeList = document.getElementsByTagName("project");
        for (int i = 0; i < nodeList.getLength(); i++) {
            if (nodeList.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element nodeElement = (Element) nodeList.item(i);
                NodeList childNodesList = nodeElement.getChildNodes();
                for (int j = 0; j < childNodesList.getLength(); j++) {
                    if (childNodesList.item(j).getNodeType() == Node.ELEMENT_NODE) {
                        Element childNodes = (Element) childNodesList.item(j);
                        //子元素name和属性集合
                        Map<String, Object> attrs = new HashMap<>();
                        NamedNodeMap attributeMap = childNodes.getAttributes();
                        //子元素属性集合Map
                        Map<String, Object> attr = new HashMap<>();
                        for (int attributeLength = 0; attributeLength < attributeMap.getLength(); attributeLength++) {
                            Node node = attributeMap.item(attributeLength);
                            attr.put(node.getNodeName(), node.getNodeValue());
                        }
                        attrs.put("name", childNodes.getTagName());
                        attrs.put("attr", attr);
                        result.add(attrs);
                    }
                }
            }
        }

        return result;
    }

    /**
     * 解析stopWatch字符串，将其转化为Map
     *
     * @param xmlString stopWatch字符串
     * @return Map
     * @author lijun
     */
    public static Map<String, Map<String, String>> getStopWatch(StringBuilder xmlString) {
        String xml;
        //过滤注释
        int offset = 0;
        while ((offset = xmlString.indexOf("<!--", offset)) != -1) {
            int end = xmlString.indexOf("-->", offset) + 3;
            xmlString.replace(offset, end, "");
            offset = 0;
        }
        //过滤换行、空格
        xml = xmlString.toString().replaceAll("\\n", "").replaceAll(">\\s+<", "><");
        Document document = XMLUtil.queryStringXml(xml);

        Map<String, Map<String, String>> result = new HashMap<>();
        //stopWatch元素
        Element first = (Element) document.getElementsByTagName("stopWatch").item(0);
        NodeList firstChilds = first.getChildNodes();
        for (int j = 0; j < firstChilds.getLength(); j++) {
            if (firstChilds.item(j).getNodeType() == Node.ELEMENT_NODE) {
                //各个码表元素
                Element second = (Element) firstChilds.item(j);
                Map<String, String> type = new HashMap<>();
                NodeList secondChilds = second.getChildNodes();
                for (int k = 0; k < secondChilds.getLength(); k++) {
                    if (secondChilds.item(k).getNodeType() == Node.ELEMENT_NODE) {
                        //码表各个filed元素
                        Element third = (Element) secondChilds.item(k);
                        /* 设置value-label键值对 */
                        String value = third.getAttribute("value");
                        String label = third.getAttribute("label");
                        type.put(value, label);
                    }
                }
                //将码表元素的tag和type作为result的键值对
                result.put(second.getTagName(), type);
            }
        }

        return result;
    }

    /**
     * 以PROJECT_MAP为模板将params中指定域（按name）的value保存成xml字符串
     *
     * @param params 参数集合
     * @return xml字符串
     * @author lijun
     */
    public static StringBuilder projectToXml(Map<String, String> params) {
        StringBuilder result = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        result.append("<project>\n");
        for (Map<String, Object> item : PROJECT_MAP) {
            result.append("<").append(item.get("name"));
            for (Map.Entry<String, Object> entry : ((Map<String, Object>) item.get("attr")).entrySet()) {
                String value;
                result.append(" ");
                if ("value".equals(entry.getKey()) && !StringUtil.isEmpty(params.get(item.get("name")))) {
                    value = params.get(item.get("name"));
                } else {
                    value = (String) entry.getValue();
                }
                result.append(" ").append(entry.getKey()).append("=\"").append(value).append("\"");
            }
            result.append("/>\n");
        }
        result.append("</project>");

        return result;
    }
}
