package com.sccin.spboot.web.back;

import com.sccin.spboot.config.SysConfig;
import com.sccin.spboot.security.config.LoginOtherCheackFilter;
import com.sccin.spboot.security.pojo.DefineAuthItem;
import com.sccin.spboot.security.pojo.SecurityUser;
import com.sccin.spboot.service.back.UserService;
import com.sccin.spboot.utils.StringUtil;
import com.sccin.spboot.utils.VerifyCodeUtils;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * Created by CPYF-Yi Mao on 2018-08-28.
 */
@Controller
public class BackHtmlControl {

    private static Logger logger = LoggerFactory.getLogger(BackHtmlControl.class);

    @Autowired
    private SysConfig sysConfig;

    @RequestMapping("/")
    public String home(HttpServletRequest request) {
        SecurityUser securityUser = UserService.getSecurityUserFromSession(request);
        if(securityUser != null){
            Collection<? extends GrantedAuthority> authorities = securityUser.getAuthorities();
            if(authorities.size() == 1 && ((GrantedAuthority)authorities.toArray()[0]).getAuthority().equals("admin")) {
                return "redirect:/back.html?"+System.currentTimeMillis();
            }
            return "redirect:/webback.html?"+System.currentTimeMillis();
        }
        return "front/views/user/login";
    }


    @RequestMapping("/loginagency.html")
    public String agency(HttpServletRequest request) {

        return "front/views/app/agency-repository/agency-repository";
    }


    @RequestMapping("/loginbase.html")
    public String loginbase(HttpServletRequest request) {

        return "front/views/home/console";
    }


    @RequestMapping("/loginagencyedit.html")
    public String loginagencyedit(HttpServletRequest request) {

        return "front/views/app/agency-repository/listform";
    }

    @RequestMapping("/agencyImport.html")
    public String loginagencyimport() {
        return "front/views/app/agency-repository/agency-import";
    }


    @RequestMapping(value = {"/back.html"})
    public String backIndex(HttpServletRequest request) {
        //访问后台管理页面
        //从当前登陆用户的权限中获取后台的权限
        SecurityUser securityUser = UserService.getSecurityUserFromSession(request);
        List<DefineAuthItem> backAuth = new ArrayList<>();
        if (securityUser != null) {
            List<DefineAuthItem> allAuths = securityUser.getAuthsTree();
            for (DefineAuthItem authItem : allAuths) {
                //url 为0，type为表示后台顶级菜单
                if (authItem.getAuthorityBean().getUrl().equals("0") &&
                        authItem.getAuthorityBean().getType().intValue() == 1) {
                    backAuth.add(authItem);
                }
            }
        }
        request.getSession().setAttribute("uathsBack", backAuth);

        return "back/home";
    }

    @RequestMapping(value = {"/login.html"})
    public String index() {
        return "front/views/user/login";
    }

    @RequestMapping(value = {"/loginSuccess.html"})
    public String loginSuccess(HttpServletRequest request) {
        SecurityUser securityUser = UserService.getSecurityUserFromSession(request);
        if (securityUser != null) {
            Collection<? extends GrantedAuthority> authorities = securityUser.getAuthorities();
            if (authorities.size() == 1 && ((GrantedAuthority) authorities.toArray()[0]).getAuthority().equals("admin")) {
                return "redirect:/back.html?" + System.currentTimeMillis();
            }
            return "redirect:/webback.html?" + System.currentTimeMillis();
        }
        return "redirect:/login.html";
    }

    @RequestMapping(value={"/loginSuccessAjax.html"},method = RequestMethod.GET)
    @ResponseBody
    public Map<String,Object> loginSuccessAjax(HttpServletRequest request) {
        request.getMethod();
        Map<String,Object> jsonMap=new HashMap<>();
        jsonMap.put("code",0);
        jsonMap.put("msg","登陆成功");
        jsonMap.put("data",null);
        return jsonMap;
    }


    @RequestMapping(value={"/loginOutAjax.html"},method = RequestMethod.GET)
    @ResponseBody
    public Map<String,Object> loginOutAjax(HttpServletRequest request) {
        request.getMethod();
        Map<String,Object> jsonMap=new HashMap<>();
        jsonMap.put("code",0);
        jsonMap.put("msg","退出成功");
        jsonMap.put("data",null);
        return jsonMap;
    }




    @RequestMapping(value={"/loginFail.html"})
    public String loginFail() {
        return "back/login";
    }


    @RequestMapping(value={"/loginFailAjax.html"},method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> loginFailAjax(HttpServletRequest request) {
/*        Map<String,Object> iteMap=new HashMap<>();
        iteMap.put("access_token","111112222211");*/
        Map<String,Object> jsonMap=new HashMap<>();
        jsonMap.put("code",1);
        jsonMap.put("msg",request.getAttribute("error"));
        jsonMap.put("data",null);
        return jsonMap;
    }


    @RequestMapping(value={"/invalidSession.html"})
    public String invalidSession(HttpServletRequest request,HttpServletResponse response) {
        request.setAttribute("errMsg","当前登陆会话已失效");
        if(request.getHeader("X-Requested-With") != null){  //ajax请求
            response.setHeader("REDIRECT", request.getContextPath()+"/");
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            return "forward:/ajaxError";
        }else{
            return "forward:/error.html";
        }
    }

    @RequestMapping("/ajaxError")
    @ResponseBody
    public AjaxReturnBean ajaxError(HttpServletRequest request) {
        return AjaxReturnBean.createError(StringUtil.getString(request.getAttribute("errMsg")));
    }

    @RequestMapping("/error.html")
    public String error(HttpServletRequest request, HttpServletResponse response, Model model) {
        model.addAttribute("errMsg", request.getAttribute("errMsg"));
        model.addAttribute("status", response.getStatus());
        return "error";
    }

    @RequestMapping("/timeout.html")
    public String timeout(Model model) {
        model.addAttribute("turnToHomePageUrl", sysConfig.getTurnToHomePageUrl());
        return "front/views/user/login";
    }

    @RequestMapping(value = "/pub/authVerifyCode", method = RequestMethod.GET)
    public void buildVerifyCode(HttpServletRequest request,HttpServletResponse response) {
        response.setHeader("Pragma", "No-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0);
        response.setContentType("image/jpeg");

        // 生成随机字串
        String verifyCode = VerifyCodeUtils.generateVerifyCode(4);
        // 存入会话session
        HttpSession session = request.getSession(true);
        // 删除以前的
        session.removeAttribute(LoginOtherCheackFilter.VERCODE);
        session.setAttribute(LoginOtherCheackFilter.VERCODE, verifyCode.toLowerCase());
        // 生成图片
        int w = 100, h = 30;
        try {
            VerifyCodeUtils.outputImage(w, h, response.getOutputStream(),
                    verifyCode);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            logger.error("验证码生成异常",e);
        }
    }

    /**
    * 验证前台页面输入的验证码是否正确
    *
    * @param  verCode        //前台页面验证码
    * @return
    * @author ccs
    * @time  2018.12.28. 10:56
    */
    @RequestMapping(value = "/pub/verCodeCheck", method = RequestMethod.POST)
    @ResponseBody
    public AjaxReturnBean verCodeCheck(HttpServletRequest request, @Param("verCode") String verCode) {
        String msgErr = "";
        boolean flag = true;
        if (verCode == null || verCode.equals("") || request.getSession().getAttribute
                (LoginOtherCheackFilter.VERCODE) == null) {
            msgErr = "未能获取到验证码";
            flag = false;
        } else {
            if (!request.getSession().getAttribute(LoginOtherCheackFilter.VERCODE).toString().equalsIgnoreCase
                    (verCode.trim().toLowerCase())) {
                msgErr = "验证码不匹配";
                flag = false;
            }
        }
        if (flag) {
            return AjaxReturnBean.createSuccess(msgErr);
        } else {
            return AjaxReturnBean.createError(msgErr);
        }
    }

}
