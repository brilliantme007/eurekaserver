package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etprojinfo;
import com.sccin.spboot.domain.agency.specific.ProjectDao;
import com.sccin.spboot.utils.SqlUtils;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.StringUtil;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.*;

/**
 * 项目信息Dao接口实现
 *
 * @Author lijun
 */
public class EtprojinfoInterImpl implements ProjectDao {
    /**
     * EntityManager
     */
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Page<Map<String, Object>> pageBy(int page, int limit, String projectName, String bidType) {
        String countSelectSql = "SELECT COUNT(*)";
        String selectSql = "SELECT t1.fid, t1.fprojname," +
                " CASE WHEN t2.fid IS NULL THEN '否' ELSE '是' END isExtracted," +
                " extractvalue(t1.fmkeys, '/project/bidType/@value') bidType";

        StringBuilder fromSql = new StringBuilder(" FROM etprojinfo t1 LEFT JOIN rnprojagency t2 ON" +
                " t1.fid = t2.rprojinfoid WHERE 1=1");
        Map<String, Object> params = new HashMap<>();
        if (!StringUtil.isEmpty(projectName)) {
            fromSql.append(" AND fprojname LIKE :projectName");
            params.put("projectName", "%" + projectName + "%");
        }
        if (!StringUtil.isEmpty(bidType) && !"all".equals(bidType)) {
            fromSql.append("  AND extractvalue(t1.fmkeys, '/project/bidType/@value') = :bidType");
            params.put("bidType", bidType);
        }

        String countSql = countSelectSql + fromSql;
        Query countQuery = entityManager.createNativeQuery(countSql);
        SqlUtils.setParameters(params, countQuery);
        Long count = ((BigInteger) countQuery.getSingleResult()).longValue();

        List<Map<String, Object>> list;
        if (count > 0) {
            //排序
            fromSql.append(" ORDER BY futime DESC, fctime DESC");

            String querySql = selectSql + fromSql;
            Query query = this.entityManager.createNativeQuery(querySql);
            SqlUtils.setParameters(params, query);

            //分页
            query.setFirstResult(page * limit);
            query.setMaxResults(limit);
            List tempList = query.getResultList();

            list = new ArrayList<>();
            for (Object o : tempList) {
                Object[] item = (Object[]) o;
                Map<String, Object> project = new HashMap<>();
                project.put("fid", item[0]);
                project.put("fprojname", item[1]);
                project.put("isExtracted", item[2]);
                String bidType2;
                if (StringUtil.isEmpty(item[3])) {
                    bidType2 = null;
                } else {
                    bidType2 = Statements.STOP_WATCH_MAP.get("bidType").get(item[3]);
                }
                project.put("bidType", bidType2);

                list.add(project);
            }
        } else {
            list = Collections.EMPTY_LIST;
        }

        return new PageImpl<>(list, PageRequest.of(page, limit), count);
    }
}
