package com.sccin.spboot.domain.agency;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "rnprojagency")
public class Rnprojagency {
    private String fid;
    private String ragencyid;
    private String rprojinfoid;

    @Id
    @Column(name = "fid")
    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    @Basic
    @Column(name = "ragencyid")
    public String getRagencyid() {
        return ragencyid;
    }

    public void setRagencyid(String ragencyid) {
        this.ragencyid = ragencyid;
    }

    @Basic
    @Column(name = "rprojinfoid")
    public String getRprojinfoid() {
        return rprojinfoid;
    }

    public void setRprojinfoid(String rprojinfoid) {
        this.rprojinfoid = rprojinfoid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rnprojagency that = (Rnprojagency) o;
        return Objects.equals(fid, that.fid) &&
                Objects.equals(ragencyid, that.ragencyid) &&
                Objects.equals(rprojinfoid, that.rprojinfoid);
    }

    @Override
    public int hashCode() {

        return Objects.hash(fid, ragencyid, rprojinfoid);
    }
}
