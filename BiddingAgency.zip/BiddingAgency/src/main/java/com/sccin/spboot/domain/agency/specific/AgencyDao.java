package com.sccin.spboot.domain.agency.specific;

import com.sccin.spboot.domain.agency.Etagency;

import java.util.List;
import java.util.Map;

/**
 * Created by yx on 2018/12/27.
 */
public interface AgencyDao {

    List<Etagency> queryAgencyByCondition(Map<String, Object> param);

    int countAgencyByCondition(Map<String, Object> param);

    /**
     * 插入数据
     *
     * @param param
     */
    void insertAgencyByParam(Map<String, Object> param);


    /**
     * 查询需要抽取的代理信息,只查询了正常情况下的招标代理
     *
     * @param
     * @return java.util.List<com.sccin.spboot.domain.agency.Etagency>
     * @author WHLiang
     * @date 2018-12-27 14:30
     */
    List<Etagency> getEtagencysNeedExtract();
}
