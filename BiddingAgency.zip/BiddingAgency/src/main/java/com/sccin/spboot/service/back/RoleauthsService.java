package com.sccin.spboot.service.back;

import com.sccin.spboot.domain.moren.Roleauths;
import com.sccin.spboot.domain.moren.repository.RoleauthsReposityInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component("roleauthsService")
public class RoleauthsService {
    private RoleauthsReposityInter roleauthsReposityInter;

    @Autowired
    public RoleauthsService(RoleauthsReposityInter roleauthsReposityInter){
        this.roleauthsReposityInter = roleauthsReposityInter;
    }

    /**
     * 保存权限
     * @param roleId
     * @param roleCode
     * @param auths
     */
    @Transactional
    public void modifyRoleAuths(String roleId,String roleCode,String[] auths){
        //根据角色唯一标识将该角色已经设置好的权限取出
        List<Roleauths> lstAuths = this.roleauthsReposityInter.findByRoleid(roleId);
        //删除权限后重新设置
        if(lstAuths!=null && lstAuths.size()>0){
            roleauthsReposityInter.deleteAll(lstAuths);
        }
        //重新设置权限
        if(auths!=null&&auths.length>0){
            List<Roleauths> roleauthsList = new ArrayList<>();
            Roleauths roleauths = null;
            for(String s:auths){
                roleauths = new Roleauths();
                roleauths.setId(UUID.randomUUID().toString());
                roleauths.setRoleid(roleId);
                roleauths.setRolecode(roleCode);
                roleauths.setAuthorityid(s);
                roleauthsList.add(roleauths);
            }
            if(roleauthsList.size()>0){
                roleauthsReposityInter.saveAll(roleauthsList);
            }
        }
    }
    /**
     * 根据角色id获取角色权限
     * @param roleId
     * @return
     */
    public List<Roleauths> findByRoleId(String roleId){
        if(roleId==null||roleId.trim().equals("")){
            return new ArrayList<>();
        }else{
            return roleauthsReposityInter.findByRoleid(roleId);
        }
    }
}
