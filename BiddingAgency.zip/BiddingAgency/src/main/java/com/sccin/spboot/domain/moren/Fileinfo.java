package com.sccin.spboot.domain.moren;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "etfileinfo")
public class Fileinfo {
    private String id;
    private String name;
    private String storename;
    private String suffix;
    private String storeplace;
    private Timestamp time;

    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "fname", nullable = true, insertable = true, updatable = true, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "fstorename", nullable = true, insertable = true, updatable = true, length = 50)
    public String getStorename() {
        return storename;
    }

    public void setStorename(String storename) {
        this.storename = storename;
    }

    @Basic
    @Column(name = "fsuffix", nullable = true, insertable = true, updatable = true, length = 50)
    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    @Basic
    @Column(name = "fstoreplace", nullable = true, insertable = true, updatable = true, length = 256)
    public String getStoreplace() {
        return storeplace;
    }

    public void setStoreplace(String storeplace) {
        this.storeplace = storeplace;
    }

    @Basic
    @Column(name = "ftime", nullable = true, insertable = true, updatable = true)
    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Fileinfo fileinfo = (Fileinfo) o;

        if (id != null ? !id.equals(fileinfo.id) : fileinfo.id != null) return false;
        if (name != null ? !name.equals(fileinfo.name) : fileinfo.name != null) return false;
        if (storename != null ? !storename.equals(fileinfo.storename) : fileinfo.storename != null) return false;
        if (suffix != null ? !suffix.equals(fileinfo.suffix) : fileinfo.suffix != null) return false;
        if (storeplace != null ? !storeplace.equals(fileinfo.storeplace) : fileinfo.storeplace != null) return false;
        if (time != null ? !time.equals(fileinfo.time) : fileinfo.time != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (storename != null ? storename.hashCode() : 0);
        result = 31 * result + (suffix != null ? suffix.hashCode() : 0);
        result = 31 * result + (storeplace != null ? storeplace.hashCode() : 0);
        result = 31 * result + (time != null ? time.hashCode() : 0);
        return result;
    }
}
