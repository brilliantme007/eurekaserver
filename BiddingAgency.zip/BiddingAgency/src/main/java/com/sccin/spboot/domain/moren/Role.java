package com.sccin.spboot.domain.moren;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * Created by CPYF-Yi Mao on 2018-08-27.
 */
@Entity
@Table(name = "etrole")
public class Role {
    private String id;
    private String name;
    private String code;
    private Timestamp time;

    @Id
    @Column(name = "fid", nullable = false, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "fname", nullable = true, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "fcode", nullable = true, length = 50)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Basic
    @Column(name = "ftime", nullable = true)
    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Role role = (Role) o;
        return Objects.equals(id, role.id) &&
                Objects.equals(name, role.name) &&
                Objects.equals(code, role.code) &&
                Objects.equals(time, role.time);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, code, time);
    }
}
