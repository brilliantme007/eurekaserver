package com.sccin.spboot.domain.agency;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "etextracting")
public class Etextracting {
    private String fid;
    private Integer fstep;
    private Timestamp ftime;
    private String rprojid;
    private String fmark;
    private String ftempgroup;
    private String flevel;

    @Id
    @Column(name = "fid")
    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    @Basic
    @Column(name = "fstep")
    public Integer getFstep() {
        return fstep;
    }

    public void setFstep(Integer fstep) {
        this.fstep = fstep;
    }

    @Basic
    @Column(name = "ftime")
    public Timestamp getFtime() {
        return ftime;
    }

    public void setFtime(Timestamp ftime) {
        this.ftime = ftime;
    }

    @Basic
    @Column(name = "rprojid")
    public String getRprojid() {
        return rprojid;
    }

    public void setRprojid(String rprojid) {
        this.rprojid = rprojid;
    }

    @Basic
    @Column(name = "fmark")
    public String getFmark() {
        return fmark;
    }

    public void setFmark(String fmark) {
        this.fmark = fmark;
    }

    @Basic
    @Column(name = "ftempgroup")
    public String getFtempgroup() {
        return ftempgroup;
    }

    public void setFtempgroup(String ftempgroup) {
        this.ftempgroup = ftempgroup;
    }

    @Basic
    @Column(name = "flevel")
    public String getFlevel() {
        return flevel;
    }

    public void setFlevel(String flevel) {
        this.flevel = flevel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Etextracting that = (Etextracting) o;
        return Objects.equals(fid, that.fid) &&
                Objects.equals(fstep, that.fstep) &&
                Objects.equals(ftime, that.ftime) &&
                Objects.equals(rprojid, that.rprojid) &&
                Objects.equals(fmark, that.fmark) &&
                Objects.equals(ftempgroup, that.ftempgroup) &&
                Objects.equals(flevel, that.flevel);
    }

    @Override
    public int hashCode() {

        return Objects.hash(fid, fstep, ftime, rprojid, fmark, ftempgroup, flevel);
    }
}
