package com.sccin.spboot.section;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sccin.spboot.domain.moren.RepushAgain;
import com.sccin.spboot.domain.moren.repository.RepushAgainReposityInter;
import com.sccin.spboot.section.pojo.RemoteAccessResultDto;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Created by jun.li on 2018/4/26.
 */
@Aspect
public class RemoteAccessAscpet {
    @Autowired
    private RepushAgainReposityInter repushAgainReposityInter;

    @Pointcut("execution(* com.sccin.spboot.service.RemoteAccessService.*(..))")
    public void failure() {}

    @Around("failure()")
    public RemoteAccessResultDto aroundFailure(ProceedingJoinPoint pjp) throws Throwable{
        RemoteAccessResultDto o = (RemoteAccessResultDto)pjp.proceed();

        if (!o.getState()) {
            Object[] args = pjp.getArgs();

            RepushAgain repushAgain = new RepushAgain();

            repushAgain.setId(UUID.randomUUID().toString());
            repushAgain.setDomain(o.getDomain());
            repushAgain.setDescribe(o.getMessage());
            repushAgain.setCreatime(new Timestamp(System.currentTimeMillis()));

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonArgs = objectMapper.writeValueAsString(args);
            repushAgain.setParams(jsonArgs);

            Signature s = pjp.getSignature();
            MethodSignature ms = (MethodSignature)s;
            Class[] paramTypes = ms.getParameterTypes();
            String jsonParamTypes = objectMapper.writeValueAsString(paramTypes);
            repushAgain.setParamTypes(jsonParamTypes);

            repushAgain.setMethod(ms.getName());

            repushAgainReposityInter.saveAndFlush(repushAgain);
        }
        return o;
    }
}
