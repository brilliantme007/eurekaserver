package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etagencylevel;
import com.sccin.spboot.domain.agency.specific.EtagencylevelDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author MeiYF 2018/12/27 8:29
 **/
public class AgencyLevelReposityInterImpl implements EtagencylevelDao {

    /**
     * PersistenceContext
     */
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 查询库级别信息
     *
     * @param page 当前页面需要跳转到的第几页
     * @param limit 每页显示多少条
     * @param fname 库级别名称
     * @param flevel 库级别数
     * @return 返回
     */
    @Override
    public Map<String, Object> selectAgencylevelMess(int page, int limit, String fname, String flevel) {
        //拼接sql
        StringBuilder sb = new StringBuilder();
        sb.append(" SELECT fid,fname,flevel from etagencylevel ");
        if ((fname != null && !"".equals(fname)) || (flevel != null && !"".equals(flevel))) {
            sb.append("where ");
            if (fname != null && !"".equals(fname)) {
                sb.append(" fname like:fname ");
            }
            if ((fname != null && !"".equals(fname)) && (flevel != null && !"".equals(flevel))) {
                sb.append(" and flevel  = :flevel ");
            }
            if ((fname == null || "".equals(fname)) && (flevel != null && !"".equals(flevel))) {
                sb.append(" flevel  = :flevel ");
            }
        }
        sb.append(" ORDER BY flevel ");
        Query query = entityManager.createNativeQuery(sb.toString());
        //赋值
        if ((fname != null && !"".equals(fname))) {
            query.setParameter("fname", "%" + fname + "%");
        }
        if ((flevel != null && !"".equals(flevel))) {
            query.setParameter("flevel", flevel);
        }
        //查询
        List<Object[]> objs = query.getResultList();
        List<Etagencylevel> etAgencyLevelList = new ArrayList<>();
        //总条数
        int total = 0;
        if (objs != null) {
            total = objs.size();
            if (objs.size() != 0) {
                int pageStart = (page - 1) * limit;
                int pageEnd = pageStart + limit < total ? pageStart + limit : total;
                for (int i = pageStart; i < pageEnd; i++) {
                    Object[] o = objs.get(i);
                    Etagencylevel etagencylevel = new Etagencylevel();
                    etagencylevel.setFid((String) o[0]);
                    etagencylevel.setFname((String) o[1]);
                    etagencylevel.setFlevel((Integer) o[2]);
                    etAgencyLevelList.add(etagencylevel);
                }
            }
        }
        Map<String, Object> m = new HashMap<>(2);
        m.put("total", total);
        m.put("etAgencyLevelList", etAgencyLevelList);
        return m;
    }

    @Override
    public String findIdByLevel(Object level) {
        String sql = "select fid from etagencylevel where flevel=:flevel";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("flevel", level);
        List list = query.getResultList();
        if (!list.isEmpty()) {
            return list.get(0).toString();
        }
        return null;
    }
}
