package com.sccin.spboot.service.third.dto.pld;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by jun.li on 2018/5/23.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Pld2004 {
    /**
     * 用户体系中使用的角色地区ID
     */
    @JsonProperty(value = "UserRoleID")
    private String userRoleID;

    /**
     * 角色ID
     */
    @JsonProperty(value = "RoleID")
    private String roleID;

    /**
     * 角色  参考《用户体系接口枚举值》
     */
    //
    @JsonProperty(value = "RoleCode")
    private String roleCode;

    /**
     * 备注信息
     */
    @JsonProperty(value = "Remark")
    private String remark;

    /**
     * 角色名
     */
    @JsonProperty(value = "RoleName")
    private String roleName;

    public Pld2004() {
    }

    public String getUserRoleID() {
        return userRoleID;
    }

    public void setUserRoleID(String userRoleID) {
        this.userRoleID = userRoleID;
    }

    public String getRoleID() {
        return roleID;
    }

    public void setRoleID(String roleID) {
        this.roleID = roleID;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
