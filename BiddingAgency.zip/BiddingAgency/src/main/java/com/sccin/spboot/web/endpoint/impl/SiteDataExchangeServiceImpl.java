package com.sccin.spboot.web.endpoint.impl;

import com.sccin.spboot.web.endpoint.WebServiceProvider;
import com.sccin.spboot.web.endpoint.dto.recv.CameraInfo;
import com.sccin.spboot.web.endpoint.dto.recv.ProjectOrderInfo;
import com.sccin.spboot.web.endpoint.dto.recv.RoomInfo;
import com.sccin.spboot.web.endpoint.dto.result.Result;
import com.sccin.spboot.web.endpoint.interfaces.SiteDataExchangeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import javax.jws.WebService;
import java.util.*;

/**
 * Created by CPYF-Yi Mao on 2018-09-26.
 */
@Component
@WebService(serviceName = "SiteDataExchangeService",
            portName = "SiteDataExchangeServicePort",
            targetNamespace = "http://interfaces.endpoint.web.spboot.sccin.com",
            endpointInterface = "com.sccin.spboot.web.endpoint.interfaces.SiteDataExchangeService")
public class SiteDataExchangeServiceImpl extends WebServiceProvider implements SiteDataExchangeService {

    private static Logger logger = LoggerFactory.getLogger(SiteDataExchangeServiceImpl.class);


    @Override
    public String getRoomInfos(String jsonStr){
        logger.info("场地请求获取开评标房间信息：jsonStr -> "+jsonStr);
        /*try{
            Result<RoomInfo> result;
            RoomInfo param;
            if((result = jsonTransferToBean(jsonStr,RoomInfo.class)).checkSuccess()){
                param = result.getData();
            }else {
                return toJson(result);
            }

            List<Mediaroom> listRooms = mediaRoomReposityInter.findAllByAreacode(param.getAreacode());

            LinkedList<Map> data = new LinkedList<>();
            Map map;
            for(Mediaroom room : listRooms){
                map = new HashMap();
                map.put("roomno",room.getRoomno());
                map.put("roomname",room.getRoomname());
                map.put("roomtype",room.getRoomtype());
                data.addLast(map);
            }

            return toJson(Result.buildSuccess(data));
        }catch (Exception e) {
            logger.error("获取开评标房间信息接口运行非预期异常:"+e.getMessage());
        }*/
        return buildFailedStr("获取开评标房间信息接口运行非预期异常");
    }

    @Override
    public String receiveOrderRoomInfos(String jsonStr){
        /*logger.info("接收场地预约开评标房间信息：jsonStr -> "+jsonStr);
        try{
            Result<ProjectOrderInfo> result;
            ProjectOrderInfo param;
            if((result = jsonTransferToBean(jsonStr,ProjectOrderInfo.class)).checkSuccess()){
                param = result.getData();
            }else {
                return toJson(result);
            }

            return toJson(projectService.pushAdd(param));
        }catch (Exception e) {
            logger.error("接收场地预约开评标房间信息接口运行非预期异常:"+e.getMessage());
        }*/
        return buildFailedStr("接收场地预约开评标房间信息接口运行非预期异常");
    }


    @Override
    public String getCameraInfos(String jsonStr){
        logger.info("获取开评标房间摄像头信息：jsonStr -> "+jsonStr);
        /*try{
            Result<CameraInfo> result;
            CameraInfo param;
            if((result = jsonTransferToBean(jsonStr,CameraInfo.class)).checkSuccess()){
                param = result.getData();
            }else {
                return toJson(result);
            }
            String[] projectIds = param.getProjectId().split(",");
            List<Camera> listRooms = cameraReposityInter.getCameraInfoByProjectId(Arrays.asList(projectIds));

            LinkedList<Map> data = new LinkedList<>();
            Map map;
            for(Camera room : listRooms){
                map = new HashMap();
                map.put("projectId",room.getProjectId());
                map.put("cameraId",room.getId());
                map.put("roomtype",room.getRoomtype());
                data.addLast(map);
            }

            return toJson(Result.buildSuccess(data));
        }catch (Exception e) {
            logger.error("获取开评标房间摄像头信息接口运行非预期异常:"+e.getMessage());
        }*/
        return buildFailedStr("获取开评标房间摄像头信息接口运行非预期异常");
    }
}
