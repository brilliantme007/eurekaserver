package com.sccin.spboot.security;

import com.sccin.spboot.security.pojo.SecurityUser;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.FilterInvocation;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Created by developer_hyaci on 2018/8/14.
 *
 */
@Component
//Security需要用到一个实现了AccessDecisionManager接口的类
//类功能：根据当前用户的信息，和目标url涉及到的权限，判断用户是否可以访问
//判断规则：用户只要匹配到目标url权限中的一个role就可以访问
public class AccessDecisionManagerImpl implements AccessDecisionManager {
    @Override
    public void decide(Authentication authentication, Object o, Collection<ConfigAttribute> collection) throws AccessDeniedException, InsufficientAuthenticationException {
        //验证豁免
        if(collection == null) {
            return;
        }

        //获得元数据
        List<String> needRoles = new ArrayList<>();
        Iterator<ConfigAttribute> iterator = collection.iterator();
        while (iterator.hasNext()) {
            needRoles.add(iterator.next().getAttribute());
        }

        //不在所有权限控制范围的请求
        if(needRoles.contains("NODESIGN")){
            throw new AccessDeniedException("用户访问超权");
        }

        //登录验证
        if (authentication instanceof AnonymousAuthenticationToken) {
            throw new InsufficientAuthenticationException("当前未登录");
        }

        //共有权限已过登录验证
        if(needRoles.contains("NEEDLOGIN")){ return; }

        //权限验证
        Iterator<? extends GrantedAuthority> authorities = ((SecurityUser)authentication.getPrincipal()).getAuthorities().iterator();
        while (authorities.hasNext()){
            if(needRoles.contains(authorities.next().getAuthority())){
                return;
            }
        }

        throw new AccessDeniedException("用户权限不足");
    }

    @Override
    public boolean supports(ConfigAttribute configAttribute) {
        return true;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return FilterInvocation.class.isAssignableFrom(aClass);
    }
}
