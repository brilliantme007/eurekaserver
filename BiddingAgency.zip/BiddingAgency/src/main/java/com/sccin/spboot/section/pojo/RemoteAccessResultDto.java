package com.sccin.spboot.section.pojo;

import org.slf4j.Logger;

/**
 * 调用第三方方法统一结果封装
 */
public class RemoteAccessResultDto {

    private Boolean state;  //成功、失败
    private String message; //失败消息
    private String domain;  //地址（用于失败重新发起）

    RemoteAccessResultDto(Boolean state, String message, String domain){
        this.state = state;
        this.message = message;
        this.domain = domain;
    }

    public static RemoteAccessResultDto buildSuccess(){
        return new RemoteAccessResultDto(Boolean.TRUE,null,null);
    }

    public static RemoteAccessResultDto buildFailed(String message, String domain , Logger logger){
        logger.error(message);
        return new RemoteAccessResultDto(Boolean.FALSE,message,domain);
    }

    public boolean isState() {
        return state;
    }

    public Boolean getState() {
        return state;
    }

    public void setState(Boolean state) {
        this.state = state;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }
}
