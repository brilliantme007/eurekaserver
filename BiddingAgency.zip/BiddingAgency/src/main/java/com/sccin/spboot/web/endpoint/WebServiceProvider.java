package com.sccin.spboot.web.endpoint;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sccin.spboot.utils.ValidUtils;
import com.sccin.spboot.web.endpoint.dto.result.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Created by CPYF-Yi Mao on 2018-09-27.
 * webservice 通用处理方法
 */
public class WebServiceProvider {

    private static Logger logger = LoggerFactory.getLogger(WebServiceProvider.class);

    protected static final ObjectMapper objectMapper = new ObjectMapper();

    protected <T> Result jsonTransferToBean(String json,Class<T> cls){
        T obj;
        try {
            obj = objectMapper.readValue(json,cls);
        } catch (IOException e) {
            return Result.buildFailed("Json参数转换实体Bean异常",logger);
        }

        ValidUtils.CheckResult result;
        if(!(result = ValidUtils.checkObject(obj)).isCheck())
            return Result.buildReject(result.getMessage(),logger);

        return Result.buildSuccess(obj);
    }

    protected String toJson(Object obj) throws JsonProcessingException {
        return objectMapper.writeValueAsString(obj);
    }

    protected String buildFailedStr(String message){
        return "{\"status\":\"2\",\"message\":\""+message+"\"}";
    }
}
