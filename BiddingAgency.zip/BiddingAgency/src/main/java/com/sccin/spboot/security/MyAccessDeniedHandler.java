package com.sccin.spboot.security;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.csrf.CsrfException;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by developer_hyaci on 2018/8/14.
 */
@Component
//成功登陆之后，在权限授权验证过程中出现异常才会进入该处；
public class MyAccessDeniedHandler implements AccessDeniedHandler {

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException e) throws IOException, ServletException {
        request.setAttribute("errMsg",e.getMessage());
        //判断当前请求是否为ajax
        if(request.getHeader("X-Requested-With")!=null){  //Ajax请求
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);   //403
            if(e instanceof CsrfException){ //csrf异常,跳转至timeout超时处理
                response.setHeader("REDIRECT", request.getContextPath()+"/timeout.html");
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            }
            request.getRequestDispatcher("/ajaxError").forward(request,response);
        }else{
            if(e instanceof CsrfException){
                request.getRequestDispatcher("/timeout.html").forward(request,response);
            }else {
                request.getRequestDispatcher("/error.html").forward(request,response);
            }
        }
    }
}
