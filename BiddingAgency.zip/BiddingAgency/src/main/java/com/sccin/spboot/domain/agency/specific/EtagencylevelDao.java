package com.sccin.spboot.domain.agency.specific;

import java.util.Map;

/**
 * @author MeiYF 2018/12/27 8:28 库级别的dao
 **/
public interface EtagencylevelDao {

    /**
     * 查询库级别信息
     *
     * @param page 当前页面需要跳转到的第几页
     * @param limit 每页显示多少条
     * @param fname 库级别名称
     * @param flevel 库级别数
     * @return 返回
     */
    Map<String, Object> selectAgencylevelMess(int page, int limit, String fname, String flevel);

    /**
     * 根据级别查找对应的ID
     *
     * @param level 级别
     * @return ID
     */
    String findIdByLevel(Object level);
}
