package com.sccin.spboot.utils;

import javax.persistence.Query;
import java.util.Map;

/**
 * sql相关实用方法
 *
 * @Author lijun
 */
public class SqlUtils {
    /**
     * 私有实例化方法
     */
    private SqlUtils() {};

    /**
     * 为查询对象（Query）设置参数
     *
     * @param parameters 参数集合
     * @param query 查询对象
     */
    public static void setParameters(Map<String,Object> parameters, Query query){
        for(Map.Entry<String, Object> entry: parameters.entrySet()){
            query.setParameter(entry.getKey(), entry.getValue());
        }
    }
}
