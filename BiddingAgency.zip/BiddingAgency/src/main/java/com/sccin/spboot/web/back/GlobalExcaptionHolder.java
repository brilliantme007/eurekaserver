package com.sccin.spboot.web.back;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by developer_hyaci on 2016/6/30.
 * controller global handle excaption!
 */
public class GlobalExcaptionHolder {

    /**
     * ObjectMapper,用于转换其他元素为json
     */
    public static final ObjectMapper MAPPER = new ObjectMapper();

    private final static Logger logger = LoggerFactory.getLogger(GlobalExcaptionHolder.class);
    // 默认每页显示20条数据
    public final static int PAGESIZE = 20;

    @ExceptionHandler
    public String exp(HttpServletRequest request, Exception ex) {
        String path = request.getServletPath();
        StringBuffer vistiParams = new StringBuffer();
        if (request.getParameterMap() != null) {
            for (String key : request.getParameterMap().keySet()) {
                if (vistiParams.length() > 0) {
                    vistiParams.append("|" + key + ":" + request.getParameterMap().get(key)[0]);
                } else {
                    vistiParams.append(key + ":" + request.getParameterMap().get(key)[0]);
                }
            }
        }
        String uuid = System.currentTimeMillis() + "";
        logger.error("[" + uuid + "] visit path[" + path + "] been exception:" + ex.getMessage() +
                (vistiParams.length() > 0 ? (",with params:" + vistiParams.toString()) : ""), ex);
        request.setAttribute("errorUnique", uuid);
        return "error";
    }


    /**
     * 将结果封装为layui需要的json格式
     *
     * @param code  返回代码，0：成功，其他：失败
     * @param msg   返回信息
     * @param count 当前数据总条数
     * @param list  当前数据集合
     * @return 返回的是json
     */
    public static String buildJson(int code, String msg, long count, List list) {
        Map<String, Object> returnMap = new HashMap<>();
        returnMap.put("code", code);
        returnMap.put("msg", msg);
        returnMap.put("count", count);
        returnMap.put("data", list);

        //将map转json
        String returnJson = null;
        try {
            returnJson = MAPPER.writeValueAsString(returnMap);
        } catch (JsonProcessingException e) {
            logger.info("在【" + GlobalExcaptionHolder.getLogtime() + "】查询的数据转换json失败：" + e.getMessage());
            returnJson = "{\"code\":1,\"msg\":\"查询失败!\",\"count\":\"0\",\"data\":[]}";
        }
        return returnJson;
    }

    /**
     * 当失败的时候返回
     *
     * @param msg 返回失败信息
     * @return 返回的json
     */
    public static String buildFailJson(String msg) {
        return buildJson(1, msg, 0L, Collections.EMPTY_LIST);
    }

    /**
     * 当失败的时候返回
     *
     * @param count 当前数据总条数
     * @param list  当前数据集合
     * @return 返回的json
     */
    public static String buildSuccessJson(long count, List list) {
        return buildJson(0, "", count, list);
    }

    /**
     * 记录日志时间
     *
     * @return 返回
     */
    private static String getLogtime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
    }

}
