package com.sccin.spboot.domain.moren;

import javax.persistence.*;
import java.util.Objects;

/**
 * Created by CPYF-Yi Mao on 2018-08-27.
 */
@Entity
@Table(name = "etauthority")
public class Authority {
    private String id;
    private String name;
    private Integer type;
    private Integer index;
    private String url;
    private String parent;
    private String remark;

    @Id
    @Column(name = "fid", nullable = false, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "fname", nullable = true, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "ftype", nullable = true)
    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Basic
    @Column(name = "findex", nullable = true)
    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    @Basic
    @Column(name = "furl", nullable = true, length = 50)
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Basic
    @Column(name = "fparent", nullable = true, length = 50)
    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    @Basic
    @Column(name = "fremark", nullable = true, length = 258)
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Authority authority = (Authority) o;
        return Objects.equals(id, authority.id) &&
                Objects.equals(name, authority.name) &&
                Objects.equals(type, authority.type) &&
                Objects.equals(index, authority.index) &&
                Objects.equals(url, authority.url) &&
                Objects.equals(parent, authority.parent) &&
                Objects.equals(remark, authority.remark);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, type, index, url, parent, remark);
    }
}
