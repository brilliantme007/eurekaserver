package com.sccin.spboot.service.front;

import com.sccin.spboot.domain.agency.*;
import com.sccin.spboot.domain.agency.repository.*;

import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.StringUtil;
import org.apache.tomcat.util.buf.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created on 2018-12-27 9:02
 *
 * @Author WHLiang
 */
@Service("etagencyService")
public class EtagencyService {

    private static final Integer GROUP_1 = 1;
    private static final Integer GROUP_2 = 2;

    @Autowired
    private EtagencyInter etagencyInter;

    @Autowired
    private EtprojinfoInter etprojinfoInter;

    @Autowired
    private RnprojagencyInter rnprojagencyInter;

    @Autowired
    private EtextractigngInter etextractigngInter;

    @Autowired
    private EtagencylevelInter etagencylevelInter;

    /**
     * 通过项目的fid查询项目抽取结果
     *
     * @param projectId 项目fid
     * @return com.sccin.spboot.domain.agency.Rnprojagency
     * @author WHLiang
     * @date 2018-12-28 14:30
     */
    public Rnprojagency getProjAgencyByProjectId(String projectId) {
        return rnprojagencyInter.findByRprojinfoid(projectId);
    }

    /**
     * 通过项目的fid查询项目抽取结果
     *
     * @param projectIds 项目fids
     * @return com.sccin.spboot.domain.agency.Rnprojagency
     * @author WHLiang
     * @date 2018-12-28 14:30
     */
    public List<Rnprojagency> getProjAgencyByProjectIds(List<String> projectIds) {
        return rnprojagencyInter.findByRprojinfoidIn(projectIds);
    }

    /**
     * 获取待抽取的代理机构
     *
     * @param
     * @return java.util.List<com.sccin.spboot.domain.agency.Etagency>
     * @author WHLiang
     * @date 2018-12-27 19:20
     */
    public List<Etagency> getEtagencysNeedExtract() {
        return etagencyInter.getEtagencysNeedExtract();
    }

    /**
     * 获取所有的代理
     *
     * @return java.util.List<com.sccin.spboot.domain.agency.Etagency>
     * @author WHLiang
     * @date 2018-12-29 14:15
     */
    public List<Etagency> getAll() {
        return etagencyInter.findAll();
    }

    /**
     * 获取招标非指定页面上需要显示的组
     *
     * @param etagencysNeedExtract 待抽取机构列表
     * @param etprojinfo           待抽取项目
     * @return java.util.List<com.sccin.spboot.domain.agency.Etagency>
     * @author WHLiang
     * @date 2018-12-29 14:20
     */
    public List<Etagency> tenderGroupResult(List<Etagency> etagencysNeedExtract, Etprojinfo etprojinfo) {
        // step1 信息
        Etextracting etextracting1 = new Etextracting();
        // step2 信息
        Etextracting etextracting2 = new Etextracting();
        // 这些步骤信息,只有正常抽取得到结果才入库
        etextracting1.setFid(UUID.randomUUID().toString());
        etextracting1.setFlevel("1,2");
        etextracting1.setRprojid(etprojinfo.getFid());
        etextracting1.setFtime(Timestamp.valueOf(LocalDateTime.now()));
        etextracting1.setFstep(1);
        etextracting1.setFmark("招标项目:" + etprojinfo.getFprojname() + "开始抽取,从1.2级别库符合条件的代理中抽取");
        etextracting1.setFtempgroup(spliceStr(etagencysNeedExtract));
        // 分组(以级别分组)
        List<List<Etagency>> groupEachFive = new ArrayList<>();
        groupByLevel(etagencysNeedExtract, groupEachFive);
        List<Etagency> etagencies = new ArrayList<>();
        // 默认取第一组
        int groupIndex = 0;
        if (!groupEachFive.isEmpty()) {
            etextracting2.setFid(UUID.randomUUID().toString());
            etextracting2.setFlevel("1,2");
            etextracting2.setRprojid(etprojinfo.getFid());
            etextracting2.setFtime(Timestamp.valueOf(LocalDateTime.now()));
            etextracting2.setFstep(2);
            etextracting2.setFmark("招标项目:" + etprojinfo.getFprojname() + "抽取分组,将1.2级别库符合条件的代理" + spliceStr(etagencysNeedExtract) + "按照5个一组分组");
            // 获取上次的招标抽取的代理机构,现在没有判断非招标查询全部
            Rnprojagency lastResult = rnprojagencyInter.findLastResult();
            if (lastResult != null) {
                groupIndex = getGroupIndex(groupEachFive, groupIndex, lastResult);
            }
            etagencies = groupEachFive.get(groupIndex);
            etextracting2.setFtempgroup(spliceStr(etagencies));
        }
        if (!etagencies.isEmpty()) {
            etextractigngInter.save(etextracting1);
            etextractigngInter.save(etextracting2);
        }
        return etagencies;
    }

    /**
     * 指定的时候保存第一步信息
     *
     * @param etagencysNeedExtract
     * @param etprojinfo
     * @return void
     * @author WHLiang
     * @date 2019-01-02 14:18
     */
    public void notTenderStep(List<Etagency> etagencysNeedExtract, Etprojinfo etprojinfo) {
        // step1 信息
        Etextracting etextracting1 = new Etextracting();
        // 这些步骤信息,只有正常抽取得到结果才入库
        etextracting1.setFid(UUID.randomUUID().toString());
        etextracting1.setFlevel("1,2");
        etextracting1.setRprojid(etprojinfo.getFid());
        etextracting1.setFtime(Timestamp.valueOf(LocalDateTime.now()));
        etextracting1.setFstep(1);
        etextracting1.setFmark("招标项目:" + etprojinfo.getFprojname() + "开始抽取,从1.2级别库符合条件的代理中抽取");
        etextracting1.setFtempgroup(spliceStr(etagencysNeedExtract));
        etextractigngInter.save(etextracting1);
    }

    /**
     * 项目抽取过程
     *
     * @param fid 项目fid
     * @return java.lang.String
     * @author WHLiang
     * @date 2018-12-27 14:03
     */
    @Transactional
    public String agencyExtractionResult(String fid) {
        // 通过fid 查询出该项目信息
        Optional<Etprojinfo> etprojinfoOptional = etprojinfoInter.findById(fid);
        Etprojinfo etprojinfo = etprojinfoOptional.orElse(null);
        if (etprojinfo == null) {
            return "项目不存在,无法抽取!";
        } else {
            // 获取 代理机构 列表 只获取正常情况(fstate=0)下的招标代理
            List<Etagency> etagencysNeedExtract = etagencyInter.getEtagencysNeedExtract();
            if (etagencysNeedExtract == null || etagencysNeedExtract.isEmpty()) {
                return "没有可以抽取的代理机构!";
            }
            // 需要判断该项目时非招标还是招标
            // 招标 true,非招标 false 暂时没有判断 默认为招标
            boolean isTender = true;
            if (!StringUtil.isEmpty(etprojinfo.getFmkeys())) {
                String xmlValueByNameAndAttr = getXmlValueByNameAndAttr(etprojinfo.getFmkeys(), "bidType", "value");
                if (!StringUtil.isEmpty(xmlValueByNameAndAttr) && "2".equals(xmlValueByNameAndAttr)) {
                    // 非招标
                    isTender = false;
                }
            }
            // 抽中的机构
            Etagency etagency = null;
            if (isTender) {
                // 招标 走一个逻辑
                etagency = tenderResult(etagencysNeedExtract, etprojinfo);
            } else {
                // 非招标 走一个 逻辑
                etagency = notTenderResult(etagencysNeedExtract, etprojinfo);
            }
            // 抽取完毕
            if (etagency == null) {
                return "没有抽取到代理机构!";
            } else {
                // 入库相关的信息
                return etagency.getFepname();
            }
        }
    }

    /**
     * 获取xml 里面的attr的值
     *
     * @param xmlStr xml字符串
     * @param name   xml 里面的字段名称
     * @param attr   attr
     * @return java.lang.String
     * @author WHLiang
     * @date 2018-12-28 15:51
     */
    public String getXmlValueByNameAndAttr(String xmlStr, String name, String attr) {
        List<Map<String, Object>> list = Statements.getProject(new StringBuilder(xmlStr));
        String result = null;
        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> stringObjectMap : list) {
                if (stringObjectMap.containsKey("name") && !StringUtil.isEmpty(stringObjectMap.get("name"))) {
                    Object nameValue = stringObjectMap.get("name");
                    if (name.equals(nameValue)) {
                        // 需要的字段
                        if (stringObjectMap.containsKey("attr") && stringObjectMap.get("attr") != null) {
                            Map<String, Object> attrValue = (Map<String, Object>) stringObjectMap.get("attr");
                            if (attrValue.containsKey(attr) && !StringUtil.isEmpty(attrValue.get(attr))) {
                                // 需要的attr
                                result = String.valueOf(attrValue.get(attr));
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * 招标抽取的逻辑
     *
     * @param etagencysNeedExtract 待抽取的机构集合
     * @param etprojinfo           项目信息
     * @return Etagency
     * @author WHLiang
     * @date 2018-12-27 14:13
     */
    public Etagency tenderResult(List<Etagency> etagencysNeedExtract, Etprojinfo etprojinfo) {
        // step1 信息
        Etextracting etextracting1 = new Etextracting();
        // step2 信息
        Etextracting etextracting2 = new Etextracting();
        // stemp 信息
        Etextracting etextracting3 = new Etextracting();
        // 这些步骤信息,只有正常抽取得到结果才入库
        etextracting1.setFid(UUID.randomUUID().toString());
        etextracting1.setFlevel("1,2");
        etextracting1.setRprojid(etprojinfo.getFid());
        etextracting1.setFtime(Timestamp.valueOf(LocalDateTime.now()));
        etextracting1.setFstep(1);
        etextracting1.setFmark("招标项目:" + etprojinfo.getFprojname() + "开始抽取,从1.2级别库符合条件的代理中抽取");
        etextracting1.setFtempgroup(spliceStr(etagencysNeedExtract));
        // 分组(以级别分组)
        List<List<Etagency>> groupEachFive = new ArrayList<>();
        groupByLevel(etagencysNeedExtract, groupEachFive);
        Etagency result = null;
        // 默认取第一组
        int groupIndex = 0;
        if (!groupEachFive.isEmpty()) {
            etextracting2.setFid(UUID.randomUUID().toString());
            etextracting2.setFlevel("1,2");
            etextracting2.setRprojid(etprojinfo.getFid());
            etextracting2.setFtime(Timestamp.valueOf(LocalDateTime.now()));
            etextracting2.setFstep(2);
            etextracting2.setFmark("招标项目:" + etprojinfo.getFprojname() + "抽取分组,将1.2级别库符合条件的代理" + spliceStr(etagencysNeedExtract) + "按照5个一组分组");
            // 获取上次的招标抽取的代理机构,现在没有判断非招标查询全部
            Rnprojagency lastResult = rnprojagencyInter.findLastResult();
            if (lastResult != null) {
                groupIndex = getGroupIndex(groupEachFive, groupIndex, lastResult);
            }
            List<Etagency> etagencies = groupEachFive.get(groupIndex);
            etextracting2.setFtempgroup(spliceStr(etagencies));
            if (etagencies != null && !etagencies.isEmpty()) {
                int round = (int) (Math.random() * etagencies.size());
                result = etagencies.get(round);
                etextracting3.setFid(UUID.randomUUID().toString());
                etextracting3.setFlevel("1,2");
                etextracting3.setRprojid(etprojinfo.getFid());
                etextracting3.setFtime(Timestamp.valueOf(LocalDateTime.now()));
                etextracting3.setFstep(3);
                etextracting3.setFmark("招标项目:" + etprojinfo.getFprojname() + "抽取,从分组:" + spliceStr(etagencies) + "中随机抽取,抽取结果为:" + result.getFepname());
                etextracting3.setFtempgroup(spliceStr(etagencies));
            }
        }
        if (result != null) {
            Rnprojagency rnprojagency = new Rnprojagency();
            rnprojagency.setFid(UUID.randomUUID().toString());
            rnprojagency.setRagencyid(result.getFid());
            rnprojagency.setRprojinfoid(etprojinfo.getFid());
            Optional<Etagency> byId = etagencyInter.findById(rnprojagency.getRagencyid());
            Etagency etagency = byId.orElse(null);
            if (etagency != null) {
                etagency.setFbidcount(etagency.getFbidcount() + 1);
                if (etagency.getFlevel() == 1 && etagency.getFbidcount() >= 5) {
                    etagency.setFstate(1);
                }
                if (etagency.getFlevel() == 2 && etagency.getFbidcount() >= 3) {
                    etagency.setFstate(1);
                }
            }
            etextractigngInter.save(etextracting1);
            etextractigngInter.save(etextracting2);
            etextractigngInter.save(etextracting3);
            rnprojagencyInter.save(rnprojagency);
            if (etagency != null) {
                etagencyInter.save(etagency);
            }
        }
        return result;
    }

    /**
     * 获取本次抽取的组坐标
     *
     * @param groupEachFive
     * @param groupIndex
     * @param lastResult
     * @return int
     * @author WHLiang
     * @date 2018-12-28 14:51
     */
    private int getGroupIndex(List<List<Etagency>> groupEachFive, int groupIndex, Rnprojagency lastResult) {
        // 上次招标代理的id
        String ragencyid = lastResult.getRagencyid();
        // 循环当前分组(除最后一组),判断上次抽取到的代理在第几组,本次抽取他的后一组
        if (!StringUtil.isEmpty(ragencyid)) {
            int size = groupEachFive.size();
            for (int i = 0; i < size - 1; i++) {
                List<Etagency> etagencies = groupEachFive.get(i);
                if (etagencies != null) {
                    for (Etagency etagency : etagencies) {
                        if (etagency != null && ragencyid.equals(etagency.getFid())) {
                            groupIndex = i + 1;
                            break;
                        }
                    }
                }
            }
        }
        return groupIndex;
    }

    /**
     * 非招标抽取逻辑
     *
     * @param etagencysNeedExtract 带抽取的机构集合
     * @param etprojinfo           项目信息
     * @return Etagency
     * @author WHLiang
     * @date 2018-12-27 14:14
     */
    public Etagency notTenderResult(List<Etagency> etagencysNeedExtract, Etprojinfo etprojinfo) {
        Etextracting etextracting1 = new Etextracting();
        Etextracting etextracting2 = new Etextracting();
        etextracting1.setFid(UUID.randomUUID().toString());
        etextracting1.setFlevel("1,2");
        etextracting1.setFstep(1);
        etextracting1.setFmark("非招标项目:" + etprojinfo.getFprojname() + "开始抽取,从1.2级别库符合条件的代理中抽取");
        etextracting1.setRprojid(etprojinfo.getFid());
        etextracting1.setFtime(Timestamp.valueOf(LocalDateTime.now()));
        etextracting1.setFtempgroup(spliceStr(etagencysNeedExtract));
        Etagency result = null;
        if (etagencysNeedExtract != null && !etagencysNeedExtract.isEmpty()) {
            int round = (int) (Math.random() * etagencysNeedExtract.size());
            result = etagencysNeedExtract.get(round);
        }
        if (result != null) {
            etextracting2.setFid(UUID.randomUUID().toString());
            etextracting2.setFlevel("1,2");
            etextracting2.setFstep(2);
            etextracting2.setFmark("非招标项目:" + etprojinfo.getFprojname() + "抽取完毕,从1.2级别库符合条件的代理中随机抽取结果:" + result.getFepname());
            etextracting2.setRprojid(etprojinfo.getFid());
            etextracting2.setFtime(Timestamp.valueOf(LocalDateTime.now()));
            etextracting2.setFtempgroup(spliceStr(etagencysNeedExtract));
            Rnprojagency rnprojagency = new Rnprojagency();
            rnprojagency.setFid(UUID.randomUUID().toString());
            rnprojagency.setRagencyid(result.getFid());
            rnprojagency.setRprojinfoid(etprojinfo.getFid());
            Optional<Etagency> byId = etagencyInter.findById(rnprojagency.getRagencyid());
            Etagency etagency = byId.orElse(null);
            if (etagency != null) {
                etagency.setFchoosecount(etagency.getFchoosecount() + 1);
                if (etagency.getFchoosecount() >= 20) {
                    etagency.setFstate(1);
                }
            }
            etextractigngInter.save(etextracting1);
            etextractigngInter.save(etextracting2);
            rnprojagencyInter.save(rnprojagency);
            if (etagency != null) {
                etagencyInter.save(etagency);
            }
        }
        return result;
    }

    /**
     * 非招标抽取逻辑(集中抽取)
     *
     * @param etagencysNeedExtract 带抽取的机构集合
     * @param etprojinfos          项目信息
     * @return Etagency
     * @author WHLiang
     * @date 2018-12-27 14:14
     */
    public Etagency notTenderResult1(List<Etagency> etagencysNeedExtract, List<Etprojinfo> etprojinfos) {
        Etagency result = null;
        if (etagencysNeedExtract != null && !etagencysNeedExtract.isEmpty()) {
            int round = (int) (Math.random() * etagencysNeedExtract.size());
            result = etagencysNeedExtract.get(round);
        }
        for (Etprojinfo etprojinfo : etprojinfos) {
            Etextracting etextracting1 = new Etextracting();
            Etextracting etextracting2 = new Etextracting();
            etextracting1.setFid(UUID.randomUUID().toString());
            etextracting1.setFlevel("1,2");
            etextracting1.setFstep(1);
            etextracting1.setFmark("非招标项目:" + etprojinfo.getFprojname() + "开始抽取,从1.2级别库符合条件的代理中抽取");
            etextracting1.setRprojid(etprojinfo.getFid());
            etextracting1.setFtime(Timestamp.valueOf(LocalDateTime.now()));
            etextracting1.setFtempgroup(spliceStr(etagencysNeedExtract));
            if (result != null) {
                etextracting2.setFid(UUID.randomUUID().toString());
                etextracting2.setFlevel("1,2");
                etextracting2.setFstep(2);
                etextracting2.setFmark("非招标项目:" + etprojinfo.getFprojname() + "抽取完毕,从1.2级别库符合条件的代理中随机抽取结果:" + result.getFepname());
                etextracting2.setRprojid(etprojinfo.getFid());
                etextracting2.setFtime(Timestamp.valueOf(LocalDateTime.now()));
                etextracting2.setFtempgroup(spliceStr(etagencysNeedExtract));
                Rnprojagency rnprojagency = new Rnprojagency();
                rnprojagency.setFid(UUID.randomUUID().toString());
                rnprojagency.setRagencyid(result.getFid());
                rnprojagency.setRprojinfoid(etprojinfo.getFid());
                Optional<Etagency> byId = etagencyInter.findById(rnprojagency.getRagencyid());
                Etagency etagency = byId.orElse(null);
                if (etagency != null) {
                    etagency.setFchoosecount(etagency.getFchoosecount() + 1);
                    if (etagency.getFchoosecount() >= 20) {
                        etagency.setFstate(1);
                    }
                }
                etextractigngInter.save(etextracting1);
                etextractigngInter.save(etextracting2);
                rnprojagencyInter.save(rnprojagency);
                if (etagency != null) {
                    etagencyInter.save(etagency);
                }
            }
        }

        return result;
    }

    /**
     * 先按级别分组,再按5人一组
     *
     * @param etagencysNeedExtract 待抽取代理
     * @param groupEachFive        d
     * @return void
     * @author WHLiang
     * @date 2018-12-28 13:34
     */
    private void groupByLevel(List<Etagency> etagencysNeedExtract, List<List<Etagency>> groupEachFive) {
        if (etagencysNeedExtract != null) {
            Map<Integer, List<Etagency>> groupby = etagencysNeedExtract.stream().collect(Collectors.groupingBy(Etagency::getFlevel));
            if (groupby.containsKey(GROUP_1) && groupby.get(GROUP_1) != null && !groupby.get(GROUP_1).isEmpty()) {
                groupEachFive(groupEachFive, groupby.get(GROUP_1));
            }
            if (groupby.containsKey(GROUP_2) && groupby.get(GROUP_2) != null && !groupby.get(GROUP_2).isEmpty()) {
                groupEachFive(groupEachFive, groupby.get(GROUP_2));
            }
        }
    }

    /**
     * 五个一组分组
     *
     * @param groupFiv
     * @param groupByName
     * @return void
     * @author WHLiang
     * @date 2018-12-27 15:40
     */
    public void groupEachFive(List<List<Etagency>> groupFiv, List<Etagency> groupByName) {
        int size = groupByName.size();
        int intPart = size / 5;
        int remainder = size % 5;
        int count = remainder != 0 ? intPart + 1 : intPart;
        for (int i = 0; i < count; i++) {
            if (i != count - 1) {
                groupFiv.add(groupByName.subList(i*5, i*5 + 5));
            } else {
                groupFiv.add(groupByName.subList(i*5, size));
            }
        }
    }

    /**
     * 取出代理机构中的index拼接字符串,隔开
     *
     * @param etagencysNeedExtract
     * @return java.lang.String
     * @author WHLiang
     * @date 2018-12-28 8:46
     */
    private String spliceStr(List<Etagency> etagencysNeedExtract) {
        String result = null;
        if (etagencysNeedExtract != null) {
            List<String> tempList = new ArrayList<>();
            for (Etagency etagency : etagencysNeedExtract) {
                tempList.add(etagency.getFindex().toString());
            }
            result = StringUtils.join(tempList, ',');
        }
        return result;
    }

    /****
     * 根据查询条件 查询代理机构
     * @param param
     * @return
     */
    public Map<String, Object> queryAgencyByCondition(Map<String, Object> param) {
        Map<String, Object> result = new HashMap<>();
        List<Etagency> list = etagencyInter.queryAgencyByCondition(param);
        int total = etagencyInter.countAgencyByCondition(param);
        result.put("data", list);
        result.put("count", total);
        return result;
    }

    /****
     * 根据ID查询代理机构
     * @param fid id值
     * @return
     */
    public Etagency getEtagencyById(String fid) {
        Optional<Etagency> t = etagencyInter.findById(fid);
        if (t.isPresent()) {
            return t.get();
        }
        return null;
    }

    /***
     * 保存代理机构
     * @param nameValue
     */
    public void saveAgency(Map<String, Object> nameValue) {
        Etagency agency = null;
        if (nameValue.get("fid") != null && !"".equals(nameValue.get("fid").toString())) {
            agency = getEtagencyById(nameValue.get("fid").toString());
        } else {
            agency = new Etagency();
            agency.setFid(UUID.randomUUID().toString());
            agency.setFstate(0);
            agency.setFchoosecount(0);
            agency.setFbidcount(0);
        }
        if (nameValue.get("findex") != null) {
            agency.setFindex(Integer.parseInt(nameValue.get("findex").toString()));
        }
        if (nameValue.get("fepname") != null) {
            agency.setFepname(nameValue.get("fepname").toString());
        }
        if (nameValue.get("flinkman") != null) {
            agency.setFlinkman(nameValue.get("flinkman").toString());
        }
        if (nameValue.get("fsex") != null) {
            agency.setFsex(nameValue.get("fsex").toString());
        }
        if (nameValue.get("fduty") != null) {
            agency.setFduty(nameValue.get("fduty").toString());
        }
        if (nameValue.get("fphone") != null) {
            agency.setFphone(nameValue.get("fphone").toString());
        }
        if (nameValue.get("fscc") != null) {
            agency.setFscc(nameValue.get("fscc").toString());
        }
        if (nameValue.get("faddress") != null) {
            agency.setFaddress(nameValue.get("faddress").toString());
        }
        if (nameValue.get("ragencylevelid") != null) {
            agency.setRagencylevelid(nameValue.get("ragencylevelid").toString());
        }
        etagencyInter.save(agency);
    }

    /***
     * 删除代理机构
     * @param fid
     */
    public void deleteAgency(String fid) {
        etagencyInter.deleteById(fid);
    }


    /**
     * 向代理机构插入数据
     *
     * @param param
     */
    public void insertAgencyByParam(Map<String, Object> param) {
        etagencyInter.insertAgencyByParam(param);
    }

    /**
     * 保存抽取结果
     *
     * @param agency
     * @param etprojinfo
     * @return void
     * @author WHLiang
     * @date 2019-01-02 13:41
     */
    @Transactional
    public void saveExtraResult(Etagency agency, Etprojinfo etprojinfo) {
        // 过程
        Etextracting etextracting1 = new Etextracting();
        etextracting1.setFid(UUID.randomUUID().toString());
        etextracting1.setFlevel("1,2");
        etextracting1.setRprojid(etprojinfo.getFid());
        etextracting1.setFtime(Timestamp.valueOf(LocalDateTime.now()));
        etextracting1.setFstep(3);
        etextracting1.setFmark("招标项目:" + etprojinfo.getFprojname() + "保存选取结果:" + agency.getFepname());
        etextracting1.setFtempgroup(agency.getFindex().toString());
        // 结果
        Rnprojagency rnprojagency = new Rnprojagency();
        rnprojagency.setFid(UUID.randomUUID().toString());
        rnprojagency.setRagencyid(agency.getFid());
        rnprojagency.setRprojinfoid(etprojinfo.getFid());
        Optional<Etagencylevel> byId = etagencylevelInter.findById(agency.getRagencylevelid());
        Etagencylevel etagencylevel = byId.orElse(null);
        if (agency != null && etagencylevel != null) {
            agency.setFbidcount(agency.getFbidcount() + 1);
            if (etagencylevel.getFlevel()==1 && agency.getFbidcount() >= 5) {
                agency.setFstate(1);
            }
            if (etagencylevel.getFlevel()==2 && agency.getFbidcount() >= 3) {
                agency.setFstate(1);
            }
        }
        etextractigngInter.save(etextracting1);
        rnprojagencyInter.save(rnprojagency);
        etagencyInter.save(agency);
    }
}
