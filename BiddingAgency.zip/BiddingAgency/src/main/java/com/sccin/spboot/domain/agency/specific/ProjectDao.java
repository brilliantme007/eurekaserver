package com.sccin.spboot.domain.agency.specific;

import com.sccin.spboot.domain.agency.Etprojinfo;
import org.springframework.data.domain.Page;

import java.util.Map;

/**
 * 项目信息Dao接口
 *
 * @Author lijun
 */
public interface ProjectDao {
    /**
     * 分页查询项目信息
     *
     * @param page 页数
     * @param limit 大小
     * @param projectName 项目名称
     * @param bidType 招采类型
     * @Author lijun
     * @return 分页结果
     */
    Page<Map<String, Object>> pageBy(int page, int limit, String projectName, String bidType);
}
