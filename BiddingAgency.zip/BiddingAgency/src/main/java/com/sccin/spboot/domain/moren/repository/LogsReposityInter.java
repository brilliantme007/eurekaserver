package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.Nlog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by ccs on 2018/8/27.
 */
public interface LogsReposityInter extends JpaRepository<Nlog, String> {
    /**
     * 查询所有日志
     * @param pageable 分页页数
     * @return Nlog的分页
     */
    @Query("select l FROM Nlog l ")
    Page<Nlog> queryPage(Pageable pageable);

    /**
     * 根据fmessage查询日志
     * @param pageable  分页页数
     * @param fmessage 日志相关信息
     * @return Nlog的分页
     */
    @Query("select l FROM Nlog l where (l.arg4 like :fmessage or l.arg0 like :fmessage or l.arg1 like :fmessage or l.arg2 like :fmessage or l.arg3 like :fmessage)")
    Page<Nlog> queryPage(Pageable pageable, @Param("fmessage") String fmessage);

    /**
     *
     * @param arg0
     * @return
     */
    @Query("select l FROM Nlog l where l.arg0 = :arg0 ")
    List<Nlog> queryLogsByFarg0(@Param("arg0") String arg0);

    /**
     * 按时间删除可删除日志
     * @param date 时间
     */
    @Modifying
    @Query(value = "DELETE FROM etnlog WHERE etnlog.ftime< :date and etnlog.fisdel=1", nativeQuery = true)
    void deleteByFtimeBefore(@Param("date") String date);

    /**
     * 按时间删除日志
     * @param date
     */
    @Modifying
    @Query(value = "DELETE FROM etnlog WHERE etnlog.ftime< :date ", nativeQuery = true)
    void deleteByFtimeBeforeAll(@Param("date") String date);

    /**
     * 按fid删除一条日志
     * @param id
     */
    @Modifying
    @Query(value = "DELETE FROM etnlog WHERE etnlog.fid = :id and etnlog.fisdel=1", nativeQuery = true)
    void deleteByfid(@Param("id") String id);
}
