package com.sccin.spboot.web.front;

import com.sccin.spboot.domain.agency.Etprojinfo;
import com.sccin.spboot.domain.moren.Authority;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.security.LoginUserDetailsService;
import com.sccin.spboot.service.back.UserService;
import com.sccin.spboot.service.front.ProjectService;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.StringUtil;
import com.sccin.spboot.web.back.GlobalExcaptionHolder;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.*;


/**
 * 项目信息管理
 *
 * @author lijun
 */
@Controller
public class ProjectControl extends GlobalExcaptionHolder {
    /**
     * 日志logger
     */
    private static Logger logger = LoggerFactory.getLogger(ProjectControl.class);

    /**
     * 项目信息管理service
     */
    @Autowired
    private ProjectService projectService;

    /**
     * 登陆用户详情service
     */
    @Autowired
    private LoginUserDetailsService loginUserDetailsService;

    /**
     * 项目列表页面
     *
     * @param request 请求
     * @return 项目管理列表页
     * @author lijun
     */
    @RequestMapping(value = "/project/list.html", method = RequestMethod.GET)
    public String index(HttpServletRequest request, Model model) {
        //招采类型下拉选数据
        model.addAttribute("bidTypeOptions", Statements.STOP_WATCH_MAP.get("bidType"));

        /* 权限相关 */
        User user = UserService.getUserFromSession(request);
        List<Authority> authorityList = loginUserDetailsService.getLoginUserAuths(user.getId());
        if (authorityList != null && !authorityList.isEmpty()) {
            for (Authority authority : authorityList) {
                String url = authority.getUrl();
                if (url.equals("/project/edit.html")) {
                    //编辑或新增
                    model.addAttribute("editAuth", Boolean.TRUE);
                } else if (url.equals("/project/delete")) {
                    //删除
                    model.addAttribute("delAuth", Boolean.TRUE);
                } else if (url.equals("/project/extractionAgent.html")) {
                    //抽取
                    model.addAttribute("extractAuth", Boolean.TRUE);
                }
            }
        }

        return "front/views/app/project/list";
    }

    /**
     * ajax获取项目列表所需数据
     *
     * @param request 请求
     * @param page 页数
     * @param limit 大小
     * @param projectName 项目名称
     * @param bidType 招采类型
     * @return json数据
     * @author lijun
     */
    @RequestMapping(value = "/project/listdata", method = RequestMethod.POST)
    @ResponseBody
    public String getProjectData(HttpServletRequest request, int page, int limit, String projectName, String bidType) {
        Page<Map<String, Object>> projets = projectService.page(page - 1, limit, projectName, bidType);
        if (projets != null) {
            return buildSuccessJson(projets.getTotalElements(), projets.getContent());
        } else {
            return buildFailJson("不可能出现的错误");
        }
    }

    /**
     * 项目编辑页面
     *
     * @param request 请求
     * @return 项目编辑页面
     * @author lijun
     */
    @RequestMapping(value = "/project/edit.html", method = RequestMethod.GET)
    public String edit(HttpServletRequest request, Model model, String fid) {
        //项目信息
        Etprojinfo project;
        //编辑或新增显示的字段
        List<Map<String, Object>> fields;
        if (StringUtil.isEmpty(fid)) {
            /* 新增 */
            project = new Etprojinfo();
            fields = Statements.PROJECT_MAP;
        } else {
            /* 编辑 */
            project = projectService.findByIdOrUnique(fid);
            String fmkeys = project.getFmkeys() == null ? "" : project.getFmkeys();
            fields = Statements.getProject(new StringBuilder(fmkeys));
        }
        //xml中下拉选数据
        Map<String, Map<String, String>> xmlSelectOptions = new HashMap<>();
        fields.forEach(item -> {
            if (item.containsKey("attr") && item.get("attr") != null) {
                /* 设置需要stopWatch码表的数据 */
                Map<String, Object> attr = (Map<String, Object>) item.get("attr");
                if (attr.containsKey("type") && "select".equals(attr.get("type"))) {
                    if (attr.containsKey("reffered") && attr.get("reffered") != null) {
                        String reffered = (String) attr.get("reffered");
                        xmlSelectOptions.put(reffered, Statements.STOP_WATCH_MAP.get(reffered));
                    }
                }
            }
        });
        model.addAttribute("project", project);
        model.addAttribute("fields", fields);
        model.addAttribute("xmlSelectOptions", xmlSelectOptions);

        //招采类型下拉选数据
        model.addAttribute("bidTypeOptions", Statements.STOP_WATCH_MAP.get("bidType"));

        return "front/views/app/project/edit";
    }

    /**
     * 保存项目
     *
     * @param request 请求
     * @return 关联了true，否则false
     * @author lijun
     */
    @RequestMapping(value = "/project/save", method = RequestMethod.POST)
    @ResponseBody
    public AjaxReturnBean save(HttpServletRequest request, @RequestParam Map<String, String> params) {
        try {
            projectService.addOrUpdate(params);
            return AjaxReturnBean.createSuccess("success");
        } catch (IllegalArgumentException e) {
            logger.error(e.getMessage(), e);
            return AjaxReturnBean.createError("保存项目失败，请稍后再试!");
        }
    }

    /**
     * 检查项目是否关联了抽取结果
     *
     * @param request 请求
     * @param ids     项目唯一标识
     * @return 关联了true，否则false
     * @author lijun
     */
    @RequestMapping(value = "/project/check", method = RequestMethod.POST)
    @ResponseBody
    public AjaxReturnBean check(HttpServletRequest request, String ids) {
        if (ids == null) {
            logger.error("无效项目fids");
            return AjaxReturnBean.createError("检查是否关联了抽取结果失败");
        }
        boolean hasBeenRelated = projectService.hasBeenRelated(Arrays.asList(ids.split(",")));
        return AjaxReturnBean.createSuccess("检查成功", hasBeenRelated);
    }

    /**
     * ajax批量删除删除项目
     *
     * @param request 请求
     * @param ids     项目唯一标识
     * @return 删除成功或失败
     * @author lijun
     */
    @RequestMapping(value = "/project/delete", method = RequestMethod.POST)
    @ResponseBody
    public AjaxReturnBean delete(HttpServletRequest request, String ids) {
        Objects.requireNonNull(ids);
        String[] idArray = ids.split(",");

        //操作日志
        StringBuffer msg = new StringBuffer();
        msg.append("删除项目：");
        for (String id : idArray) {
            Etprojinfo project = projectService.findByIdOrUnique(id);
            if (project != null) {
                msg.append(project.getFprojname() + "(" + id + ")，");
            }
        }

        projectService.batchDelete(Arrays.asList(idArray));
        logger.info(msg.toString());

        return AjaxReturnBean.createSuccess("删除成功！");
    }


}
