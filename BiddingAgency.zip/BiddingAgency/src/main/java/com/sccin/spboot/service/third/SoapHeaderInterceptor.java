package com.sccin.spboot.service.third;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.headers.Header;
import org.apache.cxf.helpers.DOMUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import java.util.List;

/**
 * 调用WCF时，自定义拦截器
 * 生成soap头
 */
public class SoapHeaderInterceptor extends AbstractPhaseInterceptor<SoapMessage> {
    /**
     * soap头用户名
     */
    private String OperationUserName;
    /**
     * soap头密码
     */
    private String OperationPwd;
    /**
     * soap头用户名的节点名
     */
    private String OperationUserNameType;
    /**
     * soap头密码的节点名
     */
    private String OperationUPwsType;

    public SoapHeaderInterceptor(String username, String password, String usertype, String passtype) {
        super(Phase.PREPARE_SEND);
        this.OperationUserName = username;
        this.OperationPwd = password;
        this.OperationUserNameType = usertype;
        this.OperationUPwsType = passtype;
    }

    @Override
    public void handleMessage(SoapMessage message) throws Fault {
        // TODO Auto-generated method stub
        List<Header> headers = message.getHeaders();
        String userN = "tns:" + this.OperationUserNameType;
        String passN = "tns:" + this.OperationUPwsType;
        //自定义节点
        Document doc = DOMUtils.createDocument();
        Element username = doc.createElement(userN);
        username.setAttribute("xmlns","http://www.sccin.usersystem.com");
        Element password = doc.createElement(passN);
        password.setAttribute("xmlns","http://www.sccin.usersystem.com");

        username.setTextContent(this.OperationUserName);
        password.setTextContent(this.OperationPwd);

        headers.add(0, new Header(new QName(userN),username));
        headers.add(1, new Header(new QName(passN),password));
    }


    public String getOperationUserNameType() {
        return OperationUserNameType;
    }
    public void setOperationUserNameType(String operationUserNameType) {
        this.OperationUserNameType = operationUserNameType;
    }
    public String getOperationUPwsType() {
        return OperationUPwsType;
    }
    public void setOperationUPwsType(String operationUPwsType) {
        this.OperationUPwsType = operationUPwsType;
    }
    public void setUsername(String username) {
        this.OperationUserName = username;
    }
    public void setPassword(String password) {
        this.OperationPwd = password;
    }

}
