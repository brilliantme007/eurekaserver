package com.sccin.spboot.web.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * Created by developer_hyaci on 2018/5/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UlifyUser {
    private String uid;         //如果为主账号此uid为userID，如果为子账号，此uid为parentUserID
    private String userID;      //用户ID
    private String userName;    //用户名
    private String linkMan;     //联系人
    private String linkPhone;   //联系电话
    private String registerDate;//注册时间
    private String userAreaID;  //用户所属地
    private String isParentUser;//是否是主账号,1表示主账号，0表示子账号
    private String parentUserID;//主账号ID，如果是主账号此ID为null
    private String userType;    //用户类型，1表示内部用户，0表示注册用户
    private String secretKey;
    private List<UlifyCaInfo> caInfo;       //CA信息
    private UlifyCompanyInfo companyInfo;   //主体信息
    private List<UlifyRole> role;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan;
    }

    public String getLinkPhone() {
        return linkPhone;
    }

    public void setLinkPhone(String linkPhone) {
        this.linkPhone = linkPhone;
    }

    public String getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(String registerDate) {
        this.registerDate = registerDate;
    }

    public String getUserAreaID() {
        return userAreaID;
    }

    public void setUserAreaID(String userAreaID) {
        this.userAreaID = userAreaID;
    }

    public String getIsParentUser() {
        return isParentUser;
    }

    public void setIsParentUser(String isParentUser) {
        this.isParentUser = isParentUser;
    }

    public String getParentUserID() {
        return parentUserID;
    }

    public void setParentUserID(String parentUserID) {
        this.parentUserID = parentUserID;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public List<UlifyCaInfo> getCaInfo() { return caInfo; }

    public void setCaInfo(List<UlifyCaInfo> caInfo) { this.caInfo = caInfo; }

    public UlifyCompanyInfo getCompanyInfo() { return companyInfo; }

    public void setCompanyInfo(UlifyCompanyInfo companyInfo) { this.companyInfo = companyInfo; }

    public List<UlifyRole> getRole() { return role; }

    public void setRole(List<UlifyRole> role) { this.role = role; }
}
