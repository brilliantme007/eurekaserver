package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.Roleauths;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RoleauthsReposityInter extends JpaRepository<Roleauths,String>, JpaSpecificationExecutor<Roleauths> {

    List<Roleauths> findByRoleidAndRolecode(String roleId, String roleCode);

    List<Roleauths> findByRoleid(String roleId);

    //角色授权--------------start
    @Query("select distinct new Roleauths(ro.roleid,ro.rolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.roleid ")
    Page<Roleauths> queryRoleauthsPage(Pageable pageable);

    @Query("select distinct new Roleauths(ro.roleid,ro.rolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.roleid and ro.rolecode =:roleCode and r.name =:roleNm")
    Page<Roleauths> queryRoleauthsPage(Pageable pageable, @Param("roleCode") String roleCode, @Param("roleNm") String roleNm);

    @Query("select distinct new Roleauths(ro.roleid,ro.rolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.roleid and ro.rolecode =:roleCode ")
    Page<Roleauths> queryRoleauthsByRoleCodePage(Pageable pageable, @Param("roleCode") String roleCode);

    @Query("select distinct new Roleauths(ro.roleid,ro.rolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.roleid and r.name =:roleNm ")
    Page<Roleauths> queryRoleauthsByRoleNmPage(Pageable pageable, @Param("roleNm") String roleNm);
    //角色授权--------------end
}
