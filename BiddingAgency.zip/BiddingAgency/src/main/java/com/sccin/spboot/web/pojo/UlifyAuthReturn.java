package com.sccin.spboot.web.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by developer_hyaci on 2018/5/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UlifyAuthReturn {
    private String success;
    private String message;
    private UlifyUser data;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UlifyUser getData() {
        return data;
    }

    public void setData(UlifyUser data) {
        this.data = data;
    }
}
