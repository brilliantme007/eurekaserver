package com.sccin.spboot.domain.moren;

import javax.persistence.*;
import java.util.Objects;

/**
 * Created by CPYF-Yi Mao on 2018-08-27.
 */
@Entity
@Table(name = "rnroleauths")
public class Roleauths {
    private String id;
    private String roleid;
    private String rolecode;
    private String authorityid;

    //冗余字段
    private String name;//角色名称

    public Roleauths(){}

    public Roleauths(String roleid,String rolecode,String name){
        this.roleid = roleid;
        this.rolecode = rolecode;
        this.name = name;
    }

    @Transient
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Id
    @Column(name = "fid", nullable = false, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "rroleid", nullable = true, length = 50)
    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }

    @Basic
    @Column(name = "crolecode", nullable = true, length = 50)
    public String getRolecode() {
        return rolecode;
    }

    public void setRolecode(String rolecode) {
        this.rolecode = rolecode;
    }

    @Basic
    @Column(name = "rauthorityid", nullable = true, length = 50)
    public String getAuthorityid() {
        return authorityid;
    }

    public void setAuthorityid(String authorityid) {
        this.authorityid = authorityid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Roleauths roleauths = (Roleauths) o;
        return Objects.equals(id, roleauths.id) &&
                Objects.equals(roleid, roleauths.roleid) &&
                Objects.equals(rolecode, roleauths.rolecode) &&
                Objects.equals(authorityid, roleauths.authorityid);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, roleid, rolecode, authorityid);
    }
}
