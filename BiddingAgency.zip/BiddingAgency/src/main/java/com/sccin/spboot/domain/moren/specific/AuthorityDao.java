package com.sccin.spboot.domain.moren.specific;

import org.springframework.security.access.ConfigAttribute;

import java.util.Collection;
import java.util.HashMap;

/**
 * Created by CPYF-Yi Mao on 2018-08-27.
 */
public interface AuthorityDao {

    /**
     * 获取全部权限furl -> roles
     * @return
     */
    HashMap<String, Collection<ConfigAttribute>> getAllSpecificAuthority();
}
