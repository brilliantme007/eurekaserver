package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etprojinfo;
import com.sccin.spboot.domain.agency.specific.ProjectDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 项目信息Inter
 *
 * @Author lijun
 */
@Repository
public interface EtprojinfoInter extends JpaRepository<Etprojinfo, String>, ProjectDao, JpaSpecificationExecutor<Etprojinfo> {
    /**
     * 按三方唯一标识查询一条项目
     * @param funique 三方唯一标识
     * @return optional结果
     * @author lijun
     */
    Optional<Etprojinfo> findFirstByFunique(String funique);

    /**
     * 按fid集合批量删除项目
     *
     * @param fids 项目fid集合
     * @author lijun
     */
    void deleteByFidIn(List<String> fids);

    /**
     * 通过fids查询project
     *
     * @param fids
     * @return java.util.List<com.sccin.spboot.domain.agency.Etprojinfo>
     * @author WHLiang
     * @date 2018-12-29 13:32
     */
    List<Etprojinfo> findByFidIn(List<String> fids);
}
