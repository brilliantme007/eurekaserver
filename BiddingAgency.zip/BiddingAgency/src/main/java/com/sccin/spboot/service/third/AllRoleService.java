package com.sccin.spboot.service.third;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sccin.spboot.config.SysConfig;
import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.domain.moren.repository.RoleReposityInter;
import com.sccin.spboot.service.third.dto.Request;
import com.sccin.spboot.service.third.dto.Response;
import com.sccin.spboot.service.third.dto.pld.Pld2004;
import com.sccin.spboot.service.third.dto.prm.Prm2004;
import com.sccin.spboot.utils.RemoteAccessUtil;
import com.sccin.spboot.utils.ThreeDESUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by developer_hyaci on 2016/6/23.
 */
@Component("allRoleService")
public class AllRoleService {

    private final static Logger logger = LoggerFactory.getLogger(AllRoleService.class);

    private final String METHOD = "DoUserWork";
    private static final String APINAME = "GetSystemRole";
    private static final Integer APICOD = 2004;

    @Autowired
    private SysConfig sysConfig;
    @Autowired
    private RoleReposityInter roleReposityInter;

    public List<Role> doRequest() throws Exception{
        final String thirdURL = sysConfig.getThridURL();
        if (StringUtils.isEmpty(thirdURL)) {
            throw new Exception("用户体系数据接口缺少url参数");
        }

        //构造请求对象
        Request<Prm2004> request = new Request<>();
        request.setCod(APICOD);
        request.setName(APINAME);
        String ts = UUID.randomUUID().toString();
        request.setTs(ts);
        request.setSig(ThreeDESUtil.encode(ts));
        if(sysConfig.getUlifyAreaid()==null|| sysConfig.getUlifyAreaid().equals("")
                ||sysConfig.getUlifySystemid()==null || sysConfig.getUlifySystemid().equals("")){
            throw new Exception("未能获取到用户体系设定的系统ID或者地区ID");
        }
        Prm2004 prm2004 = new Prm2004();
        prm2004.setAreaID(sysConfig.getUlifyAreaid());
        prm2004.setSystemID(sysConfig.getUlifySystemid());
        request.setPrm(prm2004);

        //请求对象转成json字符串
        String param;
        try {
            param = new ObjectMapper().writeValueAsString(request);
        } catch (JsonProcessingException e) {
            logger.error("与用户体系进行对接时传递给用户体系的参数转换失败，失败原因：" + e.getMessage());
            throw new Exception("与用户体系进行对接时传递给用户体系的参数转换失败");
        }

        //发送请求
        String result;
        try {
            // 调用方法,获取从用户体系中获取的值
            result = RemoteAccessUtil.wcfInit(thirdURL, METHOD, new SoapHeaderInterceptor(ThreeDESUtil.encode(
                    sysConfig.getSoapHeadUserName()), ThreeDESUtil.encode(sysConfig.getSoapHeadPassWord()),
                    sysConfig.getThirdUserName(), sysConfig.getThirdPassWord()), ThreeDESUtil.encode(param)).threeDESUtilRequest();
        } catch (Exception e) {
            logger.error("与用户体系进行对接时失败，对接时的数据为：" + param + ",失败原因：" + e.getMessage());
            throw new Exception("与用户体系进行对接时上送过程中出现异常");
        }

        if (StringUtils.isEmpty(request)) {
            return null;
        }

        //处理返回结果
        Response response = null;
        try {
            response = new ObjectMapper().readValue(result, Response.class);
        } catch (Exception e) {
            logger.error("从用户体系中获取的返回结果解析失败，参数为：" + result + "，失败原因：" + e.getMessage());
            throw new Exception("从用户体系中获取的返回结果解析失败");
        }

        if (response == null) {
            return null;
        } else if (response.getRet().longValue() != 0) {
            return null;
        } else if (response.getTs() == null || "".equals(response.getTs()) || response.getSig() == null
                || !response.getSig().equals(ThreeDESUtil.encode(response.getTs()))) {
            // 表示ts或sig不存在，数据可能被篡改
            logger.error("从用户体系中调用接口的数据被可能被篡改，可能被篡改的数据为：" + result);
            throw new Exception("从用户体系中调用接口的数据被可能被篡改");
        } else if (response.getPld() == null) {
            //未取得对应的数据集
            return null;
        } else {
            List<Pld2004> plds = response.getPld();
            return saveRolesFrom(plds);
        }
    }

    /**
     * 为防止因用户同一时间内多次点击导致数据多次保存，同步该方法
     */
    private synchronized List<Role> saveRolesFrom(List<Pld2004> plds) {
        List<Role> result = new ArrayList<>();

        for (Pld2004 pld : plds) {
            String localRoleCode = pld.getRoleID();
            Role old  = roleReposityInter.findByCode(localRoleCode);
            if (old == null) {
                Role role = new Role();
                role.setId(UUID.randomUUID().toString());
                role.setCode(localRoleCode);
                role.setName(pld.getRoleName());
                role.setTime(new Timestamp(System.currentTimeMillis()));
                roleReposityInter.saveAndFlush(role);
                result.add(role);
            }else{
                if(!old.getName().equals(pld.getRoleName())){
                    old.setName(pld.getRoleName());
                    old.setTime(new Timestamp(System.currentTimeMillis()));
                    roleReposityInter.saveAndFlush(old);
                    result.add(old);
                }
            }
        }

        return result;
    }
}
