package com.sccin.spboot.service.third.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sccin.spboot.service.third.dto.pld.Pld2004;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Response {
    /**
     * 为接口已约定好的方法ID
     */
    private Integer cod;
    /**
     * 0表示成功，非0表示失败，与msg对应
     */
    private Integer ret;
    /**
     * 调用结果文字说明
     */
    private String msg;
    /**
     * 对应方法名
     */
    private String name;
    /**
     * 加密字段，确保消息没有被篡改
     */
    private String sig;
    /**
     * 仅客户端和服务器交互使用
     */
    private String ts;
    /**
     * 返回数据集
     */
    private List<Pld2004> pld;

    public Integer getCod() {
        return cod;
    }

    public void setCod(Integer cod) {
        this.cod = cod;
    }

    public Integer getRet() {
        return ret;
    }

    public void setRet(Integer ret) {
        this.ret = ret;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSig() {
        return sig;
    }

    public void setSig(String sig) {
        this.sig = sig;
    }

    public String getTs() {
        return ts;
    }

    public void setTs(String ts) {
        this.ts = ts;
    }

    public List<Pld2004> getPld() {
        return pld;
    }

    public void setPld(List<Pld2004> pld) {
        this.pld = pld;
    }
}

