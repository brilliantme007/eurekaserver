package com.sccin.spboot.service.back;

import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.domain.moren.Roleauths;
import com.sccin.spboot.domain.moren.Userrole;
import com.sccin.spboot.domain.moren.repository.RoleReposityInter;
import com.sccin.spboot.domain.moren.repository.RoleauthsReposityInter;
import com.sccin.spboot.domain.moren.repository.UserRoleReposityInter;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;

@Component("roleService")
public class RoleService {
    @Autowired
    private RoleReposityInter roleReposityInter;
    @Autowired
    private UserRoleReposityInter userRoleReposityInter;
    @Autowired
    private RoleauthsReposityInter roleauthsReposityInter;

    /**
     * 分页查询角色
     * @param roleNm 角色名称(模糊查询)
     * @param pageable
     * @return
     */
    public Page<Role> findRole(String roleNm, Pageable pageable) {
        boolean roleFlag = roleNm != null && !roleNm.trim().equals("");
        Page<Role> rolePage = null;
        if (roleFlag) {
            rolePage = roleReposityInter.queryRolePage(pageable, "%" + roleNm + "%");
        } else {
            rolePage = roleReposityInter.findAll(pageable);
        }
        return rolePage;
    }


    //设置权限前获取角色
    public List<Role> findByRoleId(String roleId) {
        List<Role> listRoles = new ArrayList<>();
        if (roleId != null && !roleId.trim().equals("")) {
            listRoles.add(roleReposityInter.getOne(roleId));
        } else {
            listRoles = roleReposityInter.findAll();
        }
        return listRoles;
    }

    /**
     * 新增或是修改role
     * @param paramMap   roleName,roleCode,fid(修改时候传入)
     * @return
     */
    @Transactional
    public AjaxReturnBean addRole(Map<String,String> paramMap) {
        String roleName = paramMap.get("roleName");
        String roleCode = paramMap.get("roleCode");
        String fid = paramMap.get("fid");
        boolean rolenameFlag = roleName != null && !"".equals(roleName.trim());
        boolean roleCodeFlag = roleCode != null && !"".equals(roleCode.trim());
        boolean fidFlag = fid != null && !"".equals(fid.trim());
        AjaxReturnBean result=null;
        Role role = new Role();
        if(rolenameFlag && roleCodeFlag){
            if(fidFlag){
                //角色修改（角色编码禁止修改）
                Optional<Role> byId = roleReposityInter.findById(fid);
                Role tmpRole =byId.isPresent()?byId.get():null;
                if(tmpRole==null){
                    return AjaxReturnBean.createError("角色不存在",null);
                }
                if (!roleCode.equals(tmpRole.getCode())) {
                    //returnMap.put("msg","角色编码是唯一存在项，禁止修改");
                    return AjaxReturnBean.createError("角色编码是唯一存在项，禁止修改",null);
                }
            }else{
                //判断该角色是否已经存在
                Role tmpRole = this.roleReposityInter.findByCode(roleCode);
                if(tmpRole != null){
                    //returnMap.put("msg","角色编码是唯一存在项，该角色编码已经存在，请确认后重新添加");
                    return AjaxReturnBean.createError("角色编码是唯一存在项，该角色编码已经存在，请确认后重新添加",null);
                }
            }
            role.setCode(roleCode);
            role.setName(roleName);
            role.setTime(Timestamp.valueOf(LocalDateTime.now()));
        }else{
            //returnMap.put("msg","存在必填项为空，请填写后重新添加");
            return AjaxReturnBean.createError("存在必填项为空，请填写后重新添加",null);
        }

        if(fidFlag){
            role.setId(fid);
        }else{
            role.setId(UUID.randomUUID().toString());
        }

        String returnMsg = "";
        //保存数据,添加try catch捕捉数据保存异常
        try{
            this.roleReposityInter.save(role);
            returnMsg = "success";
            result=AjaxReturnBean.createSuccess(returnMsg,null);
        }catch (Exception e){
            if(fidFlag){
                returnMsg = "修改角色失败，请重试";
            }else{
                returnMsg = "添加角色失败，请重试";
            }
            result=AjaxReturnBean.createError(returnMsg,null);
        }
        return result;
    }

    /**
     *  删除角色
     * @param fid 角色fid
     * @return
     */
    @Transactional
    public AjaxReturnBean deleteRole(String fid) {
        boolean fidFlag = fid != null && !fid.trim().equals("");
        AjaxReturnBean result=null;
        String returnMsg = "";
        if(fidFlag){
            //获取要删除的对象
            Optional<Role> byId = roleReposityInter.findById(fid);
            Role tmpRole =byId.isPresent()?byId.get():null;
            if(tmpRole==null){
                return AjaxReturnBean.createError("角色不存在",null);
            }
            //判断该角色是否能够删除
            if(tmpRole.getCode().equals("admin")){
                //returnMap.put("msg","管理员角色不能被删除");
                return AjaxReturnBean.createError("管理员角色不能被删除",null);
            }

            //判断该角色是否已经绑定用户
            List<Userrole> userrole = this.userRoleReposityInter.findByRoleid(fid);
            if( userrole.size()>0 && userrole != null ){
                //returnMap.put("msg","该角色已被用户使用,请先解除与用户之间的关系后再删除");
                return AjaxReturnBean.createError("该角色已被用户使用,请先解除与用户之间的关系后再删除",null);
            }
            //判断角色是否有权限，有权限应先删除权限
            List<Roleauths> lstRoleauths = this.roleauthsReposityInter.findByRoleidAndRolecode(tmpRole.getId(),tmpRole.getCode());
            if( lstRoleauths.size()>0 && lstRoleauths != null ){
                // returnMap.put("msg","该角色已被赋予权限,请先解除该角色的权限后再删除");
                return AjaxReturnBean.createError("该角色已被赋予权限,请先解除该角色的权限后再删除",null);
            }
            //删除角色
            try{
                this.roleReposityInter.delete(tmpRole);
                returnMsg = "success";
                result=AjaxReturnBean.createSuccess(returnMsg,null);
            }catch (Exception e){
                returnMsg = "角色删除失败";
                result=AjaxReturnBean.createError(returnMsg,null);
            }

        }else{
            returnMsg = "未传递唯一标识";
            result=AjaxReturnBean.createError(returnMsg,null);
        }
        return result;
    }

    /**
     * 通过fid 查询角色
     * @param fid
     * @return
     */
    public AjaxReturnBean getRoleById(String fid) {
        AjaxReturnBean result=null;
        String returnMsg = "";
        if(fid != null && !fid.trim().equals("")){
            Optional<Role> byId = roleReposityInter.findById(fid);
            Role role =byId.isPresent()?byId.get():null;
            if(role==null){
                return AjaxReturnBean.createError("角色不存在",null);
            }
            returnMsg = "success";
            result = AjaxReturnBean.createSuccess(returnMsg, role);
        } else{
            returnMsg = "唯一标识未传递";
            result=AjaxReturnBean.createError(returnMsg,null);
        }
        return result;
    }

    public List<Role> queryAllRole() {
        return roleReposityInter.findAll();
    }

    public Role querRoleByCode(String code) {
        return roleReposityInter.queryRoleByCode(code);
    }

    public List<Userrole> queryUserRoleByUserId(String userId) {
        return userRoleReposityInter.queryRoleByCode(userId);
    }

    public List<Role> findByCodeIn(Collection<String> codes){
        return roleReposityInter.findByCodeIn(codes);
    }
}
