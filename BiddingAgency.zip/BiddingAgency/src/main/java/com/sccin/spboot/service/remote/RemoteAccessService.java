//package com.sccin.spboot.service.back;
//import com.sccin.spboot.section.pojo.RemoteAccessResultDto;
//import com.sccin.spboot.config.SysConfig;
//import com.sccin.spboot.utils.RemoteAccessUtil;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.context.WebApplicationContext;
//
//import java.util.Map;
//
///**
// * 远程访问外部统一实现入口（本service中所有方法会使用切面增强以控制访问失败重发问题）
// *
// * 方法返回统一为：RemoteAccessResultDto
// * 方法参数除必要实体对象外，尽量有用才传，且小量级传递
// * 具体业务处理应放在其他service层处理，本层只做外部访问
// */
//@Service("remoteAccessService")
//public class RemoteAccessService {
//
//    private static Logger logger = LoggerFactory.getLogger(RemoteAccessService.class);
//
//    @Autowired
//    private SysConfig sysConfig;
//    @Autowired
//    private WebApplicationContext webApplicationContext;
//
//    private ObjectMapper objectMapper = new ObjectMapper();
//
//    /**
//     * 回馈数据中心审核结果
//     * @param callBackDto
//     */
//    public RemoteAccessResultDto callBackDataCenter(AccessCenterAuditDto callBackDto){
//        //赋值unique
//        if(callBackDto.pass()){   //审核通过设置url
//            callBackDto.setUrl(sysConfig.getProjectHost()+webApplicationContext.getServletContext().getContextPath()+
//                    "/pub/indexContent_"+callBackDto.getId()+".html");
//        }
//
//        try {
//            String result = RemoteAccessUtil.restInit(sysConfig.getRemoteDataCenterHost(), objectMapper.writeValueAsString(callBackDto)).recvBackStr();
//            Map resultMap = objectMapper.readValue(result, Map.class);
//            boolean resp = resultMap.containsKey("success") ? Boolean.valueOf(resultMap.get("success").toString()) : false;
//            if(!resp){  //失败
//                String message = resultMap.containsKey("message") ? resultMap.get("message").toString() : "";
//                return RemoteAccessResultDto.buildFailed(message,sysConfig.getRemoteDataCenterHost(),logger);
//            }
//        } catch (Exception e) {
//            return RemoteAccessResultDto.buildFailed("唯一标识："+callBackDto.getId()+" 回馈数据中心审核结果异常："+e.getMessage(),sysConfig.getRemoteDataCenterHost(),logger);
//        }
//
//        return RemoteAccessResultDto.buildSuccess();
//    }
//}
