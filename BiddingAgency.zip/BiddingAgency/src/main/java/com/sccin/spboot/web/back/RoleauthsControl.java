package com.sccin.spboot.web.back;

import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.domain.moren.Roleauths;
import com.sccin.spboot.service.back.AuthorityService;
import com.sccin.spboot.service.back.RoleService;
import com.sccin.spboot.service.back.RoleauthsService;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 角色授权相关
 * @author Wang HLiang
 */
@Controller
public class RoleauthsControl{

    @Autowired
    private RoleauthsService roleauthsService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private AuthorityService authorityService;

    /**
     * 后台角色管理-设置角色权限页面
     * @param roleId 角色id
     * @param model
     * @return
     */
     @RequestMapping(value = "/role/roleAuthsSetting.html")
     public String roleAuthsSetting(@Param("roleId")String roleId, @Param("backShowKey")String backShowKey, @Param("backShowPage")Pageable pageable, Model model){
         //根据角色ID获取角色
         List<Role> rols = roleService.findByRoleId(roleId);
         List<Map<String,String>> mapList_roles = rols.stream().filter(role->{
             if(role.getCode().equals("ADMIN")){
                 return false;
             }
             return true;
         }).map(role->{
             Map<String, String> map = new HashMap<String, String>();
             map.put("roleId", role.getId());
             map.put("roleName", role.getName());
             map.put("roleCode", role.getCode());
             return map;
         }).collect(Collectors.toList());;

         //获取该角色已有权限
         List<Roleauths> roleauths = roleauthsService.findByRoleId(roleId);
         List<Map<String,Object>> authList_map=authorityService.changToListMap(authorityService.getAutoritys(), roleauths);

         //获取所有的后台权限
         List<Map<String,Object>> backAuths= authList_map.stream().filter(map -> {
             return map.get("auType").toString().equals("1");
         }).sorted((map1,map2)->{
             return ((Integer)map1.get("index")).compareTo((Integer) map2.get("index"));
         }).collect(Collectors.toList());

         //获取所有的前台管理权限
         List<Map<String,Object>> preManageAuths= authList_map.stream().filter(map -> {
             return map.get("auType").toString().equals("0");
         }).sorted((map1,map2)->{
             return ((Integer)map1.get("index")).compareTo((Integer) map2.get("index"));
         }).collect(Collectors.toList());

         //获取所有的前台权限
         List<Map<String,Object>> preAuths= authList_map.stream().filter(map -> {
             return map.get("auType").toString().equals("2");
         }).sorted((map1,map2)->{
             return ((Integer)map1.get("index")).compareTo((Integer) map2.get("index"));
         }).collect(Collectors.toList());

         model.addAttribute("roles",mapList_roles);
         model.addAttribute("roleSize", mapList_roles.size());

         model.addAttribute("preHide","0");
         if(mapList_roles.size()==1){
             if(mapList_roles.get(0).get("roleCode").indexOf("ADMIN")!=-1){
                 model.addAttribute("preHide","1");
             }
         }
         model.addAttribute("backAuths",backAuths);
         model.addAttribute("preAuths",preAuths);
         model.addAttribute("preManageAuths",preManageAuths);
         model.addAttribute("backShowKey",backShowKey);
         model.addAttribute("backShowPage",pageable);

         return "back/role/roleAuthsSetting";
     }


    /**
     * 保存设置的权限
     * @param roleId 角色id
     * @param roleCode 角色 code
     * @param auths 选择的权限id
     * @return
     */
     @RequestMapping(value = "/role/roleAuthsModify")
     @ResponseBody
     public AjaxReturnBean modifyRolePower(@Param("roleId")String roleId, @Param("roleCode")String roleCode, @Param("auths")String [] auths){
         try{
             roleauthsService.modifyRoleAuths(roleId,roleCode,auths);
             authorityService.syncCacheAuthortiy(); //同步缓存权限
         }catch (Exception e){
             return AjaxReturnBean.createError("授权失败!",null);
         }
         return AjaxReturnBean.createSuccess("授权成功!",null);
     }

}
