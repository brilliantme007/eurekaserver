package com.sccin.spboot.domain.agency;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "etprojinfo")
public class Etprojinfo {
    private String fid;
    private String fprojname;
    private String funique;
    private String fmkeys;
    private String fptype;
    private Timestamp fctime;
    private Timestamp futime;

    @Id
    @Column(name = "fid")
    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    @Basic
    @Column(name = "fprojname")
    public String getFprojname() {
        return fprojname;
    }

    public void setFprojname(String fprojname) {
        this.fprojname = fprojname;
    }

    @Basic
    @Column(name = "funique")
    public String getFunique() {
        return funique;
    }

    public void setFunique(String funique) {
        this.funique = funique;
    }

    @Basic
    @Column(name = "fmkeys")
    public String getFmkeys() {
        return fmkeys;
    }

    public void setFmkeys(String fmkeys) {
        this.fmkeys = fmkeys;
    }

    @Basic
    @Column(name = "fptype")
    public String getFptype() {
        return fptype;
    }

    public void setFptype(String fptype) {
        this.fptype = fptype;
    }

    @Basic
    @Column(name = "fctime")
    public Timestamp getFctime() {
        return fctime;
    }

    public void setFctime(Timestamp fctime) {
        this.fctime = fctime;
    }

    @Basic
    @Column(name = "futime")
    public Timestamp getFutime() {
        return futime;
    }

    public void setFutime(Timestamp futime) {
        this.futime = futime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Etprojinfo that = (Etprojinfo) o;
        return Objects.equals(fid, that.fid) &&
                Objects.equals(fprojname, that.fprojname) &&
                Objects.equals(funique, that.funique) &&
                Objects.equals(fmkeys, that.fmkeys) &&
                Objects.equals(fptype, that.fptype) &&
                Objects.equals(fctime, that.fctime) &&
                Objects.equals(futime, that.futime);
    }

    @Override
    public int hashCode() {

        return Objects.hash(fid, fprojname, funique, fmkeys, fptype, fctime, futime);
    }

}
