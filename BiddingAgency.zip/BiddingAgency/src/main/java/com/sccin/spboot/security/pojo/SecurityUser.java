package com.sccin.spboot.security.pojo;

import com.sccin.spboot.config.SysConfig;
import com.sccin.spboot.domain.moren.Authority;
import com.sccin.spboot.domain.moren.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SecurityUser implements UserDetails {

	private static final long serialVersionUID = -2850148622557170441L;

	private User loginUser;	//用户信息

	private SysConfig sysConfig;

	private static ArrayList<DefineAuthItem> authsTree = new ArrayList<>();	//后台树形权限

	private List<Authority> auths;	//全部权限数据

	private List<DefineGrantedAuthority> authorities;	//角色信息


	public SecurityUser(User user,List<DefineGrantedAuthority> authorities){
		this.loginUser=user;
		this.authorities = authorities;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	public void qrySubByAuthItem(DefineAuthItem authItem){
		for(int i=0;i<auths.size();i++){
			if(auths.get(i).getParent()!=null
					&& !(auths.get(i).getParent().equals(""))
					&& auths.get(i).getParent().equals(authItem.getAuthorityBean().getId())){
				DefineAuthItem sub=new DefineAuthItem(auths.get(i));
				this.qrySubByAuthItem(sub);
				authItem.getSubAuth().add(sub);
			}
		}
	}

	/**
	 * 获得后台权限树形结构
	 * @return
	 */
	public ArrayList<DefineAuthItem> getAuthsTree() {
		if(authsTree.isEmpty()){
			if(auths!=null && auths.size()!=0){
				for(int i=0;i<auths.size();i++){
					//url 为0，type 1 为表示后台顶级菜单
					if(auths.get(i).getUrl().equals("0") && auths.get(i).getType().intValue() == 1){
						DefineAuthItem	authItem=new DefineAuthItem(auths.get(i));
						qrySubByAuthItem(authItem);
						authsTree.add(authItem);
					}
				}
			}
		}
		return authsTree;
	}

	/**
	 * 获得全部权限树形结构
	 * @return
	 */
	public List<DefineAuthItem> getAllAuthsTree() {
		List<DefineAuthItem> authTree = new ArrayList<>();
			if(auths!=null && auths.size()!=0){
				for(int i=0;i<auths.size();i++){
					DefineAuthItem authItem = new DefineAuthItem(auths.get(i));
					qrySubByAuthItem(authItem);
					authTree.add(authItem);
				}
			}
		return authTree;
	}

	public List<DefineAuthItem> getAuthsTreeByParentId(String id) {
		List<DefineAuthItem> authTree = new ArrayList<>();
		if(auths != null && auths.size()!=0) {
			for (Authority item : auths) {
				if (item.getId().equals(id)) {
					DefineAuthItem	authItem=new DefineAuthItem(item);
					qrySubByAuthItem(authItem);
					authTree.add(authItem);
					break;
				}
			}
		}
		return authTree;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.loginUser.getPasd();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return this.loginUser.getName();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		//账户是否已经登陆
/*		if(this.loginUser.getFailnum().intValue()==99){
			return false;
		}*/
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		//当前登陆用户登陆失败次数>10次，则半个小时不再允许再登陆
		if(this.loginUser.getFailnum().intValue()==10){
			LocalDateTime loclDateTime=this.loginUser.getLogtime().toLocalDateTime();
			String lockedTime = sysConfig.getAcountLockedTime();
			int lockedTimeIntValue = 30;
			if(lockedTime!=null && !lockedTime.trim().equals("") && !lockedTime.trim().equals("0")){
				lockedTimeIntValue=Integer.parseInt(lockedTime);
			}
			loclDateTime=loclDateTime.plusMinutes(lockedTimeIntValue);
			LocalDateTime now=LocalDateTime.now();
			if(now.compareTo(loclDateTime) < 0){
				return  false;
			}else{
				return  true;
			}
		}
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		//证书？
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		//当前登陆用户是否可用
		return this.loginUser.getIsvalid().intValue()==1?true:false;
	}

	public User getLoginUser() {
		return loginUser;
	}

	public String getCADN(){
		return loginUser.getCa();
	}

	public void setAuths(List<Authority> auths) {
		this.auths = auths;
	}

	public SecurityUser setSysConfig(SysConfig sysConfig) { this.sysConfig = sysConfig; return this;}

	//以下三个方法和Secrity中一个用户登陆之后，同一个用户再次登陆会挤掉前一个用户；
	@Override
	public String toString() {
		return this.loginUser.getId();
	}

	@Override
	public int hashCode() {
		return this.loginUser.getId().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this.toString().equals(obj.toString());
	}

}
