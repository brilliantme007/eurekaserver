package com.sccin.spboot.domain.moren.specific;

import com.sccin.spboot.domain.moren.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * Created by yx on 2018/8/27.
 */
public interface UserDao {

    Page<User> queryUserList(String userName, Pageable pageable);

    Map<String,String> queryRoleNames(List<String> userIdList);

    User findUserById(String userId);

    List<User> getUserByParams(String userName, String uerloginName);

    List<Map<String,String>> getUserByRoleIds(String roleIds);

    List<Map<String,String>> getUserHadAuthority(Map<String, Object> params);
}
