package com.sccin.spboot.web.endpoint.impl;

import com.sccin.spboot.domain.agency.Etprojinfo;
import com.sccin.spboot.service.front.EtagencyService;
import com.sccin.spboot.service.front.ProjectService;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.web.endpoint.interfaces.ProjectExtractService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.jws.WebService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author LiJunhao
 */
@Component
@WebService(serviceName = "ProjectExtractService",
            portName = "ProjectExtractServicePort",
            targetNamespace = "http://interfaces.endpoint.web.spboot.sccin.com",
            endpointInterface = "com.sccin.spboot.web.endpoint.interfaces.ProjectExtractService")
public class ProjectExtractServiceImpl implements ProjectExtractService {

    private static Logger LOGGER  = LoggerFactory.getLogger(ProjectExtractServiceImpl.class);

    @Autowired
    private ProjectService projectService;

    @Autowired
    private EtagencyService agencyService;

    @Override
    public String ExtractAgency(String XMLStr, String judge) {
        List<Map<String,Object>> parsedStr = Statements.getProject(new StringBuilder(XMLStr));
        String projName = "";
        String projType = "";
        for (Map<String, Object> infoMap : parsedStr) {
            if (infoMap.containsKey("attr") && infoMap.get("attr") != null) {
                if ("projName".equals(((Map)infoMap.get("attr")).get("key"))) {
                    projName = (String) ((Map)infoMap.get("attr")).get("value");
                }
                if ("projType".equals(((Map)infoMap.get("attr")).get("key"))) {
                    projType = (String) ((Map)infoMap.get("attr")).get("value");
                }
            }
        }
        Map<String, String> projParam = new HashMap<>();
        projParam.put("fprojname", projName);
        projParam.put("fptype", projType);
        Etprojinfo projInfo = projectService.addOrUpdate(projParam);
        String company = agencyService.agencyExtractionResult(projInfo.getFid());
        return company;
    }
}
