package com.sccin.spboot.web.back;


import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.service.back.RoleService;
import com.sccin.spboot.service.third.AllRoleService;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Wang HLiang
 */
@Controller
public class RoleControl{
    /**
     * 角色列表分页默认大小
     */
    public final int PAGESIZE=20;

    @Autowired
    private RoleService roleService;

    @Autowired
    private AllRoleService allRoleService;

    /**
     * 后天角色管理-角色列表
     * @param pageable
     * @param frole 角色code
     * @param model
     * @return
     */
    @RequestMapping("/role/paramsRole.html")
    public String searchPageRole(@PageableDefault(value = PAGESIZE,sort ={"time"}, direction = Sort.Direction.DESC) Pageable pageable, @Param("frole") String frole, Model model) {
        //根据角色Code获取角色
        Page<Role> roles = roleService.findRole(frole,pageable);

        if(roles == null || roles.getContent().size() == 0){
            model.addAttribute("roles","");
        }else{
            model.addAttribute("roles",roles.getContent());
        }

        model.addAttribute("page",pageable.getPageNumber()+1);
        model.addAttribute("total",roles.getTotalPages());
        model.addAttribute("frole",frole);
        return "back/role/roleList";
    }


    /**
     * 后台角色管理-添加或修改角色
     * @param fid       角色唯一标识
     * @param roleName  角色名称
     * @param roleCode  角色code
     * @return
     */
    @RequestMapping("/role/addRole")
    public @ResponseBody
    AjaxReturnBean addRole(@Param("fid") String fid, @Param("roleName") String roleName, @Param("roleCode") String roleCode){
       Map<String, String> paramMap = new HashMap<String, String>();
        paramMap.put("fid",fid);
        paramMap.put("roleName",roleName);
        paramMap.put("roleCode",roleCode);
        return this.roleService.addRole(paramMap);
    }

    /**
     * 后台角色管理-删除角色
     * @param fid
     * @return
     */
    @RequestMapping("/role/deleteRole")
    public @ResponseBody
    AjaxReturnBean delRole(@Param("fid") String fid){
        AjaxReturnBean result = this.roleService.deleteRole(fid);
        return result;
    }

    /**
     * 后台角色管理-获取角色详情
     * @param fid
     * @return
     */
    @RequestMapping("/role/detailRole")
    public @ResponseBody
    AjaxReturnBean detailRole(@Param("fid") String fid){
        AjaxReturnBean result=this.roleService.getRoleById(fid);
        return result;
    }

    /**
     * 从用户体系数据接口获取所有角色（根据地区和系统获取）
     */
    @RequestMapping("/pub/getListFromThird")
    public @ResponseBody AjaxReturnBean getListFromThird() {
        AjaxReturnBean result;

        List<Role> roles=null;
        try{
            roles = allRoleService.doRequest();
        }catch (Exception e){
            result = AjaxReturnBean.createError(e.getMessage());
            return result;
        }
        if (roles == null) {
            result = AjaxReturnBean.createError("获取到角色列表为NULL");
        } else if (roles.isEmpty()) {
            result = AjaxReturnBean.createError("本次未能获取到需要更新的角色列表");
        } else {
            result = AjaxReturnBean.createSuccess("本次更新角色列表" + roles.size() + "条");
        }

        return result;
    }
}
