package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.Userrole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by yx on 2017/10/18.
 */
public interface UserRoleReposityInter extends JpaRepository<Userrole,String>, JpaSpecificationExecutor<Userrole> {

    @Query("select r FROM Userrole r where r.userid =:userId ")
    List<Userrole> queryRoleByCode(@Param("userId") String userId);

    List<Userrole> findByRoleid(String roleId);


    @Query("SELECT new Userrole(u.id,u.userid,u.roleid,u.rolecode,r.name) FROM Userrole u,Role r WHERE u.roleid = r.id AND u.userid =:userId")
    List<Userrole> queryUserroleByUserid(@Param("userId") String userId);
}
