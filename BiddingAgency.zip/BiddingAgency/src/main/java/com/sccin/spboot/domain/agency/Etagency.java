package com.sccin.spboot.domain.agency;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "etagency")
public class Etagency {
    private String fid;
    private String fepname;
    private String fscc;
    private String faddress;
    private String fphone;
    private String flinkman;
    private String fsex;
    private String fduty;
    private String ragencylevelid;
    private Integer findex;
    private Integer fstate;
    private Integer fchoosecount;
    private Timestamp fusetime;
    private Integer fbidcount;

    // 冗余
    private Integer flevel;
    private String fname;

    @Id
    @Column(name = "fid")
    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    @Basic
    @Column(name = "fepname")
    public String getFepname() {
        return fepname;
    }

    public void setFepname(String fepname) {
        this.fepname = fepname;
    }

    @Basic
    @Column(name = "fscc")
    public String getFscc() {
        return fscc;
    }

    public void setFscc(String fscc) {
        this.fscc = fscc;
    }

    @Basic
    @Column(name = "faddress")
    public String getFaddress() {
        return faddress;
    }

    public void setFaddress(String faddress) {
        this.faddress = faddress;
    }

    @Basic
    @Column(name = "fphone")
    public String getFphone() {
        return fphone;
    }

    public void setFphone(String fphone) {
        this.fphone = fphone;
    }

    @Basic
    @Column(name = "flinkman")
    public String getFlinkman() {
        return flinkman;
    }

    public void setFlinkman(String flinkman) {
        this.flinkman = flinkman;
    }

    @Basic
    @Column(name = "fsex")
    public String getFsex() {
        return fsex;
    }

    public void setFsex(String fsex) {
        this.fsex = fsex;
    }

    @Basic
    @Column(name = "fduty")
    public String getFduty() {
        return fduty;
    }

    public void setFduty(String fduty) {
        this.fduty = fduty;
    }

    @Basic
    @Column(name = "ragencylevelid")
    public String getRagencylevelid() {
        return ragencylevelid;
    }

    public void setRagencylevelid(String ragencylevelid) {
        this.ragencylevelid = ragencylevelid;
    }

    @Basic
    @Column(name = "findex")
    public Integer getFindex() {
        return findex;
    }

    public void setFindex(Integer findex) {
        this.findex = findex;
    }

    @Basic
    @Column(name = "fstate")
    public Integer getFstate() {
        return fstate;
    }

    public void setFstate(Integer fstate) {
        this.fstate = fstate;
    }

    @Basic
    @Column(name = "fchoosecount")
    public Integer getFchoosecount() {
        return fchoosecount;
    }

    public void setFchoosecount(Integer fchoosecount) {
        this.fchoosecount = fchoosecount;
    }

    @Basic
    @Column(name = "fusetime")
    public Timestamp getFusetime() {
        return fusetime;
    }

    public void setFusetime(Timestamp fusetime) {
        this.fusetime = fusetime;
    }

    @Basic
    @Column(name="fbidcount")
    public Integer getFbidcount() {
        return fbidcount;
    }

    public void setFbidcount(Integer fbidcount) {
        this.fbidcount = fbidcount;
    }

    @Transient
    public Integer getFlevel() {
        return flevel;
    }

    public void setFlevel(Integer flevel) {
        this.flevel = flevel;
    }

    @Transient
    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Etagency etagency = (Etagency) o;
        return Objects.equals(fid, etagency.fid) &&
                Objects.equals(fepname, etagency.fepname) &&
                Objects.equals(fscc, etagency.fscc) &&
                Objects.equals(faddress, etagency.faddress) &&
                Objects.equals(fphone, etagency.fphone) &&
                Objects.equals(flinkman, etagency.flinkman) &&
                Objects.equals(fsex, etagency.fsex) &&
                Objects.equals(fduty, etagency.fduty) &&
                Objects.equals(ragencylevelid, etagency.ragencylevelid) &&
                Objects.equals(findex, etagency.findex) &&
                Objects.equals(fstate, etagency.fstate) &&
                Objects.equals(fchoosecount, etagency.fchoosecount) &&
                Objects.equals(fusetime, etagency.fusetime);
    }

    @Override
    public int hashCode() {

        return Objects.hash(fid, fepname, fscc, faddress, fphone, flinkman, fsex, fduty, ragencylevelid, findex, fstate, fchoosecount, fusetime);
    }
}
