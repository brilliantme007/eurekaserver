package com.sccin.spboot.domain.agency;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "etagencylevel")
public class Etagencylevel {
    private String fid;
    private String fname;
    private Integer flevel;

    @Id
    @Column(name = "fid")
    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    @Basic
    @Column(name = "fname")
    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    @Basic
    @Column(name = "flevel")
    public Integer getFlevel() {
        return flevel;
    }

    public void setFlevel(Integer flevel) {
        this.flevel = flevel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Etagencylevel that = (Etagencylevel) o;
        return Objects.equals(fid, that.fid) &&
                Objects.equals(fname, that.fname) &&
                Objects.equals(flevel, that.flevel);
    }

    @Override
    public int hashCode() {

        return Objects.hash(fid, fname, flevel);
    }
}
