package com.sccin.spboot.security;

import com.sccin.spboot.security.pojo.SecurityUser;
import com.sccin.spboot.utils.RSAUtils;
import com.sccin.spboot.utils.Statements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.security.interfaces.RSAPrivateKey;

/**
 * Created by developer_hyaci on 2016/2/17.
 * 登陆用户的认证
 */
@Component
public class DefineAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {
    @Autowired
    LoginUserDetailsService userDetailsService;

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken) throws AuthenticationException {
        String value_pwd =(String) usernamePasswordAuthenticationToken.getCredentials();

        RSAPrivateKey rSAPrivateKey= Statements.getRSAPrivateKey();
        try {
            value_pwd = RSAUtils.decryptByPrivateKey(value_pwd, rSAPrivateKey);
        } catch (Exception e) {
            throw new BadCredentialsException("密码解析出错，请使用正确的方式登录");
        }
        SecurityUser securityUser=(SecurityUser)userDetails;

        //认证逻辑
        String errorMsg = "默认校验不通过";//默认消息

        boolean verifyFlag = userDetailsService.verifyPasd(securityUser.getPassword(),value_pwd);

        if(!verifyFlag){
            errorMsg ="密码校验不通过";
        }

        if(!verifyFlag) {
            throw new BadCredentialsException("认证失败："+errorMsg);
        }
    }

    @Override
    protected UserDetails retrieveUser(String s, UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken) throws AuthenticationException {
        return userDetailsService.loadUserByUsername(s);
    }
}
