package com.sccin.spboot.security;

import com.sccin.spboot.utils.Statements;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by developer_hyaci on 2017/10/17.
 */
@Component
public class LogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {

    public static final String NORMALSESSIONCLOSE="logout_sessionClose_flag";

    @Override
    public void onLogoutSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
        this.setDefaultTargetUrl(Statements.LOGOUTSUCCESSURL);
        this.setAlwaysUseDefaultTargetUrl(true);

        super.onLogoutSuccess(httpServletRequest, httpServletResponse, authentication);

    }
}
