package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.RepushAgain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

/**
 * Created by jun.li on 2018/4/26.
 */
public interface RepushAgainReposityInter extends JpaRepository<RepushAgain, String>, JpaSpecificationExecutor<RepushAgain> {

    @Query(value="SELECT fid,fparams,fparamtypes,fdomain,fmethod,fdescrible,fcreatime FROM etrepushagain WHERE fid = :id",nativeQuery = true)
    RepushAgain findOne(String id);

    @Query(value="DELETE FROM etrepushagain WHERE fid = :id",nativeQuery = true)
    void delete(String id);
}
