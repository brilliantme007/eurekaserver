package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.specific.UserDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

/**
 * Created by yx on 2018/8/27.
 */
public interface UserReposityInter extends JpaRepository<User,String>,UserDao,JpaSpecificationExecutor {
      User findByLoginame(String loginName);
      User findByBusysunique(String busysunique);

      @Modifying
      @Query("update User u set u.failnum = 0 where u.failnum = 99")
      void initUserLoginStateAtStartUp();



}
