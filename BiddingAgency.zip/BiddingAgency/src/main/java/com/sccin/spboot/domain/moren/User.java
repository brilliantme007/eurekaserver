package com.sccin.spboot.domain.moren;

import com.sccin.spboot.utils.Utility;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;

/**
 * Created by developer_hyaci on 2017/10/13.
 */
@Entity
@Table(name = "etuser")
public class User {
    private String id;
    private String name;
    private String loginame;
    private String pasd;
    private String ca;
    private String realname;
    private String email;
    private String phone;
    private Integer failnum;
    private Timestamp logtime;
    private Integer isvalid;
    private Integer issys;
    private String busysunique;
    private String expend;

    //角色名称
    private String roleName;
    //冗余角色code列表
    private Set<String> roleCodes;
    //上次登录时间
    private Timestamp lastlogintime;
    //数据权限
    private String dataAuth;
    //数据对应地区名称
    private String areaName;

    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "fname", nullable = true, insertable = true, updatable = true, length = 128)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "floginame", nullable = true, insertable = true, updatable = true, length = 128)
    public String getLoginame() {
        return loginame;
    }

    public void setLoginame(String loginame) {
        this.loginame = loginame;
    }

    @Basic
    @Column(name = "fpasd", nullable = true, insertable = true, updatable = true, length = 256)
    public String getPasd() {
        return pasd;
    }

    public void setPasd(String pasd) {
        this.pasd = pasd;
    }

    @Basic
    @Column(name = "fca", nullable = true, insertable = true, updatable = true, length = 256)
    public String getCa() {
        return ca;
    }

    public void setCa(String ca) {
        this.ca = ca;
    }

    @Basic
    @Column(name = "frealname", nullable = true, insertable = true, updatable = true, length = 50)
    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    @Basic
    @Column(name = "femail", nullable = true, insertable = true, updatable = true, length = 50)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "fphone", nullable = true, insertable = true, updatable = true, length = 50)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Basic
    @Column(name = "ffailnum", nullable = true, insertable = true, updatable = true)
    public Integer getFailnum() {
        return failnum;
    }

    public void setFailnum(Integer failnum) {
        this.failnum = failnum;
    }

    @Basic
    @Column(name = "flogtime", nullable = true, insertable = true, updatable = true)
    public Timestamp getLogtime() {
        return logtime;
    }

    public void setLogtime(Timestamp logtime) {
        this.logtime = logtime;
    }

    @Basic
    @Column(name = "fisvalid", nullable = true, insertable = true, updatable = true)
    public Integer getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(Integer isvalid) {
        this.isvalid = isvalid;
    }

    @Basic
    @Column(name = "fissys", nullable = true, insertable = true, updatable = true)
    public Integer getIssys() {
        return issys;
    }

    public void setIssys(Integer issys) {
        this.issys = issys;
    }

    @Basic
    @Column(name = "fbusysunique", nullable = true, insertable = true, updatable = true, length = 100)
    public String getBusysunique() {
        return busysunique;
    }

    public void setBusysunique(String busysunique) {
        this.busysunique = busysunique;
    }

    @Basic
    @Column(name = "fexpend")
    public String getExpend() { return expend; }

    public void setExpend(String expend) {
        this.expend = expend;
        //设置数据权限
        if(!StringUtils.isEmpty(expend) && expend.contains("areaCode:")){
            this.setDataAuth(Utility.getFexpendByKey(expend, "areaCode"));
        }else {
            this.setDataAuth(null);
        }
    }

    @Transient
    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Transient
    public Set<String> getRoleCodes() { return roleCodes; }

    public void setRoleCodes(Set<String> roleCodes) { this.roleCodes = roleCodes; }

    @Transient
    public Timestamp getLastlogintime() {
        return lastlogintime;
    }

    public void setLastlogintime(Timestamp lastlogintime) {
        this.lastlogintime = lastlogintime;
    }

    @Transient
    public String getDataAuth() { return dataAuth; }

    public void setDataAuth(String dataAuth) { this.dataAuth = dataAuth; }

    @Transient
    public String getAreaName() { return areaName; }

    public void setAreaName(String areaName) { this.areaName = areaName; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        User user = (User) o;

        if (id != null ? !id.equals(user.id) : user.id != null) return false;
        if (name != null ? !name.equals(user.name) : user.name != null) return false;
        if (loginame != null ? !loginame.equals(user.loginame) : user.loginame != null) return false;
        if (pasd != null ? !pasd.equals(user.pasd) : user.pasd != null) return false;
        if (ca != null ? !ca.equals(user.ca) : user.ca != null) return false;
        if (realname != null ? !realname.equals(user.realname) : user.realname != null) return false;
        if (email != null ? !email.equals(user.email) : user.email != null) return false;
        if (phone != null ? !phone.equals(user.phone) : user.phone != null) return false;
        if (failnum != null ? !failnum.equals(user.failnum) : user.failnum != null) return false;
        if (logtime != null ? !logtime.equals(user.logtime) : user.logtime != null) return false;
        if (isvalid != null ? !isvalid.equals(user.isvalid) : user.isvalid != null) return false;
        if (issys != null ? !issys.equals(user.issys) : user.issys != null) return false;
        if (busysunique != null ? !busysunique.equals(user.busysunique) : user.busysunique != null) return false;
        if (expend != null ? !expend.equals(user.expend) : user.expend != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (loginame != null ? loginame.hashCode() : 0);
        result = 31 * result + (pasd != null ? pasd.hashCode() : 0);
        result = 31 * result + (ca != null ? ca.hashCode() : 0);
        result = 31 * result + (realname != null ? realname.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (failnum != null ? failnum.hashCode() : 0);
        result = 31 * result + (logtime != null ? logtime.hashCode() : 0);
        result = 31 * result + (isvalid != null ? isvalid.hashCode() : 0);
        result = 31 * result + (issys != null ? issys.hashCode() : 0);
        result = 31 * result + (busysunique != null ? busysunique.hashCode() : 0);
        result = 31 * result + (expend != null ? expend.hashCode() : 0);
        return result;
    }
}
