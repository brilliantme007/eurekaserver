package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etagency;
import com.sccin.spboot.domain.agency.specific.AgencyDao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by yx on 2018/12/27.
 */
public class EtagencyInterImpl implements AgencyDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Etagency> queryAgencyByCondition(Map<String, Object> param) {
        List<Etagency> result = new ArrayList<>();
        StringBuilder sb = new StringBuilder(" select t.fid,t.fepname,t.fscc,t.faddress,t.fphone,t.flinkman,t.fsex,t.fduty,t.findex ");
        sb.append(" FROM `etagency` t ");
        sb.append(" where 1= 1 ");
        if (param.get("pname") != null && !"".equals(param.get("pname").toString())) {
            sb.append(" and t.fepname like :pname ");
        }
        if (param.get("linkman") != null && !"".equals(param.get("linkman").toString())) {
            sb.append(" and t.flinkman like :linkman ");
        }
        sb.append(" limit :start, :limit ");
        Query query = entityManager.createNativeQuery(sb.toString());
        if (param.get("pname") != null && !"".equals(param.get("pname").toString())) {
            query.setParameter("pname", "%" + param.get("pname").toString() + "%");
        }
        if (param.get("linkman") != null && !"".equals(param.get("linkman").toString())) {
            query.setParameter("linkman", "%" + param.get("linkman").toString() + "%");
        }
        query.setParameter("limit", Integer.parseInt(param.get("limit").toString()));
        query.setParameter("start", Integer.parseInt(param.get("start").toString()));
        List<Object[]> objs = query.getResultList();
        if (objs != null && objs.size() > 0) {
            for (int i = 0; i < objs.size(); i++) {
                Object[] o = objs.get(i);
                Etagency agency = new Etagency();
                agency.setFid(String.valueOf(o[0]));
                agency.setFepname(String.valueOf(o[1]));
                agency.setFscc(String.valueOf(o[2]));
                agency.setFaddress(String.valueOf(o[3]));
                agency.setFphone(String.valueOf(o[4]));
                agency.setFlinkman(String.valueOf(o[5]));
                agency.setFsex(String.valueOf(o[6]));
                agency.setFduty(String.valueOf(o[7]));
                agency.setFindex(Integer.parseInt(String.valueOf(o[8])));
                result.add(agency);
            }
        }
        return result;
    }

    @Override
    public int countAgencyByCondition(Map<String, Object> param) {
        StringBuilder sb = new StringBuilder(" select t.fid,t.fepname,t.fscc,t.faddress,t.fphone,t.flinkman,t.fsex,t.fduty,t.findex ");
        sb.append(" FROM `etagency` t ");
        sb.append(" where 1= 1 ");
        if (param.get("pname") != null && !"".equals(param.get("pname").toString())) {
            sb.append(" and t.fepname like :pname ");
        }
        if (param.get("linkman") != null && !"".equals(param.get("linkman").toString())) {
            sb.append(" and t.flinkman like :linkman ");
        }
        Query query = entityManager.createNativeQuery(sb.toString());
        if (param.get("pname") != null && !"".equals(param.get("pname").toString())) {
            query.setParameter("pname", "%" + param.get("pname").toString() + "%");
        }
        if (param.get("linkman") != null && !"".equals(param.get("linkman").toString())) {
            query.setParameter("linkman", "%" + param.get("linkman").toString() + "%");
        }
        List<Object[]> objs = query.getResultList();
        return objs != null ? objs.size() : 0;
    }

    @Override
    public void insertAgencyByParam(Map<String, Object> param) {
        StringBuilder sb = new StringBuilder(200);
        Set<Map.Entry<String, Object>> entries = param.entrySet();
        int size = entries.size();
        int index = 0;
        sb.append("insert into etagency(");
        for (Map.Entry<String, Object> entry : entries) {
            sb.append(entry.getKey());
            index++;
            if (index < size) {
                sb.append(',');
            }
        }
        sb.append(") values(");
        index = 0;
        for (Map.Entry<String, Object> entry : entries) {
            sb.append(':').append(entry.getKey());
            index++;
            if (index < size) {
                sb.append(',');
            }
        }
        sb.append(")");
        Query query = entityManager.createNativeQuery(sb.toString());
        for (Map.Entry<String, Object> entry : entries) {
            String field = entry.getKey();
            Object value = entry.getValue();
            query.setParameter(field, value);
        }
        query.executeUpdate();
    }

    @Override
    public List<Etagency> getEtagencysNeedExtract() {
        String sql = "SELECT eta.fid,eta.fepname,eta.ragencylevelid,eta.fstate," +
                "eta.fchoosecount,eta.fusetime,etal.flevel,etal.fname,eta.findex,eta.fbidcount " +
                "FROM etagency eta,etagencylevel etal " +
                "where eta.ragencylevelid=etal.fid and eta.fstate=0 " +
                "and eta.ragencylevelid=etal.fid and etal.flevel in (1,2) " +
                "ORDER BY eta.findex ";
        Query query = entityManager.createNativeQuery(sql);
        List<Etagency> resultList = new ArrayList<>();
        if (query == null) {
            return resultList;
        }
        List<Object[]> objs = query.getResultList();
        if (objs != null && !objs.isEmpty()) {
            for (Object[] o : objs) {
                if (o != null) {
                    Etagency etagency = new Etagency();
                    etagency.setFid(String.valueOf(o[0]));
                    etagency.setFepname(String.valueOf(o[1]));
                    etagency.setRagencylevelid(String.valueOf(o[2]));
                    if (o[3]!=null){
                        etagency.setFstate(Integer.valueOf(String.valueOf(o[3])));
                    }else {
                        etagency.setFstate(0);
                    }
                    if (o[4]!=null){
                        etagency.setFchoosecount(Integer.valueOf(String.valueOf(o[4])));
                    }else {
                        etagency.setFchoosecount(0);

                    }
                    if(o[5]!=null){
                        etagency.setFusetime(Timestamp.valueOf(String.valueOf(o[5])));
                    }
                    if(o[6]!=null){
                        etagency.setFlevel(Integer.valueOf(String.valueOf(o[6])));
                    }
                    etagency.setFname(String.valueOf(o[7]));
                    etagency.setFindex(Integer.valueOf(String.valueOf(o[8])));
                    if(o[9]!=null){
                        etagency.setFbidcount(Integer.valueOf(String.valueOf(o[9])));
                    }
                    resultList.add(etagency);
                }
            }
        }
        return resultList;
    }
}
