package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.Areacodes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface AreacodesReposityInter extends JpaRepository<Areacodes,String>, JpaSpecificationExecutor<Areacodes> {

       Areacodes findByFcode(String code);

       List<Areacodes> findByFcodeIn(List<String> fcodes);

       List<Areacodes> findByFcodeLike(String code);

       List<Areacodes> findByFareaname(String areaName);
}
