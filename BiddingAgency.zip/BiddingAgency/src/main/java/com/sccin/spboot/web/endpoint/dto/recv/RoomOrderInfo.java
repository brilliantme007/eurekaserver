package com.sccin.spboot.web.endpoint.dto.recv;

import com.sccin.spboot.utils.ValidUtils;

/**
 * Created by CPYF-Yi Mao on 2018-09-27.
 */
public class RoomOrderInfo {

    @ValidUtils.Check(describe = "房间编号")
    private String roomno;           //房间唯一编号
    @ValidUtils.Check(describe = "预约开始时间",regex = ValidUtils.regex.datetime)
    private String stime;            //预约开始时间（yyyy-MM-dd HH:mm:ss）

    public String getRoomno() {
        return roomno;
    }

    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }

    public String getStime() {
        return stime;
    }

    public void setStime(String stime) {
        this.stime = stime;
    }
}
