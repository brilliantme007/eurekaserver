package com.sccin.spboot.domain.moren.specific;

import com.sccin.spboot.domain.moren.Fileinfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FileinfoDao {

    /**
     * 点击文件管理按钮后进入页面的查询
     * 输入条件查询文件
     * @param pageable
     * @param name       文件名
     * @param storename 储存名
     * @param suffix     后缀名
     * @param starTime      起始时间
     * @param endTime      结束时间
     * @author meiyufei
     * @time   2018.8.26. 10:56
     * @return
     */
    Page<Fileinfo> findFileinfoByPage(Pageable pageable, String name, String storename, String suffix, String starTime, String endTime);
}
