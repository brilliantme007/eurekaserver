package com.sccin.spboot.web.front;

import com.sccin.spboot.domain.agency.Etagency;
import com.sccin.spboot.domain.agency.Etagencylevel;
import com.sccin.spboot.service.front.AgencyLevelService;
import com.sccin.spboot.service.front.EtagencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yx on 2018/12/26.
 */
@Controller
public class AgencyControl {

    @Autowired
    private EtagencyService etagencyService;
    @Autowired
    private AgencyLevelService agencyLevelService;

    @RequestMapping(value = "/agency.html",method = RequestMethod.GET)
    public String loginAgency(){

        return "front/views/app/agency-bak/agency-repository";
    }

    @RequestMapping(value = "/agencyList.html",method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> agencyList(HttpServletRequest request,@Param("pname")String pname,@Param("linkman")String linkman){
        int limit = Integer.parseInt(request.getParameter("limit"));
        int page = Integer.parseInt(request.getParameter("page"));
        int start = limit * (page-1);
        Map<String,Object> param = new HashMap<>();
        param.put("start",start);
        param.put("limit",limit);
        param.put("pname",pname);
        param.put("linkman",linkman);
        Map<String,Object> result = etagencyService.queryAgencyByCondition(param);
        result.put("code","0");
        result.put("msg","");
        return result;
    }

    @RequestMapping(value = "/agencyAddOrEdit.html",method = RequestMethod.GET)
    public String loginDeadAgencyAddOrEdit(@Param("fid")String fid, Model model){
        Etagency e = null;
        if(fid!=null && !"".equals(fid)){
            e = etagencyService.getEtagencyById(fid);
        }else{
            e = new Etagency();
        }
        List<Etagencylevel> levelList = agencyLevelService.getAllLevelList();
        if(levelList!=null && levelList.size()>0){
            model.addAttribute("levelList",levelList);
        }else{
            model.addAttribute("levelList","");
        }
        model.addAttribute("agency",e);
        return "front/views/app/agency-bak/listform";
    }

    @RequestMapping(value = "/saveAgency.html",method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> loginSaveAgency(HttpServletRequest request){
        Map<String,Object> result = new HashMap<>();
        Map<String,Object> nameValue = new HashMap<>();
        Map<String, String[]> reqMap = request.getParameterMap();
        for(Map.Entry e:reqMap.entrySet()){
            String[] s = (String[])e.getValue();
            nameValue.put(String.valueOf(e.getKey()),s[0]);
        }
        try{
            etagencyService.saveAgency(nameValue);
            result.put("code","00");
            result.put("msg","保存成功!");
        }catch (Exception e){
            result.put("code","01");
            result.put("msg","保存失败!");
        }
        return result;
    }

    @RequestMapping(value = "/deleteAgency.html",method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> loginDeleteAgency(@Param("fid")String fid){
        Map<String,Object> result = new HashMap<>();
        try {
            etagencyService.deleteAgency(fid);
            result.put("code","00");
            result.put("msg","删除成功!");
        }catch (Exception e){
            result.put("code","01");
            result.put("msg","删除失败!");
        }
        return result;
    }

}
