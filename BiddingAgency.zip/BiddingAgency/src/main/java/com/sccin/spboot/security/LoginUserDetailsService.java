package com.sccin.spboot.security;

import com.sccin.spboot.config.SysConfig;
import com.sccin.spboot.domain.moren.Authority;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.Userrole;
import com.sccin.spboot.domain.moren.repository.AuthorityReposityInter;
import com.sccin.spboot.domain.moren.repository.UserReposityInter;
import com.sccin.spboot.domain.moren.repository.UserRoleReposityInter;
import com.sccin.spboot.security.pojo.DefineGrantedAuthority;
import com.sccin.spboot.security.pojo.SecurityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class LoginUserDetailsService implements UserDetailsService {
	@Autowired
	private UserReposityInter userReposity;
	@Autowired
	private AuthorityReposityInter authorityReposityInter;
	@Autowired
	private UserRoleReposityInter userRoleReposityInter;
	@Autowired
	private SysConfig sysConfig;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		User user = userReposity.findByLoginame(userName);

		if(user ==null){
			throw new UsernameNotFoundException("无法根据用户名获取信息。");
		}

		List<DefineGrantedAuthority> authoritys = new ArrayList<>();
		for(Userrole userrole : userRoleReposityInter.queryUserroleByUserid(user.getId())){
			authoritys.add(new DefineGrantedAuthority(userrole.getRolecode(),userrole.getRoleName()));
		}

		return new SecurityUser(user,authoritys).setSysConfig(sysConfig);
	}

	public boolean verifyPasd(String encodePasd,String pasd){
		BCryptPasswordEncoder psdEncoder=new BCryptPasswordEncoder();
		return psdEncoder.matches(pasd,encodePasd);
	}

	public boolean verifyCADN(String dbCadn,String formCadn){
		//最初版本没有对CA进行响应的判定，默认成功；
		if(dbCadn!=null&&!dbCadn.trim().equals("")){
			if(formCadn!=null &&!formCadn.trim().equals("")){
				return dbCadn.equals(formCadn);
			}else{
				return false;
			}
		}
		return true;
	}

	public List<Authority> getLoginUserAuths(String userId){
		return authorityReposityInter.getUserAhthoritys(userId);
	}
}
