package com.sccin.spboot.web.endpoint.interfaces;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

/**
 * Created by CPYF-Yi Mao on 2018-09-27.
 * 场地相关数据交换服务
 */
@WebService(name = "SiteDataExchangeService",
            targetNamespace = "http://interfaces.endpoint.web.spboot.sccin.com")
public interface SiteDataExchangeService {

    /**
     * 从本系统获取开评标房间信息
     * @param jsonStr
     * @return
     */
    @WebMethod(operationName = "GetRoomInfos")
    @WebResult(name = "result")
    String getRoomInfos(@WebParam(name = "jsonStr") String jsonStr);

    /**
     * 接收场地推送开评标房间预约信息
     * @param jsonStr
     * @return
     */
    @WebMethod(operationName = "ReceiveOrderRoomInfos")
    @WebResult(name = "result")
    String receiveOrderRoomInfos(@WebParam(name = "jsonStr") String jsonStr);


    /**
     * 从本系统获取开评标房间摄像头信息
     * @param jsonStr
     * @return
     */
    @WebMethod(operationName = "GetCameraInfos")
    @WebResult(name = "result")
    String getCameraInfos(@WebParam(name = "jsonStr") String jsonStr);
}
