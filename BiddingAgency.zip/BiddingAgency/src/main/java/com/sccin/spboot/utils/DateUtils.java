package com.sccin.spboot.utils;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * Created by CPYF-Yi Mao on 2018-09-11.
 */
public class DateUtils {

    /**
     * 标准时间格式
     */
    public enum TimeFomat{
        DATEFOMAT("yyyy-MM-dd"),
        DATETIMEFOMAT("yyyy-MM-dd HH:mm:ss");
        private String value;
        TimeFomat(String value){ this.value = value; }
        public String valueOf(){return this.value; }
    }

    public static boolean checkFomat(String time){
        return checkFomat(time, TimeFomat.DATETIMEFOMAT);
    }

    public static boolean checkFomat(String time,TimeFomat timeFomat){
        String reg = null;
        if(TimeFomat.DATEFOMAT.equals(timeFomat)){
            reg = "^\\d{4}(\\-)\\d{2}\\1\\d{2}$";
        }else if(TimeFomat.DATETIMEFOMAT.equals(timeFomat)){
            reg = "^\\d{4}(\\-)\\d{2}\\1\\d{2} \\d{2}(\\:)\\d{2}\\2\\d{2}$";
        }
        if(reg != null && time != null){
            return Pattern.compile(reg).matcher(time).matches();
        }
        return false;
    }

    public static String toString(LocalDateTime localDateTime){
        return localDateTime.format(DateTimeFormatter.ofPattern(TimeFomat.DATETIMEFOMAT.valueOf()));
    }

    public static String toString(LocalDateTime localDateTime,TimeFomat timeFomat){
        return localDateTime.format(DateTimeFormatter.ofPattern(timeFomat.valueOf()));
    }

    public static String toString(Timestamp timestamp){
        return timestamp.toLocalDateTime().format(DateTimeFormatter.ofPattern(TimeFomat.DATETIMEFOMAT.valueOf()));
    }

    public static String toString(Timestamp timestamp,TimeFomat timeFomat){
        return timestamp.toLocalDateTime().format(DateTimeFormatter.ofPattern(timeFomat.valueOf()));
    }

    public static Timestamp toTimestamp(String str){
        return Timestamp.valueOf(toLocalDateTime(str, TimeFomat.DATETIMEFOMAT));
    }

    public static Timestamp toTimestamp(String str,TimeFomat timeFomat){
        return Timestamp.valueOf(toLocalDateTime(str,timeFomat));
    }

    public static LocalDateTime toLocalDateTime(String str){
        return toLocalDateTime(str, TimeFomat.DATETIMEFOMAT);
    }

    public static LocalDateTime toLocalDateTime(String str,TimeFomat timeFomat){
        return LocalDateTime.parse(str,DateTimeFormatter.ofPattern(timeFomat.valueOf()));
    }

    /**
     * 获取时间差
     * time2 > time1
     * @param time1
     * @param time2
     * @param timeUnit
     * @return
     */
    public static long timeDifference(LocalDateTime time1, LocalDateTime time2, TimeUnit timeUnit){
        long difference = Timestamp.valueOf(time2).getTime()-Timestamp.valueOf(time1).getTime();
        if(difference > 0){
            if(TimeUnit.MILLISECONDS.equals(timeUnit)){
                return difference;
            }else if(TimeUnit.SECONDS.equals(timeUnit)){
                return TimeUnit.MILLISECONDS.toSeconds(difference);
            }else if(TimeUnit.MINUTES.equals(timeUnit)){
                return TimeUnit.MILLISECONDS.toMinutes(difference);
            }else if(TimeUnit.HOURS.equals(timeUnit)){
                return TimeUnit.MILLISECONDS.toHours(difference);
            }
        }
        return 0;
    }
}
