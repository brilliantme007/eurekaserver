package com.sccin.spboot.service.back;

import com.sccin.spboot.config.StartupListener;
import com.sccin.spboot.domain.moren.RepushAgain;
import com.sccin.spboot.domain.moren.repository.RepushAgainReposityInter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sccin.spboot.section.pojo.RemoteAccessResultDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jun.li on 2018/4/27.
 */
@Service("pushFailureService")
public class PushFailureService {
    @Autowired
    private RepushAgainReposityInter repushAgainReposityInter;
    /*@Autowired
    private RemoteAccessService remoteAccessService;*/

    private final static Logger logger = LoggerFactory.getLogger(StartupListener.class);

    //获取全部推送容错记录
    public Page<RepushAgain> list(Pageable pageable){
        return repushAgainReposityInter.findAll(pageable);
    }

    //重新推送
    public boolean repush(String id) {
        RepushAgain repushAgain = repushAgainReposityInter.findOne(id);
        Boolean success = false;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            List<String> paramTypesStr = objectMapper.readValue(repushAgain.getParamTypes(), new TypeReference<List<String>>(){});
            List<Class> paramTypesList = new ArrayList<>(paramTypesStr.size());
            Class<?>[] paramsTypesArr = new Class[paramTypesStr.size()];
            for (int i = 0; i < paramsTypesArr.length; i++) {
                paramsTypesArr[i] = Class.forName(paramTypesStr.get(i));
            }

            Class service = null;
            Method method = service.getMethod(repushAgain.getMethod(), paramsTypesArr);


            Object[] params = new Object[paramTypesStr.size()];
            List<Object> tempParams = objectMapper.readValue(repushAgain.getParams(), new TypeReference<List<Object>>(){});
            for (int i = 0; i < paramsTypesArr.length; i++) {
                //重新按照参数声明的类型执行转换: 类->json->类
                String json = objectMapper.writeValueAsString(tempParams.get(i));
                params[i] = objectMapper.readValue(json, paramsTypesArr[i]);
            }

            RemoteAccessResultDto result =null;
//                    (RemoteAccessResultDto) method.invoke(remoteAccessService, params);

            success = result.getState();

            if (success) {
                repushAgainReposityInter.delete(repushAgain);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return success;
    }

    //删除容错记录
    public void delete(String id) {
        repushAgainReposityInter.delete(id);
    }
}
