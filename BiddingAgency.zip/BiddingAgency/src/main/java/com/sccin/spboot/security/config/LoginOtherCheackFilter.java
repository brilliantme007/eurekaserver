package com.sccin.spboot.security.config;

import com.sccin.spboot.utils.RSAUtils;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.Utility;
import org.springframework.security.web.access.ExceptionTranslationFilter;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.security.web.firewall.FirewalledRequest;
import org.springframework.security.web.savedrequest.RequestCacheAwareFilter;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;
import org.springframework.security.web.session.ConcurrentSessionFilter;
import org.springframework.security.web.session.SessionManagementFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by developer_hyaci on 2016/2/17.
 * 过滤登陆请求，获取到所有的登陆时输入的值，封装为其他对象往内部传递
 * UsernamePasswordAuthenticationFilter
 */
@Component
public class LoginOtherCheackFilter implements Filter {

    public static final String VERCODE="verCode";
    public static final String AJAXACCEPTCONTENTTYPE = "text/html;type=ajax";
    public static final String AJAXSOURCEPARAM = "ajaxSource";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    private String getRequestPayload(HttpServletRequest req) {
        StringBuilder sb = new StringBuilder();
        try(BufferedReader reader = req.getReader()) {
            char[] buff = new char[1024];
            int len;
            while((len = reader.read(buff)) != -1) {
                sb.append(buff,0, len);
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    private boolean isAjaxRequestInternal(HttpServletRequest request) {
        String acceptHeader = request.getHeader("Accept");
        String ajaxParam = request.getParameter(AJAXSOURCEPARAM);
        if (AJAXACCEPTCONTENTTYPE.equals(acceptHeader) || StringUtils.hasText(ajaxParam)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request=(HttpServletRequest)servletRequest;
        HttpServletResponse response=(HttpServletResponse)servletResponse;
        boolean flag = true;
        String msgErr="其他字段校验有问题";
        if(request.getRequestURI().equals("/login.html")&&request.getMethod().equalsIgnoreCase("POST")){
            //校验form中的除帐号密码的其他字段；
            //flag=false;
            /*String params=this.getRequestPayload(request);
            if(request.getAttribute(VERCODE) == null || request.getSession().getAttribute(VERCODE)== null){
                msgErr="未能获取到验证码";
                flag = false;
            }else{
                if(!request.getSession().getAttribute(VERCODE).toString().equalsIgnoreCase(request.getAttribute(VERCODE).toString())) {
                    msgErr="验证码不匹配";
                    flag = false;
                }
            }*/
        }

        //第三方登录重写paramters
        if(request.getServletPath().equals("/login.html")&&request.getAttribute("loginType")!=null&&request.getAttribute("loginType").equals("ulify")){
            request=new UlifyLoginRequestWrapper(request);
        }
//        ConcurrentSessionFilter
//        RequestCacheAwareFilter
//        SecurityContextHolderAwareRequestFilter
//        AnonymousAuthenticationFilter
//        SessionManagementFilter
//        ExceptionTranslationFilter
//        FilterSecurityInterceptor
        if(!flag){
            //判断是否为ajax请求
            String failUrl=Statements.FAILURL;
            /*if(isAjaxRequestInternal(request)){
                //ajax
                failUrl = "/loginFailAjax.html";
            }*/
            request.setAttribute("error",msgErr);
            request.getRequestDispatcher(failUrl).forward(request,response);
        }else{
            filterChain.doFilter(request,response);
        }
    }

    @Override
    public void destroy() {}



    private class SqlBlindEntry<K,V> implements Map.Entry<K, V> {
        private Map.Entry me;

        public SqlBlindEntry(Map.Entry me) {
            if (me == null) {
                throw new IllegalArgumentException("Map.Entiry argument not null.");
            }
            if(me.getValue()!=null&&!me.getValue().toString().equals("")){
                if(me.getValue() instanceof String ){
                    if(!me.getKey().toString().equals("email")){
                        me.setValue(Utility.htmlEncode(me.getValue().toString()).replaceAll("", ""));
                    }
                }else if(me.getValue() instanceof String []){
                    String [] values=(String[]) me.getValue();
                    for(int i=0;i<values.length;i++){
                        values[i]=Utility.htmlEncode(values[i]).replaceAll("","");
                    }
//					me.setValue(values);
                }else{

                }
            }
            this.me = me;
        }

        @Override
        public K getKey() {
            // TODO Auto-generated method stub
            return (K) me.getKey();
        }

        @Override
        public V getValue() {
            // TODO Auto-generated method stub
            return (V) me.getValue();
        }

        @Override
        public V setValue(V value) {
            // TODO Auto-generated method stub
            return (V) me.setValue(value);
        }

    }

    private class UlifyLoginRequestWrapper extends SecurityContextHolderAwareRequestWrapper {

        private Map paramap;

        public UlifyLoginRequestWrapper(HttpServletRequest request) {
            super(request,"");
            Map tempMap=request.getParameterMap();
            Map buildMap = new HashMap();
            Iterator iterator = tempMap.entrySet().iterator();
            while (iterator.hasNext()) {
                SqlBlindEntry entry = new SqlBlindEntry<String,Object>((Map.Entry) iterator.next());
                buildMap.put(entry.getKey(),entry.getValue());
            }
            paramap=buildMap;
            paramap.put("username",request.getAttribute("username"));
            String rsaPasd="";
            try {
                rsaPasd=RSAUtils.encryptByPublicKey(request.getAttribute("password").toString(),Statements.getRSAPubKey());
            } catch (Exception e) { }
            paramap.put("password",rsaPasd);
        }

        @Override
        public String getParameter(String name) {
            // TODO Auto-generated method stub
            if (paramap.get(name) instanceof String) {
                return (String) paramap.get(name);
            }else if(paramap.get(name) instanceof String []){
                return ((String [])paramap.get(name))[0];
            }else{
                return super.getParameter(name);
            }
        }
        @Override
        public Map<String, String[]> getParameterMap() {
            // TODO Auto-generated method stub
            return paramap;
        }
        @Override
        public String[] getParameterValues(String name) {
            // TODO Auto-generated method stub
            if (paramap.get(name) instanceof String) {
                ArrayList<String> arr=new ArrayList<String>();
                arr.add((String) paramap.get(name));
                return arr.toArray(new String [1]);
            }else if(paramap.get(name) instanceof String []){
                return (String [])paramap.get(name);
            }else{
                return super.getParameterValues(name);
            }
        }

    }


}
