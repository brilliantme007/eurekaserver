package com.sccin.spboot.service.back;

import com.sccin.spboot.domain.moren.Areacodes;
import com.sccin.spboot.domain.moren.repository.AreacodesReposityInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yx on 2018/8/27.
 */
@Service("areacodeService")
public class AreacodeService {

    @Autowired
    private AreacodesReposityInter areacodesReposityInter;

    public String getAllAreaNameByCode(String areaCode){
        List<String> areas = new ArrayList<>();
        String result = "";
        if(areaCode.length() == 6){
            if(areaCode.endsWith("0000")){

            }else if(areaCode.endsWith("00")){
                areas.add(areaCode.substring(0,2)+"0000");
            }else{
                areas.add(areaCode.substring(0,2)+"0000");
                areas.add(areaCode.substring(0,4)+"00");
            }
            areas.add(areaCode);
        } else if (areaCode.length() == 8 && areaCode.endsWith("-r")) {
            areas.add(areaCode.substring(0,6));
            areas.add(areaCode);
        }
        if(areas.size() > 0){
            List<Areacodes> areacodes = areacodesReposityInter.findByFcodeIn(areas);
            for(String areaStr:areas){
                for(Areacodes area : areacodes){
                    if(areaStr.equals(area.getFcode())){
                        result += "-"+area.getFareaname();
                        break;
                    }
                }
            }
            return areacodes.size() > 0 ? result.substring(1) : "";
        }
        return result;
    }

}
