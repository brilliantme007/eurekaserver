package com.sccin.spboot.service.back;

import com.sccin.spboot.domain.moren.Nlog;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.repository.LogsReposityInter;
import com.sccin.spboot.utils.IPAndMacAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component("LogService")
public class LogsService {
    private Logger logger = null;

    @Autowired
    private LogsReposityInter logsReposityInter;

    //根据参数查询权限相关数据；
    public Page<Nlog> queryPageLogInfos(String fmessage, Pageable pageable){
        boolean fmessageFlag = fmessage != null && !fmessage.trim().equals("");

        Page<Nlog> page=null;

        if(fmessageFlag){
            page=logsReposityInter.queryPage(pageable, "%"+ fmessage +"%");
        }else{
            page=logsReposityInter.queryPage(pageable);
        }

        return page;
    }

    public Nlog detailLog(String fid){
        Optional<Nlog> log = logsReposityInter.findById(fid);
        if(log.isPresent()){
            return log.get();
        }
        return null;
    }

    @Transactional
    public void delectLogByFid(String fid){
        logsReposityInter.deleteByfid(fid);
    }

    /**
     * @param clazz 发生日志记录事件的类模板；
     * @param fType 类型 按照PDM 进行界定
     * @param message 消息体；
     * @param flag0 标识位
     * @param flag1 标识位
     * @param flag2 标识位
     * @param flag3 标识位
     * @param remark 事项描述
     * @param fIsdel 是否可删 true 可删 false 不可删
     * */

    @Transactional
    public void logInfo(Class clazz,Integer fType,String flag0,String flag1,String flag2,String flag3,String message,String remark,Boolean fIsdel){

        Nlog log=new Nlog();
        log.setTime(Timestamp.valueOf(LocalDateTime.now()));
        log.setType(fType);
        log.setId(UUID.randomUUID().toString());
        log.setArg0(flag0);
        log.setArg1(flag1);
        log.setArg2(flag2);
        log.setArg3(flag3);
        log.setArg4(message);
        log.setRemark(remark);
        log.setIsdel(fIsdel?1:0);//（0.不可以，1可以）
        this.logsReposityInter.save(log);
        logger= LoggerFactory.getLogger(clazz);
        logger.info(message+"|"+fType+"|"+flag0+"|"+flag1+"|"+flag2+"|"+flag3+"|"+(fIsdel?"可删":"不可删"));
    }
    /**
     * @param clazz 发生日志记录事件的类模板；
     * @param logs 需要记录的业务日志对象；
     * */

    @Transactional
    public void logInfoList(Class clazz,List<Nlog> logs){
        this.logsReposityInter.saveAll(logs);
        logger=LoggerFactory.getLogger(clazz);
        for(int i=0;i<logs.size();i++){
            logger.info(logs.get(i).getArg4()+"|"+logs.get(i).getType()+"|"+logs.get(i).getArg0()+"|"+logs.get(i).getArg1()+"|"+logs.get(i).getArg2()+"|"+logs.get(i).getArg3()+"|"+((logs.get(i).getIsdel()==0)?"不可删":"可删"));
        }
    }
    /**
     * @param clazz 发生日志记录事件的类模板；
     * @param fType 类型 按照PDM 进行界定
     * @param message 消息体；
     * @param flag0 标识位
     * @param flag1 标识位
     * @param flag2 标识位
     * @param flag3 标识位
     *  @param remark 事项描述
     * @param fIsdel 是否可删 true 可删 false 不可删
     * */

    @Transactional
    public void logError(Class clazz,Integer fType,String flag0,String flag1,String flag2,String flag3,String message,String remark,Boolean fIsdel){

        Nlog log=new Nlog();
        log.setTime(Timestamp.valueOf(LocalDateTime.now()));
        log.setType(fType);
        log.setId(UUID.randomUUID().toString());
        log.setArg0(flag0);
        log.setArg1(flag1);
        log.setArg2(flag2);
        log.setArg3(flag3);
        log.setArg4(message);
        log.setRemark(remark);
        log.setIsdel(fIsdel?1:0);//（0.不可以，1可以）
        this.logsReposityInter.save(log);
        logger=LoggerFactory.getLogger(clazz);
        logger.error(message+"|"+fType+"|"+flag0+"|"+flag1+"|"+flag2+"|"+flag3+"|"+(fIsdel?"可删":"不可删"));
    }
    /**
     * @param clazz 发生日志记录事件的类模板；
     * @param logs 需要记录的业务错误日志对象；
     * */

    @Transactional
    public void logErrorList(Class clazz,List<Nlog> logs){
        this.logsReposityInter.saveAll(logs);
        logger=LoggerFactory.getLogger(clazz);
        for(int i=0;i<logs.size();i++){
            logger.error(logs.get(i).getArg4()+"|"+logs.get(i).getType()+"|"+logs.get(i).getArg0()+"|"+logs.get(i).getArg1()+"|"+logs.get(i).getArg2()+"|"+logs.get(i).getArg3()+"|"+((logs.get(i).getIsdel()==0)?"不可删":"可删"));
        }
    }

    /**
     * 删除一些时间前可以删除的日志数据
     * @param date 时间
     */
    @Transactional
    public void deleteLogBeforeDate(String date){
        logsReposityInter.deleteByFtimeBefore(date);
    }
    /**
     * 删除一些时间前日志数据
     * @param date 时间
     */
    @Transactional
    public void deleteLogBeforeDateAll(String date){
        logsReposityInter.deleteByFtimeBeforeAll(date);
    }
    //根据参数查询权限相关数据；
    public Page<Nlog> queryPageLogsByParams(String fmessage, Pageable pageable){
        boolean fmessageFlag = fmessage != null && !fmessage.trim().equals("");
        Page<Nlog> page=null;
        if(fmessageFlag){
            page=logsReposityInter.queryPage(pageable, "%"+ fmessage +"%");
        }else{
            //无参数
            page=logsReposityInter.queryPage(pageable);
        }
        return page;
    }

    public List<Nlog> detailLogModifay(String farg0){
        return logsReposityInter.queryLogsByFarg0(farg0);
    }
    @Transactional
    public void saveLog(List<Nlog> logs){
        this.logsReposityInter.saveAll(logs);
    }

    //记录用户操作，需要保存ip和mac
    public void logWithIpAndMAC(HttpServletRequest request, String msg, Logger logger) {
        User user = UserService.getUserFromSession(request);
        String username = user != null ? user.getName() : "外部用户";
        String msg0 = username + msg;
        try {
            String ip = IPAndMacAddress.getIp(request);
            IPAndMacAddress ipAndMacAddress = new IPAndMacAddress(ip);
            //写入数据库
            logInfo(this.getClass(), 3, user != null ? user.getLoginame() : "", ip,
                    ipAndMacAddress.tryGetMac(logger), "", msg0, msg0, false);
        } catch (Exception e) {
            logger.error("记录日志（用户（" + username + "）" + msg + "）失败，原因：" + e.getMessage() + "（" +
                    e.getClass().getName() + "）");
        }
    }
}
