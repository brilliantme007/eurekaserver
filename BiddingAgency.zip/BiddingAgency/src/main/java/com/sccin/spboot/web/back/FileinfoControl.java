package com.sccin.spboot.web.back;

import com.sccin.spboot.config.SysConfig;

import com.sccin.spboot.domain.moren.Fileinfo;

import com.sccin.spboot.service.back.FileinfoService;
import com.sccin.spboot.utils.Utility;


import com.sccin.spboot.web.pojo.AjaxReturnBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class FileinfoControl {

    private static Logger logger = LoggerFactory.getLogger(FileinfoControl.class);

    @Autowired
    private FileinfoService fileinfoService;
    @Autowired
    private SysConfig sysConfig;

    /**
     * 点击文件管理按钮后进入页面的查询 输入条件查询文件
     *
     * @param pageable
     * @param model
     * @param name 文件名
     * @param storename 储存名
     * @param suffix 后缀名
     * @param stime 起始时间 // * @param etime 结束时间
     * @return
     * @author meiyufei
     * @time 2018.8.26. 10:56
     */
    @RequestMapping("/fileInfo/listPage.html")
    public String getFileInfoList(@PageableDefault Pageable pageable, Model model, @Param("name") String name, @Param("storename") String storename,
                                  @Param("suffix") String suffix, @Param("stime") String stime, @Param("etime") String etime) {

        Date dd = new Date();
        SimpleDateFormat sdff = new SimpleDateFormat("yyyy-MM-dd");
        String starTime = "";          //开始时间
        String endTime = "";           //结束时间
        if (stime == null || stime == "") {
            starTime = "1970-01-01 00:00:00";
        } else {
            starTime = stime;
        }
        if (etime == null || etime == "") {
            endTime = sdff.format(dd) + " 23:59:59";
        } else {
            endTime = etime;
        }

        Page<Fileinfo> page = fileinfoService.findFileinfoByPage(pageable, name, storename, suffix, starTime, endTime);

        HashMap<String, Object> paramMap = new HashMap<>();
        paramMap.put("stime", stime);
        paramMap.put("etime", etime);
        paramMap.put("name", name);
        paramMap.put("storename", storename);
        paramMap.put("suffix", suffix);
        model.addAttribute("fileInfos", page.getContent());           //传递查询的信息
        model.addAttribute("page", page.getNumber() + 1); //传递当前页数
        model.addAttribute("total", page.getTotalPages());            //传递总页数
        model.addAttribute("paramMap", paramMap);
        return "back/fileInfo/fileInfoList";
    }


    /**
     * 点击编辑按钮后根据选择的文件id查询对应的信息
     *
     * @param fid 文件id
     * @param model
     * @return
     */
    @RequestMapping("/fileInfo/edit/{fid}.html")
    public String editFileInfo(@PathVariable("fid") String fid, Model model) {
        model.addAttribute("fileInfo", fileinfoService.findByFid(fid));
        model.addAttribute("downUrl", sysConfig.getProjectHost() + "/fileInfo/downloadFile?fileId=" + fid);
        return "back/fileInfo/fileInfoEdit";
    }

    /**
     * 保存编辑后的文件信息
     *
     * @param fileinfo 文件对象
     * @return
     */
    @RequestMapping("/fileInfo/save")
    @ResponseBody
    public AjaxReturnBean saveOrUpdateFileInfo(Fileinfo fileinfo) {
        return fileinfoService.saveOrUpdateFileInfo(fileinfo);
    }

    /**
     * 删除文件信息
     *
     * @param fids 文件id
     * @return
     */
    @RequestMapping("/fileInfo/del")
    @ResponseBody
    public AjaxReturnBean delFileInfo(@Param("fids") String fids) {
        List<String> list = null;
        if (!StringUtils.isEmpty(fids)) {
            if (fids.contains(",")) {
                list = Arrays.asList(fids.split(","));
            } else {
                list = new ArrayList<>();
                list.add(fids);
            }
        }
        if (fids != null) {
            return fileinfoService.delFileinfo(list);
        }
        return AjaxReturnBean.createError("无效请求", null);
    }

    @RequestMapping(value = "/fileInfo/downloadFile", method = RequestMethod.GET)
    public void downloadFile(HttpServletRequest request, HttpServletResponse response, @Param("fileId") String fileId) {
        if (!StringUtils.isEmpty(fileId)) {
            Fileinfo fileinfo = this.fileinfoService.findByFid(fileId);
            if (fileinfo != null) {
                try {
                    Utility.download(new File(fileinfo.getStoreplace()), fileinfo.getName(), null, request, response);
                } catch (IOException e) {
                    logger.error("文件下载异常：" + e.getMessage());
                }
            }
        }
    }

    @RequestMapping("/fileInfo/downloadExcelFile")
    public void downloadExcelFile(HttpServletRequest request, HttpServletResponse response) {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        Resource resource = context.getResource("classpath:/static/front/layuiadmin/excel/agency-template.xlsx");
        try {
            File file = resource.getFile();
            Utility.download(file, "招标代理模板.xlsx", null, request, response);
        } catch (IOException e) {
            logger.error("文件下载异常：" + e.getMessage(), e);
        }
    }

    /**
     * 准备导入上传的Excel文件
     *
     * @param fileId
     * @return
     */
    @RequestMapping("/fileInfo/importFile")
    @ResponseBody
    public AjaxReturnBean importFile(@Param("fileId") String fileId) {
        Fileinfo fileinfo = fileinfoService.findByFid(fileId);
        if (fileinfo != null) {
            String path = fileinfo.getStoreplace();
            File file = new File(path);
            if (file.exists() && file.isFile()) {
                try {
                    fileinfoService.importExcelFile(file);
                } catch (Exception e) {
                    return AjaxReturnBean.createError("导入文件失败！");
                }
            }
        }
        return AjaxReturnBean.createSuccess("导入文件成功！");
    }

    /**
     * 文件上传
     *
     * @param request
     * @return
     */
    @RequestMapping("/fileInfo/uploadFile")
    @ResponseBody
    public String uploadFile(HttpServletRequest request) {
        String fileIdStr = "";
        String fileName = "";
        if (request instanceof MultipartHttpServletRequest) {
            MultipartHttpServletRequest mRequest = (MultipartHttpServletRequest) request;
            List<MultipartFile> list = mRequest.getMultiFileMap().get("upfile");
            if (list != null && list.size() > 0) {
                String rootPath = sysConfig.getSaveFileRootPath();
                File rootfile = new File(rootPath);
                if (!rootfile.isDirectory()) {
                    rootfile.mkdirs();
                }
                InputStream is = null;
                OutputStream os = null;
                for (MultipartFile file : list) {
                    String uuid = UUID.randomUUID().toString();
                    String originalName = file.getOriginalFilename();
                    if (originalName.contains("\\")) {
                        originalName = originalName.substring(originalName.lastIndexOf("\\") + 1);
                    }
                    if (originalName.length() > 128) {
                        return "{\"state\":\"文件名超过限制长度128位\"}";
                    }

                    String parentSavePath = rootPath + File.separator + uuid;
                    String fileSavePath = rootPath + File.separator + uuid + File.separator
                            + originalName.substring(originalName.lastIndexOf(File.separator) + 1);
                    try {
                        File saveParentFile = new File(parentSavePath);
                        if (!saveParentFile.isDirectory()) {
                            saveParentFile.mkdirs();
                        }
                        is = file.getInputStream();
                        os = new FileOutputStream(new File(fileSavePath));
                        byte[] buffer = new byte[1024 * 5];
                        while (is.read(buffer) != -1) {
                            os.write(buffer);
                        }

                        String suffix = originalName.substring(originalName.lastIndexOf("."),
                                originalName.length());
                        Fileinfo info = new Fileinfo();
                        info.setId(uuid);
                        info.setName(originalName);
                        info.setStorename(originalName);
                        info.setStoreplace(fileSavePath);
                        info.setSuffix(suffix);
                        info.setTime(new Timestamp(System.currentTimeMillis()));
                        fileinfoService.saveFileInfo(info);
                        fileIdStr = uuid;
                        fileName = originalName;
                    } catch (Exception e) {
                        return "{\"state\":\"" + e.getMessage() + "\"}";
                    } finally {
                        try {
                            if (is != null) {
                                is.close();
                            }
                            if (os != null) {
                                os.close();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        return "{\"state\":\"SUCCESS\",\"url\":\"" + fileIdStr + "\",\"name\":\"" + fileName + "\"}";
    }
}
