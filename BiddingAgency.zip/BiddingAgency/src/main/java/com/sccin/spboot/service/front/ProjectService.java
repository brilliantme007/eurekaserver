package com.sccin.spboot.service.front;

import com.sccin.spboot.domain.agency.Etprojinfo;
import com.sccin.spboot.domain.agency.Rnprojagency;
import com.sccin.spboot.domain.agency.repository.EtprojinfoInter;
import com.sccin.spboot.domain.agency.repository.RnprojagencyInter;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.StringUtil;
import javafx.scene.paint.Stop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * 项目信息管理
 *
 * @Author lijun
 */
@Service("projectService")
public class ProjectService {
    /**
     * 项目信息Dao
     */
    @Autowired
    private EtprojinfoInter etprojinfoInter;
    /**
     * 抽取结果Dao
     */
    @Autowired
    private RnprojagencyInter rnprojagencyInter;

    /**
     * 通过fids查询projects
     *
     * @param fids
     * @return java.util.List<com.sccin.spboot.domain.agency.Etprojinfo>
     * @author WHLiang
     * @date 2018-12-29 13:32
     */
    public List<Etprojinfo> getAllByFidIn(List<String> fids) {
        return etprojinfoInter.findByFidIn(fids);
    }

    /**
     * 分页查询项目信息
     *
     * @param page        页数（从0开始）
     * @param limit       大小
     * @param projectName 项目名称
     * @param bidType 招采类型
     * @return 分页结果
     * @author lijun
     */
    public Page<Map<String, Object>> page(int page, int limit, String projectName, String bidType) {
        return etprojinfoInter.pageBy(page, limit, projectName, bidType);
    }

    /**
     * 通过fid获取项目信息
     *
     * @param fid 项目id
     * @return com.sccin.spboot.domain.agency.Etprojinfo
     * @author WHLiang
     * @date 2018-12-27 9:54
     */
    public Etprojinfo getEtprojinfoByFid(String fid) {
        Optional<Etprojinfo> etprojinfoOptional = etprojinfoInter.findById(fid);
        return etprojinfoOptional.orElse(null);
    }


    /**
     * 根据fid或者funique查询项目
     *
     * @param uniqueOrId fid或者unique
     * @return 项目
     * @author lijun
     */
    public Etprojinfo findByIdOrUnique(String uniqueOrId) {
        if (StringUtil.isEmpty(uniqueOrId)) {
            throw new NullPointerException("项目fid或者funique为空");
        }

        return etprojinfoInter.findFirstByFunique(uniqueOrId).orElse(
                etprojinfoInter.findById(uniqueOrId).orElse(null));
    }

    /**
     * 检查选中的项目是否已经被抽取结果表关联
     *
     * @param fids 项目fid集合
     * @return 有关联true，否则false
     * @author lijun
     */
    public boolean hasBeenRelated(List<String> fids) {
        if (!fids.isEmpty()) {
            List<Rnprojagency> rnprojagencies = rnprojagencyInter.findByRprojinfoidIn(fids);
            if (rnprojagencies != null && !rnprojagencies.isEmpty()) {
                return true;
            }
        }

        return false;
    }

    /**
     * 批量删除项目
     *
     * @param fids 项目fid集合
     * @author lijun
     */
    @Transactional
    public void batchDelete(List<String> fids) {
        etprojinfoInter.deleteByFidIn(fids);
    }

    /**
     * 新增或更新项目
     *
     * @param params 参数
     * @author lijun
     */
    public Etprojinfo addOrUpdate(Map<String, String> params) {
        Etprojinfo project;
        Timestamp now = Timestamp.from(Instant.now());
        if (params.containsKey("fid") && !StringUtil.isEmpty(params.get("fid"))) {
            /* 更新 */
            /* fid */
            String fid = params.get("fid");
            project = etprojinfoInter.findById(fid).orElseThrow(() ->
                    new IllegalArgumentException("根据项目fid未找到项目：" + fid));
        } else {
            /* 新增 */
            project = new Etprojinfo();
            //fid
            project.setFid(UUID.randomUUID().toString());
            //创建时间
            project.setFctime(now);
        }
        /* 项目名称 */
        if (params.containsKey("projectName") && !StringUtil.isEmpty(params.get("projectName"))) {
            project.setFprojname(params.get("projectName"));
        } else {
            project.setFprojname(null);
        }

        //更新时间
        project.setFutime(now);
        //fmkeys
        project.setFmkeys(Statements.projectToXml(params).toString());
        /* 项目类型，默认为采购（见stopWatch的projectType）*/
        project.setFptype("2");

        //保存
        return etprojinfoInter.save(project);
    }
}
