package com.sccin.spboot.domain.moren;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by jun.li on 2018/4/26.
 */
@Entity
@Table(name = "etrepushagain")
public class RepushAgain {
    private String id;
    private String params;
    private String paramTypes;
    private String domain;
    private String method;
    private String describe;
    private Timestamp creatime;



    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "fparams", nullable = true, insertable = true, updatable = true, length = 65535)
    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    @Basic
    @Column(name = "fparamtypes", nullable = true, insertable = true, updatable = true, length = 65535)
    public String getParamTypes() {
        return paramTypes;
    }

    public void setParamTypes(String paramTypes) {
        this.paramTypes = paramTypes;
    }

    @Basic
    @Column(name = "fdomain", nullable = true, insertable = true, updatable = true, length = 258)
    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    @Basic
    @Column(name = "fmethod", nullable = true, insertable = true, updatable = true, length = 258)
    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    @Basic
    @Column(name = "fdescrible", nullable = true, insertable = true, updatable = true, length = 258)
    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    @Basic
    @Column(name = "fcreatime", nullable = true, insertable = true, updatable = true)
    public Timestamp getCreatime() {
        return creatime;
    }

    public void setCreatime(Timestamp creatime) {
        this.creatime = creatime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RepushAgain repush = (RepushAgain) o;

        if (id != null ? !id.equals(repush.id) : repush.id != null) return false;
        if (params != null ? !params.equals(repush.params) : repush.params != null) return false;
        if (paramTypes != null ? !paramTypes.equals(repush.paramTypes) : repush.paramTypes != null) return false;
        if (domain != null ? !domain.equals(repush.domain) : repush.domain != null) return false;
        if (method != null ? !method.equals(repush.method) : repush.method != null) return false;
        if (describe != null ? !describe.equals(repush.describe) : repush.describe != null) return false;
        if (creatime != null ? !creatime.equals(repush.creatime) : repush.creatime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (params != null ? params.hashCode() : 0);
        result = 31 * result + (paramTypes != null ? paramTypes.hashCode() : 0);
        result = 31 * result + (domain != null ? domain.hashCode() : 0);
        result = 31 * result + (method != null ? method.hashCode() : 0);
        result = 31 * result + (describe != null ? describe.hashCode() : 0);
        result = 31 * result + (creatime != null ? creatime.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "id = " + id + ", params = " + params + ", paramTypes = " + paramTypes + ", domain = " + domain
                + ", method = " + method + ", describe = " + describe + ", creatime = " + creatime;
    }
}
