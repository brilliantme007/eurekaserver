package com.sccin.spboot.web.back;

import com.sccin.spboot.domain.moren.RepushAgain;
import com.sccin.spboot.service.back.PushFailureService;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by jun.li on 2018/4/27.
 */
@Controller
@RequestMapping("/pushFailure")
public class PushFailureControl extends GlobalExcaptionHolder {
    @Autowired
    PushFailureService pushFailureService;

    @RequestMapping("/list.html")
    public String list(@PageableDefault(value = PAGESIZE) Pageable pageable, Model model,@Param("pageNo") String pageNo) {

        Sort sort = new Sort(Sort.Direction.DESC, "creatime");
        System.out.println(pageable.getPageNumber()+" "+pageable.getPageSize()+" " +pageNo);
        if (pageNo == null){
            pageNo = "0";
        }
        pageable = new PageRequest(Integer.parseInt(pageNo), pageable.getPageSize(), sort);
        Page<RepushAgain> repushAgainPage = pushFailureService.list(pageable);
        model.addAttribute("pageNo",pageable.getPageNumber() + 1);
        model.addAttribute("total",repushAgainPage.getTotalPages());
        model.addAttribute("content",repushAgainPage.getContent());

        return "back/pushFailure/list";
    }

    @RequestMapping("/repush")
    public @ResponseBody
    AjaxReturnBean repush(@Param("id") String id) {
        //调用RemoteAccessService对应方法
        boolean success = pushFailureService.repush(id);
        AjaxReturnBean result;
        if (success) {
            result = AjaxReturnBean.createSuccess("success");
        } else {
            result = AjaxReturnBean.createError("推送失败，是否保存该条失败记录？");
        }
        return result;
    }

    @RequestMapping("/delete")
    public @ResponseBody
    AjaxReturnBean delete(@Param("id") String id) {
        pushFailureService.delete(id);
        return AjaxReturnBean.createSuccess("success");
    }

}
