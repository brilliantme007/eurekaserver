package com.sccin.spboot.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Created by CPYF-Yi Mao on 2018-09-10.
 */
public class ValidUtils {

    //校验注解定义
    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Check {
        //字段描述（用于错误提示返回）
        String describe();

        //非空（null、空字符、0长度集合数组）校验
        boolean not_empty() default true;

        //可接受字符串范围（例如：{"1","3"}）
        String[] accepts() default {};

        //正则校验
        String regex() default "";

        //字符最大长度校验（默认-1：不校验）
        int max_length() default -1;

        //字符长度校验（默认-1：不校验）
        int length() default -1;
    }

    //常用正则
    public interface regex{
        String datetime = "\\d{4}(\\-)\\d{2}\\1\\d{2} \\d{2}(:)\\d{2}\\2\\d{2}";//例:{2018-09-28 11:18:12}
        String date = "\\d{4}(\\-)\\d{2}\\1\\d{2}";                             //例:{2018-09-28}
        String areacode = "\\d{6}";                                             //例:{510600}
    }

    //结果返回
    public static class CheckResult{
        private boolean check = true;   //true通过，false不通过
        private String message;         //检查不通过提示信息

        public CheckResult(){}

        public CheckResult(String message){
            this.check = false;
            this.message = message;
        }

        public boolean isCheck() {
            return check;
        }

        public String getMessage() { return message; }
    }

    /**
     * 根据字段Check注释检查相应内容
     * @param obj   检查对象
     * @return
     * @throws IllegalAccessException
     */
    public static CheckResult checkObject(Object obj){
        try {
            return checkObject(obj,null);
        } catch (IllegalAccessException e) {
            return new CheckResult("解析并校验json对象异常："+e.getMessage());
        }
    }

    /**
     * 检验空
     * 实体、字符串、集合
     * @param obj
     * @return
     */
    public static boolean isEmpty(Object obj){
        if(obj == null)
            return true;
        if(obj instanceof String)
            return "".equals(obj.toString().trim()) || "null".equalsIgnoreCase(obj.toString().trim());
        if(obj instanceof Collection)
            return ((Collection)obj).size() == 0;
        return false;
    }

    /**
     * 获取包含父类的所有字段
     * @param cls
     * @return
     */
    public static List<Field> getSuperFields(Class<?> cls){
        List<Field> allFields = new ArrayList<>();
        do{
            Field[] fields = cls.getDeclaredFields();
            for(Field field : fields){
                allFields.add(field);
            }
            cls = cls.getSuperclass();
        }while (!cls.isAssignableFrom(Object.class));
        return allFields;
    }

    /**
     * 根据字段Check注释检查相应内容
     * @param obj     检查对象
     * @param fields  用于递归集合实体类缓存，外部不关注
     * @throws IllegalAccessException
     */
    private static CheckResult checkObject(Object obj,List<Field> fields) throws IllegalAccessException {
        for(Field field : fields != null ? fields : getSuperFields(obj.getClass())){
            field.setAccessible(true);

            ValidUtils.Check check;
            if((check = field.getAnnotation(ValidUtils.Check.class)) != null) {
                Object val = field.get(obj);
                if(check.not_empty() && ValidUtils.isEmpty(val)){   //空字符校验
                    return new CheckResult("字段[ "+field.getName()+" ("+check.describe()+") ]值为 {"+val+"} 空，校验不通过");
                }
                if(check.accepts().length > 0 && !Arrays.asList(check.accepts()).contains(val)){ //接受字符校验
                    return new CheckResult("字段[ "+field.getName()+" ("+check.describe()+") ]值为 {"+val+"} 超过可接受范围，校验不通过");
                }
                if(!ValidUtils.isEmpty(check.regex()) && (val == null || !Pattern.compile(check.regex()).matcher(val.toString()).matches())){
                    return new CheckResult("字段[ "+field.getName()+" ("+check.describe()+") ]值为 {"+val+"} 格式不符合要求，校验不通过");
                }
                if(check.max_length() != -1 && (val == null || val.toString().length() > check.max_length())){
                    return new CheckResult("字段[ "+field.getName()+" ("+check.describe()+") ]值为 {"+val+"} 字符长度超过最大限制 "+check.max_length()+" ，校验不通过");
                }
                if(check.length() != -1 && (val == null || val.toString().length() != check.length())){
                    return new CheckResult("字段[ "+field.getName()+" ("+check.describe()+") ]值为 {"+val+"} 字符长度不符合规定 "+check.length()+" ，校验不通过");
                }
            }

            if(Collection.class.isAssignableFrom(field.getType())){ //集合
                Iterator iter = ((Collection)field.get(obj)).iterator();
                List<Field> tmp = null;
                CheckResult result;
                while (iter.hasNext()){
                    Object o = iter.next();
                    if(tmp != null) tmp = getSuperFields(o.getClass());
                    if(!(result = checkObject(o,tmp)).isCheck()) return result;
                }
            }
        }
        return new CheckResult();
    }
}
