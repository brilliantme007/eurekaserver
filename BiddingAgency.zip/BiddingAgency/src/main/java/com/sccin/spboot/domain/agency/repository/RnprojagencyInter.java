package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Rnprojagency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created on 2018-12-27 8:54
 *
 * @Author WHLiang
 */
@Repository
public interface RnprojagencyInter extends JpaRepository<Rnprojagency, String>, JpaSpecificationExecutor<Rnprojagency> {
    /**
     * 按照项目fid集合查询抽取结果
     *
     * @param fids 项目fid集合
     * @return 抽取结果
     * @author lijun
     */
    List<Rnprojagency> findByRprojinfoidIn(List<String> fids);

    /**
     * 获取上次抽取结果(招标的时候才回调用这个方法,暂时取得全部的)
     *
     * @param
     * @return com.sccin.spboot.domain.agency.Rnprojagency
     * @author WHLiang
     * @date 2018-12-28 9:21
     */
    @Query(value = "SELECT rnprojagency.* FROM etextracting,rnprojagency,etprojinfo " +
            "where etextracting.rprojid=rnprojagency.rprojinfoid and rnprojagency.rprojinfoid=etprojinfo.fid and EXTRACTVALUE(fmkeys,'/project/bidType/attribute::value')='1' and etextracting.fstep=3 " +
            "ORDER BY etextracting.ftime desc LIMIT 1",nativeQuery = true)
    Rnprojagency findLastResult();

    /**
     * 通过项目fid获取该结果
     *
     * @param projectId
     * @return com.sccin.spboot.domain.agency.Rnprojagency
     * @author WHLiang
     * @date 2018-12-28 14:29
     */
    Rnprojagency findByRprojinfoid(String projectId);
}
