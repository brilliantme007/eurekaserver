package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.Fileinfo;
import com.sccin.spboot.domain.moren.specific.FileinfoDao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class FileinfoReposityInterImpl implements FileinfoDao {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 点击文件管理按钮后进入页面的查询
     * 输入条件查询文件
     * @param pageable
     * @param name       文件名
     * @param storename 储存名
     * @param suffix     后缀名
     * @param starTime   起始时间
     * @param endTime     结束时间
     * @author meiyufei
     * @time   2018.8.26. 10:56
     * @return
     */
    @Override
    public Page<Fileinfo> findFileinfoByPage(Pageable pageable, String name, String storename, String suffix, String starTime, String endTime) {

        StringBuilder sb=new StringBuilder();
        sb.append("SELECT fid, fname, fstorename, fsuffix, fstoreplace, ftime ");
        sb.append("FROM etfileinfo ");
        sb.append("WHERE ftime BETWEEN :starTime AND :endTime ");
        if(name!=null&&!"".equals(name.trim())){
            sb.append("AND fname LIKE :name ");
        }
        if(storename!=null&&!"".equals(storename.trim())){
            sb.append("AND fstorename LIKE :storename ");
        }
        if(suffix!=null&&!"".equals(suffix.trim())){
            sb.append("AND fsuffix LIKE :suffix ");
        }
        sb.append("ORDER BY ftime DESC");

        Query query = entityManager.createNativeQuery(sb.toString());
        query.setParameter("starTime",starTime);
        query.setParameter("endTime",endTime);
        if(name!=null&&!"".equals(name.trim())){
            query.setParameter("name","%"+name+"%");
        }
        if(storename!=null&&!"".equals(storename.trim())){
            query.setParameter("storename","%"+storename+"%");
        }
        if(suffix!=null&&!"".equals(suffix.trim())){
            query.setParameter("suffix","%"+suffix+"%");
        }

        List<Object []> objs = query.getResultList();
        List<Fileinfo> fileinfoList=new ArrayList();
        int total=0;
        if(objs!=null && objs.size()!=0){
            total=objs.size();                       //总条数
            int pageStart = pageable.getPageNumber() * pageable.getPageSize();
            int pageEnd = pageStart + pageable.getPageSize() < total ? pageStart + pageable.getPageSize() : total;
            for (int i = pageStart; i < pageEnd; i++) {

                Object[] o = objs.get(i);
                Fileinfo fileinfo=new Fileinfo();
                fileinfo.setId((String) o[0]);
                fileinfo.setName((String) o[1]);
                fileinfo.setStorename((String) o[2]);
                fileinfo.setSuffix((String) o[3]);
                fileinfo.setStoreplace((String) o[4]);
                fileinfo.setTime((Timestamp)o[5]);
                fileinfoList.add(fileinfo);
            }
        }
        return new PageImpl(fileinfoList,pageable,total);
    }
}
