package com.sccin.spboot.web.front;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sccin.spboot.config.SysConfig;
import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.security.LogoutSuccessHandler;
import com.sccin.spboot.service.back.RoleService;
import com.sccin.spboot.service.back.UserService;
import com.sccin.spboot.utils.Escape;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.Utility;
import com.sccin.spboot.web.pojo.UlifyAuthReturn;
import com.sccin.spboot.web.pojo.UlifyRole;
import com.sccin.spboot.web.pojo.UlifyUser;
import com.sccin.spboot.web.pojo.UnifyLogoutReturn;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by developer_hyaci on 2018/5/15.
 * 统一登陆认证相关
 */
@Controller
public class UlifyLoginControl {

    public static Map<String,String> tokenWithId = new HashMap<>(); //维护第三方登录的token及对应本系统用户ID

    private static final String ULIFYAUTH="/api/account/auth";
    private static final String ULIFYLOGOUT="/api/account/logout";

    private static Logger logger = LoggerFactory.getLogger(UlifyLoginControl.class);
    private static final ObjectMapper mapper=new ObjectMapper();

    //第三方默认密码（不存库）
    public static final String DEFAULTPSD = "define20180516ulify";
    //回调API
    private final String returnApi = "/pub/ulify/loginCallback";

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private SysConfig sysConfig;

    @RequestMapping("/pub/ulify/loginCallback")
    public String ulifyCallBack(HttpServletRequest request, @Param("token") String token, @Param("logout") String logout, @RequestBody String body) {

        logger.info("统一用户体系回调成功，参数：token["+token+"],logout["+logout+"],body["+body+"]");

        String errorMsg = null;
        User user = null;

        if(StringUtils.isEmpty(logout) && !StringUtils.isEmpty(body)){    //标识为空解析body
            try {
                Map<String,Object> bodyMap = mapper.readValue(body,Map.class);
                token = bodyMap.get("token").toString();
                logout = bodyMap.get("logout").toString();
            } catch (IOException e) {
                errorMsg = "统一用户回调解析参数失败";
                logger.error(errorMsg + " token:"+token+" logout:"+logout+" body:"+body);
            }
        }

        if("false".equalsIgnoreCase(logout)) {  //登录标识
            //请求统一登陆的或退出校验接口返回统一登陆用户认证登陆成功通过之后一些必要信息
            if(StringUtils.isEmpty(sysConfig.getUlifyLoginDomain())||StringUtils.isEmpty(sysConfig.getUlifySystemid())|| StringUtils.isEmpty(sysConfig.getUlifyAreaid())){
                errorMsg="统一用户回调身份认证相关配置信息存在漏项";
                logger.error(errorMsg);
            }else {
                String result = this.webApiHttpsPostAuth(token);
                logger.info("统一用户回调身份认证校验token["+token+"],返回信息："+result);
                if(!StringUtils.isEmpty(result)){
                    try{
                        UlifyAuthReturn authReturn = mapper.readValue(result, UlifyAuthReturn.class);
                        //根据返回判定用户是否已在我们库里面存在，存在则删除用户与角色的关系，然后重新维护用户与角色的关系；
                        //不存在则初始化用户数据信息，然后维护用户与角色的关系；
                        if(authReturn != null && authReturn.getSuccess().equalsIgnoreCase("true")){
                            try{
                                user = this.maintainUser(authReturn);
                                if(user==null) errorMsg = "按照代码逻辑未成功生成USER对象";
                            }catch (Exception e){
                                if(e.getMessage().startsWith("ULIFYCODE")){
                                    errorMsg = e.getMessage();
                                    logger.error(errorMsg);
                                }else{
                                    errorMsg="统一用户回调身份认证根据校验返回信息维护信息时出现额外异常！";
                                    logger.error(errorMsg+e.getMessage());
                                }
                            }
                        }else {
                            errorMsg="统一用户回调身份认证返回失败："+authReturn.getMessage();
                        }
                    }catch (Exception e){
                        errorMsg="统一用户回调身份认证根据校验返回信息无法转换为约定对象！";
                        logger.error(errorMsg+e.getMessage());
                    }
                }else{
                    errorMsg="统一用户回调身份认证根据TOKEN校验无返回信息！";
                }
            }
        }else if("true".equalsIgnoreCase(logout)){  //登出标识
            //根据token获取用户并操作登出
            String userId = tokenWithId.get(token);
            if(userId != null){
                HttpSession session = Statements.getLoginSessionMapSession(userId);
                if(session != null) {
                    Statements.getLoginSessionMapSession(userId).setAttribute(LogoutSuccessHandler.NORMALSESSIONCLOSE,true);
                    Statements.getLoginSessionMapSession(userId).invalidate();
                    logger.info("统一用户回调退出成功,用户ID："+userId);
                }else{
                    logger.info("统一用户回调退出,用户ID："+userId+" 已退出");
                }
            }else{
                logger.warn("统一用户回调退出,token："+token+" 无对应用户信息");
            }
            return "ulify_logout";
        }else{  //标识无效
            errorMsg = "统一用户回调logout标识无效："+logout;
        }

        if(!StringUtils.isEmpty(errorMsg)){
            request.setAttribute("status","500");
            request.setAttribute("errMsg",errorMsg);
            return "back/error";
        }

        request.setAttribute("username",user.getLoginame());
        request.setAttribute("password",DEFAULTPSD);
        request.setAttribute("loginType","ulify");
        request.setAttribute("ulifyToken",token);
        request.setAttribute("ulifyToken_userType",user.getEmail());
        return "forward:/login.html";
    }

    @RequestMapping("/pub/ulify/logout")
    public String ulifyLogout(HttpServletRequest request){
        User user = UserService.getUserFromSession(request);
        if(user != null){
            if(!StringUtils.isEmpty(user.getBusysunique())){    //第三方用户
                Object token = request.getSession().getAttribute("ulifyToken");
                if(token != null){
                    String result = this.webApiHttpsPostLogout(token.toString());
                    logger.info("统一用户退出校验token["+token+"],返回信息："+result);
                    if(!StringUtils.isEmpty(result)){
                        try {
                            UnifyLogoutReturn logoutReturn = mapper.readValue(result,UnifyLogoutReturn.class);
                            if(logoutReturn != null && "true".equalsIgnoreCase(logoutReturn.getSuccess())){   //反馈成功
                                if(null != Statements.getLoginSessionMapSession(user.getId())){
                                    Statements.getLoginSessionMapSession(user.getId()).setAttribute(LogoutSuccessHandler.NORMALSESSIONCLOSE,true);
                                    Statements.getLoginSessionMapSession(user.getId()).invalidate();
                                }

                                return "redirect:"+sysConfig.getTurnToHomePageUrl()+"?"+System.currentTimeMillis();
                            }
                        } catch (IOException e) {
                            logger.error("统一用户退出根据校验返回信息无法转换为约定对象！"+e.getMessage());
                        }
                    }else{
                        logger.error("统一用户退出根据校验返回信息为空");
                    }
                }else {
                    request.getSession().invalidate();
                }
            }else{  //不存在三方唯一标识
                return "forward:/logout";
            }
        }
        return "forward:/loginSuccess.html";
    }

    private synchronized User maintainUser(UlifyAuthReturn authReturn) throws Exception{
        User user = this.userService.getUserByBusysUnique(authReturn.getData().getUserID());
        //本系统中已经存在该用户
        if(user!=null){
            //删除用户以及用户与角色的关系
            this.userService.delUser(user.getId());
        }
        List<String> authRoleCodes=new ArrayList<>();
        User user_define;
        UlifyUser ulifyUser = authReturn.getData();
        if(ulifyUser.getRole()!=null && ulifyUser.getRole().size()!=0){
            authRoleCodes.clear();
            for(UlifyRole role:ulifyUser.getRole()){
                authRoleCodes.add(role.getRoleID());
            }
            List<Role> roles=this.roleService.findByCodeIn(authRoleCodes);

            user_define=new User();
            user_define.setId(ulifyUser.getUserID());
            user_define.setName(ulifyUser.getLinkMan());
            user_define.setLoginame(ulifyUser.getUserID());
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            user_define.setPasd(passwordEncoder.encode(DEFAULTPSD));
            user_define.setRealname(ulifyUser.getLinkMan());
            user_define.setPhone(ulifyUser.getLinkPhone());
            user_define.setEmail(ulifyUser.getUserType());//当为统一登陆时该字段被重新定义用户储存用户类型:0,注册用户，1内部用户；
            user_define.setIsvalid(1);
            user_define.setIssys(0);
            user_define.setFailnum(0);
            user_define.setLogtime(Timestamp.valueOf(LocalDateTime.now()));
            user_define.setBusysunique(ulifyUser.getUserID());
            if(ulifyUser.getCaInfo() != null && ulifyUser.getCaInfo().size() > 0){
                user_define.setCa(ulifyUser.getCaInfo().get(0).getDn());    //默认保存第一个DN数据
            }else{
                //throw new Exception("ULIFYCODE校验当前用户不存在CA证书信息，请优先绑定CA证书信息！");
            }
            user_define.setExpend(Utility.replaceFexpend(user_define.getExpend(), "areaCode",ulifyUser.getUserAreaID()));

            if (roles!=null && roles.size()!=0){
                this.userService.saveUser(user_define,roles);
            }else{
                throw new Exception("ULIFYCODE根据校验返回信息角色列表在本库中无法查询角色数据！...");
            }
        }else {
            throw new Exception("ULIFYCODE校验返回信息不包含角色列表信息！...");
        }
        return user_define;
    }

    private class SSLClient extends DefaultHttpClient {
        public SSLClient() throws Exception{
            super();
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
                @Override
                public void checkServerTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };
            ctx.init(null, new TrustManager[]{tm}, null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx,SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            ClientConnectionManager ccm = this.getConnectionManager();
            SchemeRegistry sr = ccm.getSchemeRegistry();
            sr.register(new Scheme("https", 443, ssf));
        }
    }

    private String webApiHttpsPostAuth(String token){
        return this.webApiHttpsPost(
                sysConfig.getUlifyLoginDomain()+ULIFYAUTH,
                token,
                "{\"systemid\":\""+sysConfig.getUlifySystemid()+"\",\"areaid\":\""
                        +sysConfig.getUlifyAreaid()+"\",\"returnurl\":\""+Escape.escape(sysConfig.getProjectHost()+returnApi)+"\"}");
    }
    private String webApiHttpsPostLogout(String token){
        return this.webApiHttpsPost(
                sysConfig.getUlifyLoginDomain()+ULIFYLOGOUT,
                token,
                "{\"systemid\":\""+sysConfig.getUlifySystemid()+"\",\"areaid\":\""
                        +sysConfig.getUlifyAreaid()+"\",\"returnurl\":\""+Escape.escape(sysConfig.getProjectHost()+returnApi)+"\"}");
    }
    private String webApiHttpsPost(String url,String token,String jsonstr){
        String result = null;
        try{
            HttpClient httpClient = new SSLClient();
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-Type", "application/json");
            httpPost.addHeader("Authorization","Bearer " + token);
            StringEntity se = new StringEntity(jsonstr);
            se.setContentType("text/json");
            se.setContentEncoding(new BasicHeader("Content-Type", "application/json"));
            httpPost.setEntity(se);
            logger.info("POST请求地址："+url+" 请求参数："+jsonstr);
            HttpResponse response = httpClient.execute(httpPost);
            if(response != null){
                HttpEntity resEntity = response.getEntity();
                if(resEntity != null){
                    result = EntityUtils.toString(resEntity,"utf-8");
                }
            }
            logger.info("POST响应实体："+response+" 字符串:"+result);
        }catch(Exception ex){
            ex.printStackTrace();
            logger.error("webApiHttpsPost请求函数异常："+ex.getMessage());
        }
        return result;
    }
}
