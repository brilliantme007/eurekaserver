package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.Fileinfo;
import com.sccin.spboot.domain.moren.specific.FileinfoDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface FileinfoReposityInter extends FileinfoDao,JpaRepository<Fileinfo,String>,JpaSpecificationExecutor<Fileinfo> {

    /**
     * 点击编辑按钮后根据选择的文件id查询对应的信息
     * @param fid
     * @return
     */
    @Query(value = "select fid,fname,fstorename,fsuffix,fstoreplace,ftime from etfileinfo where fid =:fid ",nativeQuery = true)
    Fileinfo findOneById(@Param("fid") String fid);


    @Query(value="select fid,fname,fstorename,fsuffix,fstoreplace,ftime from etfileinfo where fid in :ables",nativeQuery = true)
    List<Fileinfo> findAll(List<String> ables);

    /**
     * 用业务类型（1视频、2封面）和三方标识查文件
     * @param fquoteunique 三方标识
     * @return
     */
    @Query(value="SELECT fi.* FROM rnfiledepend fa, etfileinfo fi where fa.rfileinfoid = fi.fid and fa.fquotetype = ?1 and fa.fquoteunique = ?2",nativeQuery = true)
    Fileinfo findOneBy(String fquotetype, String fquoteunique);
}
