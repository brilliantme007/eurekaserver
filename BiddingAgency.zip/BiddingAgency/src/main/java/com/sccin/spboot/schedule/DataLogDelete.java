package com.sccin.spboot.schedule;

import com.sccin.spboot.config.SysConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * Created by YF-Zhangbo on 2017/10/17.
 */

public class DataLogDelete {
    /*@Autowired
    LogsService logsService;*/
    @Autowired
    SysConfig sysConfig;
    
    /**
     * 每日凌晨两点删除数据库中一些时间之前的可删除日志记录和删除一些时间之前的所有日志
     */
    @Scheduled(cron = "0 0/2 * * * ?")
    public void deleteLogAMonthAgo() {
        System.out.println("deleteLogAMonthAgo。。。。。。。。。。");
        /*Calendar calendar = Calendar.getInstance();//日历对象
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (sysConfig.getDeleteEnableDeleteLogDate() != null && !sysConfig.getDeleteEnableDeleteLogDate().trim().equals("")) {
            try {
                int deleteEnableDeleteLogDate = new Integer(sysConfig.getDeleteEnableDeleteLogDate());
                calendar.setTime(new Date());//设置当前日期
                calendar.add(Calendar.DATE, -deleteEnableDeleteLogDate);//这些天之前的
                Date date = calendar.getTime();
                String dateString = sdf.format(date);
                logsService.deleteLogBeforeDate(dateString);
            } catch (NumberFormatException e) {
                throw new NumberFormatException("配置文件中deleteEnableDeleteLogDate删除日志的时间只能为正整数;" + e.getMessage());
            }
        }
        if (sysConfig.getDeleteAllLogMonth() != null && !sysConfig.getDeleteAllLogMonth().trim().equals("")) {
            try {
                int deleteAllLogMonth = new Integer(sysConfig.getDeleteAllLogMonth());
                calendar.setTime(new Date());//设置当前日期
                calendar.add(Calendar.MONTH, -deleteAllLogMonth);//这些月之前的
                Date dateMonth = calendar.getTime();
                String dateQuarterString = sdf.format(dateMonth);
                logsService.deleteLogBeforeDateAll(dateQuarterString);
            } catch (NumberFormatException e) {
                throw new NumberFormatException("配置文件中deleteAllLogMonth删除日志的时间只能为正整数;" + e.getMessage());
            }
        }*/
    }
}
