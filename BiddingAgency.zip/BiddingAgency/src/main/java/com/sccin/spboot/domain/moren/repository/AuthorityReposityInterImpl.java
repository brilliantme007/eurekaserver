package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.specific.AuthorityDao;
import com.sccin.spboot.utils.StringUtil;
import org.springframework.security.access.ConfigAttribute;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * Created by CPYF-Yi Mao on 2018-08-28.
 */
public class AuthorityReposityInterImpl implements AuthorityDao {

    @PersistenceContext(name = "entityManagerPrimary")
    private EntityManager entityManager;

    @Override
    public HashMap<String, Collection<ConfigAttribute>> getAllSpecificAuthority() {
        String basesql ="SELECT auth.furl,GROUP_CONCAT(role.crolecode) AS rolecodes " +
                        "FROM etauthority auth " +
                        "LEFT JOIN rnroleauths role ON auth.fid = role.rauthorityid " +
                        "WHERE auth.furl != '0' " +
                        "GROUP BY auth.furl";
        Query query = entityManager.createNativeQuery(basesql);
        List<Object[]> list = query.getResultList();
        HashMap<String, Collection<ConfigAttribute>> result = new HashMap<>();
        for(Object[] objs : list){
            String url = StringUtil.getString(objs[0]);
            String rolecodes = StringUtil.getString(objs[1]);
            if(!StringUtil.isAnyEmpty(url,rolecodes)){
                List<ConfigAttribute> templist = new ArrayList<>();
                for(String rolecode : rolecodes.split(",")){
                    templist.add(()->{  return rolecode;  });
                }
                result.put(url,templist);
            }
        }
        return result;
    }
}
