package com.sccin.spboot.web.endpoint.dto.recv;

import com.sccin.spboot.utils.ValidUtils;

/**
 * Created by CPYF-Yi Mao on 2018-09-27.
 */
public class RoomInfo {

    @ValidUtils.Check(describe = "地区编码",regex = ValidUtils.regex.areacode)
    private String areacode;        //地区编码

    public String getAreacode() {
        return areacode;
    }

    public void setAreacode(String areacode) {
        this.areacode = areacode;
    }
}
