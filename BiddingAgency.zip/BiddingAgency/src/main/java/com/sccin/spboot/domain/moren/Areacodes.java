package com.sccin.spboot.domain.moren;

import javax.persistence.*;

@Entity
@Table(name = "etareacodes")
public class Areacodes {
    private String fid;
    private String fcode;
    private String fareaname;
    private String fpcode;

    @Id
    @Column(name = "FID", nullable = false, insertable = true, updatable = true, length = 50)
    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

    @Basic
    @Column(name = "FCODE", nullable = true, insertable = true, updatable = true, length = 50)
    public String getFcode() {
        return fcode;
    }

    public void setFcode(String fcode) {
        this.fcode = fcode;
    }

    @Basic
    @Column(name = "FAREANAME", nullable = true, insertable = true, updatable = true, length = 256)
    public String getFareaname() {
        return fareaname;
    }

    public void setFareaname(String fareaname) {
        this.fareaname = fareaname;
    }

    @Basic
    @Column(name = "FPCODE", nullable = true, insertable = true, updatable = true, length = 50)
    public String getFpcode() {
        return fpcode;
    }

    public void setFpcode(String fpcode) {
        this.fpcode = fpcode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Areacodes areacodes = (Areacodes) o;

        if (fid != null ? !fid.equals(areacodes.fid) : areacodes.fid != null) return false;
        if (fcode != null ? !fcode.equals(areacodes.fcode) : areacodes.fcode != null) return false;
        if (fareaname != null ? !fareaname.equals(areacodes.fareaname) : areacodes.fareaname != null) return false;
        if (fpcode != null ? !fpcode.equals(areacodes.fpcode) : areacodes.fpcode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = fid != null ? fid.hashCode() : 0;
        result = 31 * result + (fcode != null ? fcode.hashCode() : 0);
        result = 31 * result + (fareaname != null ? fareaname.hashCode() : 0);
        result = 31 * result + (fpcode != null ? fpcode.hashCode() : 0);
        return result;
    }
}
