package com.sccin.spboot.service.third.dto.prm;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by jun.li on 2016/8/31.
 */
public class Prm2004 {

    /**
     * 统一六位地区编码
     */
    @JsonProperty(value = "AreaID")
    private String areaID;

    /**
     * 预先设置好的系统编码
     */
    @JsonProperty(value = "SystemID")
    private String systemID;

    public Prm2004() {
    }

    public String getAreaID() {
        return areaID;
    }

    public void setAreaID(String areaID) {
        this.areaID = areaID;
    }

    public String getSystemID() {
        return systemID;
    }

    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }
}
