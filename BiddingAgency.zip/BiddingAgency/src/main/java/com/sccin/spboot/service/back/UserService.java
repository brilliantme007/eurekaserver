package com.sccin.spboot.service.back;

import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.Userrole;
import com.sccin.spboot.domain.moren.repository.UserReposityInter;
import com.sccin.spboot.domain.moren.repository.UserRoleReposityInter;
import com.sccin.spboot.security.pojo.SecurityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by yx on 2018/8/27.
 */
@Service("userService")
public class UserService {

    @Autowired
    private UserReposityInter userReposity;
    @Autowired
    private UserRoleReposityInter userRoleReposityInter;
    @Autowired
    private RoleService roleService;


    /**
     * 采用SPRING SECURITY 之后，当前登陆用户会储存在SESSION里面
     * 该方法为获取当前登陆的User用户；
     * @return bean|null
     * */
    public static User getUserFromSession(HttpServletRequest request){
        SecurityUser securityUser = getSecurityUserFromSession(request);
        return securityUser == null ? null : securityUser.getLoginUser();
    }

    /**
     * 采用SPRING SECURITY 之后，当前登陆用户会储存在SESSION里面
     * 该方法为获取当前登陆的SecurityUser用户；
     * @return bean|null
     * */
    public static SecurityUser getSecurityUserFromSession(HttpServletRequest request){
        SecurityUser securityUser =null;
        if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")!=null){
            SecurityContext securityContext= (SecurityContextImpl)request.getSession().getAttribute("SPRING_SECURITY_CONTEXT");
            Authentication auth=securityContext.getAuthentication();
            securityUser = (SecurityUser)auth.getPrincipal();
        }
        return securityUser;
    }

    public User detailUser(String fid){
        return userReposity.findUserById(fid);
    }

    public User findOne(String fid){
        Optional<User> u = userReposity.findById(fid);
        if(u.isPresent()){
            return  u.get();
        }
        return null;
    }

    public String findRoleNames(String userId){
        List<String> userList=new ArrayList<>();
        userList.add(userId);
        return userReposity.queryRoleNames(userList).get(userId);
    }

    public Page<User> queryUserList(String userName, Pageable pageable){
        Page<User> userPage = userReposity.queryUserList(userName,pageable);
        if(userPage!=null && userPage.getContent()!=null && userPage.getContent().size()>0){
            StringBuilder sb = new StringBuilder();
            List<String> userIdList = new ArrayList<>();
            for(User u:userPage.getContent()){
                userIdList.add(u.getId());
            }
            Map<String,String> result = userReposity.queryRoleNames(userIdList);
            if(result!=null){
                for(User u:userPage.getContent()){
                    String roleNames = result.get(u.getId());
                    if(roleNames!=null && !"".equals(roleNames)){
                        u.setRoleName(roleNames.substring(0,roleNames.length()-1));
                    }
                }
            }
        }
        return userPage;
    }

    public String verifyUserFsyslname(String fsyslname){
        User user = userReposity.findByLoginame(fsyslname);
        String msg = "";
        if (user != null && !user.toString().equals("")) {
            msg = "该登录名已存在";
        } else{
            msg = "success";
        }
        return msg;
    }

    @Transactional
    public boolean saveUser(User user,List<Role> role,List<Userrole> userrole){
        if(role!=null ){
            if(userrole!=null && userrole.size()>0){
                userRoleReposityInter.deleteAll(userrole);
            }
            List<Userrole> saveList = new ArrayList<>();
            if(role.size()>0){
                for(Role r:role){
                    Userrole ur = new Userrole();
                    String roleid = r.getId();
                    String rolecode = r.getCode();
                    ur.setId(UUID.randomUUID().toString());
                    ur.setUserid(user.getId());
                    ur.setRolecode(rolecode);
                    ur.setRoleid(roleid);
                    saveList.add(ur);
                }
            }
            userReposity.save(user);
            userRoleReposityInter.saveAll(saveList);
            return true;
        }else{
            return false;
        }
    }


    @Transactional
    public boolean saveUser(User user,List<Role> role){
        if(role!=null && user!=null){
            List<Userrole> saveList = new ArrayList<>();
            if(role.size()>0){
                for(Role r:role){
                    Userrole ur = new Userrole();
                    String roleid = r.getId();
                    String rolecode = r.getCode();
                    ur.setId(UUID.randomUUID().toString());
                    ur.setUserid(user.getId());
                    ur.setRolecode(rolecode);
                    ur.setRoleid(roleid);
                    saveList.add(ur);
                }
            }
            userReposity.save(user);
            userRoleReposityInter.saveAll(saveList);
            return true;
        }else{
            return false;
        }
    }

    @Transactional
    public boolean delUser(String userId){
        List<Userrole> userrole = roleService.queryUserRoleByUserId(userId);
        if(userrole!=null){
            userReposity.deleteById(userId);
            userRoleReposityInter.deleteAll(userrole);
            return true;
        }else {
            return false;
        }
    }

    public List<Map<String,String>> getUserByRoleIds(String roleids){
        return this.userReposity.getUserByRoleIds(roleids);
    }
    public User getUserByBusysUnique(String busysunique){
        return this.userReposity.findByBusysunique(busysunique);
    }
    public List<Userrole> getUserRolesByUserid(String userid){
        return this.userRoleReposityInter.queryRoleByCode(userid);
    }
}
