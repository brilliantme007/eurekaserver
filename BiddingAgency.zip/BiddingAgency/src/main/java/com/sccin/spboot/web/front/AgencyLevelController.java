package com.sccin.spboot.web.front;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sccin.spboot.domain.agency.Etagencylevel;
import com.sccin.spboot.domain.moren.Authority;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.security.LoginUserDetailsService;
import com.sccin.spboot.service.back.UserService;
import com.sccin.spboot.service.front.AgencyLevelService;
import com.sccin.spboot.utils.AjaxReturnBean;
import com.sccin.spboot.utils.Statements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author MeiYF
 * 库级别的管理Controller
 * 2018/12/26 17:52
 **/
@Controller
public class AgencyLevelController  {
     /**
     * 用于在编辑时存数据用
     */
	private static Map<String, String>  flageMap = new HashMap<>();
	/**
     * ObjectMapper,用于转换其他元素为json
     */
	public static final ObjectMapper MAPPER = new ObjectMapper();
	/**
     * 日志记录LOGGER
     */
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(AgencyLevelController.class);
	/**
     * 库级别service
     */
	private AgencyLevelService agencyLevelService;
	@Autowired
	public AgencyLevelController(AgencyLevelService agencyLevelService) {
		this.agencyLevelService = agencyLevelService;
	}
	/**
	 * 用户登录详细信息service
	 */
	@Autowired
	private LoginUserDetailsService loginUserDetailsService;
	/**
	 * 点击库级别管理菜单跳转页面
	 * @param request 请求
	 * @param model   model
	 * @return        返回
	 */
	@GetMapping("/loginAgencylevel.html")
	public String turnToAgencyLevHtml(HttpServletRequest request, Model model) {
		User user = UserService.getUserFromSession(request);
		List<Authority> authorityList = loginUserDetailsService.getLoginUserAuths(user.getId());
		if (authorityList != null && !authorityList.isEmpty()) {
			for (Authority authority : authorityList) {
				String url = authority.getUrl();
				if ("/loginagencyLevelAdd.html".equals(url)) {
					//新增
					model.addAttribute("addAuth", Boolean.TRUE);
				} else if ("/loginDeleteAgencyLev".equals(url)) {
					//删除
					model.addAttribute("deletAuth", Boolean.TRUE);
				} else if ("/loginagencyLevelEdit.html".equals(url)) {
					//编辑
					model.addAttribute("edittAuth", Boolean.TRUE);
				}
			}
		}
		return "/front/views/app/agencyLevel-repository/agencyLevel-repository";
	}


	/**
     * 查询库级别信息
     * @param page   当前页面需要跳转到的第几页
     * @param limit  每页显示多少条
     * @param fname  库级别名称
     * @param flevel 库级别数
     * @return       返回
     */
	@PostMapping("/loginSelectAgencylevelMess")
	@ResponseBody
	public String selectAgencylevelMess(@Param("page") int page, @Param("limit") int limit,
										@Param("fname") String fname, @Param("flevel") String flevel) {
		Map<String, Object> returnMap = new HashMap<>(4);
		try {

			//状态判断，当从一个状态切换到另外一个状态后，重新赋值page = 1
			boolean flage = Statements.STATMAP.containsKey("flage");
			if ((fname == null || "".equals(fname)) && (flevel == null || "".equals(flevel))) {
				if (flage) {
					int numFlage = Statements.STATMAP.get("flage");
					if (numFlage != 1) {
						Statements.STATMAP.put("flage", 1);
						page = 1;
					}
				} else {
					Statements.STATMAP.put("flage", 1);
				}
			}
			if ((fname != null && !"".equals(fname)) && (flevel != null && !"".equals(flevel))) {
				if (flage) {
					int numFlage = Statements.STATMAP.get("flage");
					if (numFlage != 2) {
						Statements.STATMAP.put("flage", 2);
						page = 1;
					}
				} else {
					Statements.STATMAP.put("flage", 2);
				}
			}
			if ((fname != null && !"".equals(fname)) && (flevel == null || "".equals(flevel))) {
				if (flage) {
					int numFlage = Statements.STATMAP.get("flage");
					if (numFlage != 3) {
						Statements.STATMAP.put("flage", 3);
						page = 1;
					}
				} else {
					Statements.STATMAP.put("flage", 3);
				}
			}
			if ((fname == null || "".equals(fname)) && (flevel != null && !"".equals(flevel))) {
				if (flage) {
					int numFlage = Statements.STATMAP.get("flage");
					if (numFlage != 4) {
						Statements.STATMAP.put("flage", 4);
						page = 1;
					}
				} else {
					Statements.STATMAP.put("flage", 4);
				}
			}

			//查询数据
			Map<String, Object> etAgencyLevelMap = agencyLevelService.selectAgencylevelMess(page, limit, fname, flevel);
			int total = (int) etAgencyLevelMap.get("total");
			List<Etagencylevel> etagencylevelList = (List<Etagencylevel>) etAgencyLevelMap.get("etAgencyLevelList");
			if (etagencylevelList.isEmpty()) {
				//没有数据的时候
				returnMap.put("code", 1);
				returnMap.put("msg", "暂无数据!");
				returnMap.put("count", 0);
				returnMap.put("data", "");
			} else {
				//有数据的时候
				returnMap.put("code",  0);
				returnMap.put("msg", "");
				returnMap.put("count", total);
				returnMap.put("data", etagencylevelList);
			}
		} catch (Exception e) {
			LOGGER.info("在【" + AgencyLevelController.getLogtime() + "】查询库级别信息失败：" + e.getMessage());
			returnMap.put("code", 1);
			returnMap.put("msg", "查询库级别信息失败!请重试或联系管理员。");
			returnMap.put("count", 0);
			returnMap.put("data", "");
		}

		//将map转json
		String returnJson = null;
		try {
			returnJson = MAPPER.writeValueAsString(returnMap);
		} catch (JsonProcessingException e) {
			LOGGER.info("在【" + AgencyLevelController.getLogtime() + "】查询数据转换json失败：" + e.getMessage());
		}
		return returnJson;
	}

	/**
     * 点击新增库级别管理按钮弹出新增框
     * @return 返回
     */
	@GetMapping("/loginagencyLevelAdd.html")
	public String addAgencyLevHtml() {
		return "/front/views/app/agencyLevel-repository/addAgencyLevelListForm";
	}


	/**
     * 新增库级别信息
     * @param fname  库级别名称
     * @param flevel 库级别数
     * @return       返回
     */
	@PostMapping("/loginAddAgencyLev")
	@ResponseBody
	public AjaxReturnBean addAgencyLev(@Param("fname") String fname, @Param("flevel") String flevel) {

		//调用方法进行字段判断和信息重复性判断
		boolean addOrEdit = true;
		int flage = this.checkNewAgencyLevMess("", fname, flevel, addOrEdit);
		if (flage == 0) {
			return AjaxReturnBean.createError("输入的库级别名称不能为空！");
		} else if (flage == 1) {
			return AjaxReturnBean.createError("选择的库级别不能为空！");
		} else if (flage == 2) {
			return AjaxReturnBean.createError("已经存在相同的库级别名称，请重新输入！");
		} else if (flage == 5) {
			return AjaxReturnBean.createError("新增失败！");
		}

		//存库
		Etagencylevel etagencylevel = new Etagencylevel();
		etagencylevel.setFid(UUID.randomUUID().toString());
		etagencylevel.setFname(fname);
		etagencylevel.setFlevel(Integer.parseInt(flevel));
		try {
			agencyLevelService.saveAgencyLevMess(etagencylevel);
			LOGGER.info("在【" + AgencyLevelController.getLogtime() + "】成功新增一条id为【" + etagencylevel.getFid() + "】的库级别信息。");
			return AjaxReturnBean.createSuccess("新增数据成功！");
		} catch (Exception e) {
			LOGGER.error("在【" + AgencyLevelController.getLogtime() + "】新增一条库级别信息时失败：" + e.getMessage());
		}
		return AjaxReturnBean.createError("新增失败！");
	}


	/**
     * 根据id删除一条库级别信息
     * @param fid 主键id
     * @return    返回
     */
	@PostMapping("/loginDeleteAgencyLev")
	@ResponseBody
	public AjaxReturnBean deleteAgencyLev(@Param("fid") String fid) {
		try {
			agencyLevelService.deleteAgencyLevById(fid);
			LOGGER.info("在【" + AgencyLevelController.getLogtime() + "】成功删除一条id为【" + fid + "】的库级别信息。");
			return AjaxReturnBean.createSuccess("删除成功！");
		} catch (Exception e) {
			LOGGER.error("在【" + AgencyLevelController.getLogtime() + "】删除一条id为【" + fid + "】的库级别信息时失败：" + e.getMessage());
		}
		return AjaxReturnBean.createError("删除失败！请重试或联系管理员。");
	}


	/**
     * 点击编辑按钮后且还有没弹出编辑框时存放数据到静态Map
     * @param fid     主键id
     * @param fname   库级别名字
     * @param flevel  库的级别
     * @return        返回
     */
	@PostMapping("/pub/loginGetAgencyMess")
	@ResponseBody
	public AjaxReturnBean getAgencyMess(@Param("fid") String fid, @Param("fname") String fname, @Param("flevel") String flevel) {
		flageMap.put("fid", fid);
		flageMap.put("fname", fname);
		flageMap.put("flevel", flevel);
		return AjaxReturnBean.createSuccess("");
	}


	/**
     * 点击编辑库级别管理按钮弹出编辑框
     * @param model model
     * @return      返回
     */
	@GetMapping("/loginagencyLevelEdit.html")
	public String editAgencyLevHtml(Model model) {
		model.addAttribute("fid", flageMap.get("fid"));
		model.addAttribute("fname", flageMap.get("fname"));
		model.addAttribute("flevel", flageMap.get("flevel"));
		return "/front/views/app/agencyLevel-repository/agencyLevelListForm";
	}

	/**
     * 编辑库级别信息
     * @param fid    唯一标识
     * @param fname  库级别名称
     * @param flevel 库的级别
     * @return       返回
     */
	@PostMapping("/editAgencyLev")
	@ResponseBody
	public AjaxReturnBean editAgencyLev(@Param("fid") String fid, @Param("fname") String fname, @Param("flevel") String flevel) {

		//调用方法进行字段判断和信息重复性判断
		boolean addOrEdit = false;
		int flage = this.checkNewAgencyLevMess(fid, fname, flevel, addOrEdit);
		if (flage == 0) {
			return AjaxReturnBean.createError("输入的库级别名称不能为空！");
		} else if (flage == 1) {
			return AjaxReturnBean.createError("选择的库级别不能为空！");
		} else if (flage == 4) {
			return AjaxReturnBean.createError("数据id获取失败，请联系管理员！");
		} else if (flage == 2) {
			return AjaxReturnBean.createError("已经存在相同的库级别名称，请重新输入！");
		} else if (flage == 5) {
			return AjaxReturnBean.createError("编辑数据失败！");
		}

		//存库
		Etagencylevel etagencylevel = new Etagencylevel();
		etagencylevel.setFid(fid);
		etagencylevel.setFname(fname);
		etagencylevel.setFlevel(Integer.parseInt(flevel));
		try {
			agencyLevelService.saveAgencyLevMess(etagencylevel);
			LOGGER.info("在【" + AgencyLevelController.getLogtime() + "】成功编辑一条id为【" + fid + "】的库级别信息。");
			return AjaxReturnBean.createSuccess("编辑数据成功！");
		} catch (Exception e) {
			LOGGER.error("在【" + AgencyLevelController.getLogtime() + "】编辑一条id为【" + fid + "】的库级别信息时失败：" + e.getMessage());
		}
		return AjaxReturnBean.createError("编辑数据失败！");
	}


	/**
     * 用于新增和编辑时判断非空和重复性校验的公共方法
     * @param fid        主键id
     * @param fname      库级别名称
     * @param flevel     库级别数
     * @param addOrEdit  用于判断是新增进来的还是编辑进来的，true:新增进来的 false：编辑进来的
     * @return           返回
     *   返回code说明：  0：输入的库级别名称为空
     *                   1：输入的库级别为空
     *                   2: 已经存在相同数据
     *                   3：编辑时没有修改数据就保存了
     *                   4：编辑时库级别的id没有取到
     *                   5：失败
     *                   6：可以存库的数据
     */
	public int checkNewAgencyLevMess(String fid, String fname, String flevel, boolean addOrEdit) {
		if (!addOrEdit) {
			if ((fid == null || "".equals(fid))) {
				//编辑时库级别的id没有取到
				return 4;
			}
		}
		//先判断输入信息是否为空
		if ((fname == null || "".equals(fname))) {
			//输入的库级别名称为空
			return 0;
		}
		if ((flevel == null || "".equals(flevel))) {
			//输入的库级别为空
			return 1;
		}

		//重复性校验
		try {
			Etagencylevel etagencylevel = agencyLevelService.checkRepeat(fname);
			if (etagencylevel != null) {
				if (addOrEdit) {
					//新增
					//已经存在同名的库
					return 2;
				} else {
					//编辑
					if (etagencylevel.getFid().equals(fid)) {
						//没有修改数据
						return 3;
					} else {
						//已经存在同名的库
						return 2;
					}
				}
			} else {
				return 6;
			}
		} catch (Exception e) {
			LOGGER.error("在【" + AgencyLevelController.getLogtime() + "】对" + (addOrEdit == true ? "新增的" : "编辑的") + "数据"
					+ "进行重复性校验时失败：" + e.getMessage());
		}
		return 5;
	}


	/**
     * 记录日志时间
     * @return   返回
     */
	private static String getLogtime() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
	}
}
