package com.sccin.spboot.web.front;

import com.sccin.spboot.config.SysConfig;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.security.pojo.DefineAuthItem;
import com.sccin.spboot.security.pojo.DefineGrantedAuthority;
import com.sccin.spboot.security.pojo.SecurityUser;
import com.sccin.spboot.service.back.UserService;
import com.sccin.spboot.utils.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Created by yx on 2018/8/28.
 */
@Controller
public class HtmlControl {

    @Autowired
    private SysConfig sysConfig;

    @RequestMapping("/webback.html")
    public String webback(HttpServletRequest request){
        HttpSession session = request.getSession();
        //访问WEB管理页面
        if(session.getAttribute("userMap") == null){
            SecurityUser securityUser = UserService.getSecurityUserFromSession(request);
            List<DefineAuthItem> webAuths = new ArrayList<>();
            if(securityUser != null){
                User user = securityUser.getLoginUser();
                String roleNames = "";
                Iterator itor = securityUser.getAuthorities().iterator();
                while(itor.hasNext()){
                    roleNames += ","+((DefineGrantedAuthority)itor.next()).getRoleName();
                }
                Map<String,String> userMap = new HashMap<>();
                userMap.put("userName",user.getName());
                userMap.put("lastLoginTime",Utility.formatTimestamp(user.getLastlogintime(),Utility.TimeFomat.DATETIMEFOMAT));
                userMap.put("roleNames",roleNames.substring(1));
                userMap.put("homePage",sysConfig.getTurnToHomePageUrl());
                List<DefineAuthItem> allAuths = securityUser.getAllAuthsTree();
                for(DefineAuthItem auth : allAuths){
                    //type 2 为表示WEB顶级菜单
                    if(auth.getAuthorityBean().getUrl().equals("0") &&
                            auth.getAuthorityBean().getType().intValue() == 2){
                        webAuths.add(auth);
                    }
                }
                request.getSession().setAttribute("webAuths",webAuths);
                request.getSession().setAttribute("pageMap",userMap);
            }
        }
        return "front/views/index";
    }
}
