package com.sccin.spboot.service.front;

import com.sccin.spboot.domain.agency.Etagencylevel;
import com.sccin.spboot.domain.agency.repository.AgencyLevelReposityInter;
import com.sccin.spboot.service.back.FileinfoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @author MeiYF
 * 2018/12/26 20:55
 * 库级别service
 **/
@Service("agencyLevelService")
public class AgencyLevelService  {

	@Autowired
	private FileinfoService fileinfoService;

	/**
	 * 库级别的repository
	 */
	@Autowired
	private AgencyLevelReposityInter agencyLevelReposityInter;
	public AgencyLevelService(AgencyLevelReposityInter agencyLevelReposityInter)  {
		this.agencyLevelReposityInter = agencyLevelReposityInter;
	}


	/**
	 * 查询库级别信息
	 * @param page   当前页面需要跳转到的第几页
	 * @param limit  每页显示多少条
	 * @param fname  库级别名称
	 * @param flevel 库级别数
	 * @return       返回
	 */
	public Map<String, Object> selectAgencylevelMess(int page, int limit, String fname, String flevel)  {
		return agencyLevelReposityInter.selectAgencylevelMess(page, limit, fname, flevel);
	}

	/**
	 * 对输入的库级别信息进行重复性校验
	 * @param fname  库级别名称
	 * @return       返回
	 */
	public Etagencylevel checkRepeat(String fname) {
		return agencyLevelReposityInter.findByFname(fname);
	}


	/**
	 * 新增一条库级别信息
	 * @param etagencylevel 库级别对象
	 */
	public void saveAgencyLevMess(Etagencylevel etagencylevel) {
		agencyLevelReposityInter.save(etagencylevel);

		// 如果库级别变动，清空代理级别缓存
		fileinfoService.clearLevelValueMap();
	}

	/**
	 * 根据id删除一条库级别信息
	 * @param fid  主键id
	 */
	@Transactional
	public void deleteAgencyLevById(String fid) {
		agencyLevelReposityInter.deleteById(fid);

		// 如果库级别变动，清空代理级别缓存
		fileinfoService.clearLevelValueMap();
	}

	public List<Etagencylevel> getAllLevelList(){
		return agencyLevelReposityInter.findAll();
	}

	/**
	 * 根据级别查询对应的ID值
	 * @param level
	 * @return
	 */
    public String findIdByLevel(Object level) {
        return agencyLevelReposityInter.findIdByLevel(level);
    }

}
