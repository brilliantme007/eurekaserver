package com.sccin.spboot.service.third.dto;

/**
 * Created by hejundi on 2016/8/31.
 */
public class Request<T> {
    /**
     * 为接口已约定好的方法ID
     */
    private Integer cod;
    /**
     * 为接口已约定好的方法名称
     */
    private String name;
    /**
     * 使用与服务端已约定好的3DES加密后的ts值
     */
    private String sig;
    /**
     * 用于客户端和服务器进行交换使用
     */
    private String ts;
    /**
     * 为接口已约定好的方法ID
     */
    private T prm;

    public Request() {
    }

    public Integer getCod() {
        return cod;
    }

    public void setCod(Integer cod) {
        this.cod = cod;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSig() {
        return sig;
    }

    public void setSig(String sig) {
        this.sig = sig;
    }

    public String getTs() {
        return ts;
    }

    public void setTs(String ts) {
        this.ts = ts;
    }

    public T getPrm() {
        return prm;
    }

    public void setPrm(T prm) {
        this.prm = prm;
    }
}
