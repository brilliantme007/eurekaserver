package com.sccin.spboot.config;

import com.sccin.spboot.domain.moren.repository.AuthorityReposityInter;
import com.sccin.spboot.utils.RSAUtils;
import com.sccin.spboot.utils.Statements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;

/**
 * Created by developer_hyaci on 2016/3/23.
 */
public class StartupListener implements ApplicationListener<ContextRefreshedEvent> {

    private final static Logger logger = LoggerFactory.getLogger(StartupListener.class);

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        //application配置文件
        SysConfig sysConfig = event.getApplicationContext().getBeansOfType(SysConfig.class).get("sysConfig");

        long start=0;
        long end=0;
        logger.info("===================>>>Start some system codes that can be executing......");
        //项目启动之后初始化一对RSA公私钥，用于处理前台UI往后台传输敏感数据时进行密文传输；
        logger.info("===================>>>Start rsaPairs。");
        //维护一对公私钥；
        start=System.currentTimeMillis();
        try{
            HashMap mapRsa= RSAUtils.getKeys();
            // keys:modulus|public_exponent|publicKey|privateKey
            Statements.rsaPairs.put("publicKey",(RSAPublicKey) mapRsa.get("public"));
            Statements.rsaPairs.put("privateKey",(RSAPrivateKey) mapRsa.get("private"));
            Statements.rsaPairs.put("modulus", Statements.getRSAPubKey().getModulus().toString(16));
            Statements.rsaPairs.put("public_exponent",Statements.getRSAPubKey().getPublicExponent().toString(16));
            mapRsa=null;
        }catch (Exception e){
            logger.error("project creating！but the rsa pairs build a exception:"+e.getMessage());
            logger.error("system exit!!");
            System.exit(0);
        }
        end=System.currentTimeMillis();
        logger.info("===================>>>End rsaPairs,cast["+(end-start)+"]MS。");

        logger.info("===================>>>Start init authResourses。");
        //加载所有权限；
        start=System.currentTimeMillis();

        AuthorityReposityInter authorityReposityInter = event.getApplicationContext().getBean(AuthorityReposityInter.class);
        Statements.requestMap.putAll(authorityReposityInter.getAllSpecificAuthority());

        end=System.currentTimeMillis();
        logger.info("===================>>>End init authResourses,cast["+(end-start)+"]MS。");



        logger.info("===================>>>End some system codes that can be executing 。");
    }
}
