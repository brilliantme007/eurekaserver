package com.sccin.spboot.security;

import com.sccin.spboot.utils.StringUtil;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by CPYF-Yi Mao on 2018-08-30.
 */
@Component
//AuthenticationException异常或匿名用户AccessDeniedException异常
public class MyAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException e) throws IOException, ServletException {
        if(e instanceof InsufficientAuthenticationException){   //匿名访问保护资源
            request.setAttribute("errMsg","该保护资源需登录访问");
        }else {
            request.setAttribute("errMsg","用户认证异常");
        }
        if(request.getHeader("X-Requested-With") != null){  //ajax请求
            if(!StringUtil.isEmpty(request.getRequestedSessionId())){   //保护资源未登录且传递sessionid，超时处理
                response.setHeader("REDIRECT", request.getContextPath()+"/timeout.html");
            }else{
                response.setHeader("REDIRECT", request.getContextPath()+"/");
            }
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            request.getRequestDispatcher("/ajaxError").forward(request,response);
        }else{
            if(!StringUtil.isEmpty(request.getRequestedSessionId())){   //保护资源未登录且传递sessionid，超时处理
                request.getRequestDispatcher("/timeout.html").forward(request,response);
            }else{
                request.getRequestDispatcher("/login.html").forward(request,response);
            }
        }
    }
}
