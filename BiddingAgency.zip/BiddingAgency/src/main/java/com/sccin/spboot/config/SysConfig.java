package com.sccin.spboot.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Created by developer_hyaci on 2017/8/23.
 */
@Configuration
@ConfigurationProperties(prefix="proj.sys.define")
public class SysConfig {
    /**
     * application
     * */
    private String deleteEnableDeleteLogDate;
    private String deleteAllLogMonth;
    private String saveFileRootPath;
    private String projName;
    private String acountLockedTime;
    /**
     * 项目部署后外部访问地址
     */
    private String projectHost;
    private String versionNo;
    /**
     * 数据中心地址（用于推送审核后的发布链接）
     */
    private String remoteDataCenterHost;

    /**
     * defineSys
     * */
    //统一身份认证相关参数；
    private String ulifyLoginDomain;
    private String ulifySystemid;
    private String ulifyAreaid;
    //用户体系数据接口中相关参数
    private String thridURL;
    private String soapHeadUserName;
    private String soapHeadPassWord;
    private String thirdUserName;
    private String thirdPassWord;

    private String turnToHomePageUrl;    //返回主系统地址

    //音视频保存地址
    private String mediaFilePath;

    public String getDeleteEnableDeleteLogDate() {
        return deleteEnableDeleteLogDate;
    }

    public void setDeleteEnableDeleteLogDate(String deleteEnableDeleteLogDate) {
        this.deleteEnableDeleteLogDate = deleteEnableDeleteLogDate;
    }

    public String getDeleteAllLogMonth() {
        return deleteAllLogMonth;
    }

    public void setDeleteAllLogMonth(String deleteAllLogMonth) {
        this.deleteAllLogMonth = deleteAllLogMonth;
    }

    public String getSaveFileRootPath() {
        return saveFileRootPath;
    }

    public void setSaveFileRootPath(String saveFileRootPath) {
        this.saveFileRootPath = saveFileRootPath;
    }

    public String getProjName() {
        try {
            return new String(projName.getBytes("ISO-8859-1"),"UTF-8");
        }catch (Exception e){
            return "";
        }
    }

    public void setProjName(String projName) {
        this.projName = projName;
    }

    public String getAcountLockedTime() {
        return acountLockedTime;
    }

    public void setAcountLockedTime(String acountLockedTime) {
        this.acountLockedTime = acountLockedTime;
    }

    public String getProjectHost() {
        return projectHost;
    }

    public void setProjectHost(String projectHost) {
        this.projectHost = projectHost;
    }

    public String getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(String versionNo) {
        this.versionNo = versionNo;
    }


    public String getRemoteDataCenterHost() {return remoteDataCenterHost;}

    public void setRemoteDataCenterHost(String remoteDataCenterHost) {this.remoteDataCenterHost = remoteDataCenterHost;}

    public String getUlifyLoginDomain() {
        return ulifyLoginDomain;
    }

    public void setUlifyLoginDomain(String ulifyLoginDomain) {
        this.ulifyLoginDomain = ulifyLoginDomain;
    }

    public String getUlifySystemid() {
        return ulifySystemid;
    }

    public void setUlifySystemid(String ulifySystemid) {
        this.ulifySystemid = ulifySystemid;
    }

    public String getUlifyAreaid() {
        return ulifyAreaid;
    }

    public void setUlifyAreaid(String ulifyAreaid) {
        this.ulifyAreaid = ulifyAreaid;
    }

    public String getThridURL() {
        return thridURL;
    }

    public void setThridURL(String thridURL) {
        this.thridURL = thridURL;
    }

    public String getSoapHeadUserName() {
        return soapHeadUserName;
    }

    public void setSoapHeadUserName(String soapHeadUserName) {
        this.soapHeadUserName = soapHeadUserName;
    }

    public String getSoapHeadPassWord() {
        return soapHeadPassWord;
    }

    public void setSoapHeadPassWord(String soapHeadPassWord) {
        this.soapHeadPassWord = soapHeadPassWord;
    }

    public String getThirdUserName() {
        return thirdUserName;
    }

    public void setThirdUserName(String thirdUserName) {
        this.thirdUserName = thirdUserName;
    }

    public String getThirdPassWord() {
        return thirdPassWord;
    }

    public void setThirdPassWord(String thirdPassWord) {
        this.thirdPassWord = thirdPassWord;
    }

    public String getTurnToHomePageUrl() {
        return turnToHomePageUrl;
    }

    public void setTurnToHomePageUrl(String turnToHomePageUrl) {
        this.turnToHomePageUrl = turnToHomePageUrl;
    }

    public String getMediaFilePath() {
        return mediaFilePath;
    }

    public void setMediaFilePath(String mediaFilePath) {
        this.mediaFilePath = mediaFilePath;
    }
}
