package com.sccin.spboot.utils;

/**
 * Created by CPYF-Yi Mao on 2018/6/21.
 * 字符串工具类
 */
public class StringUtil {

    /**
     * 以字符串返回该对象
     * @param obj
     * @return
     */
    public static String getString(Object obj){
        return obj == null ? null : obj.toString();
    }

    /**
     * 空判断（包含连续空格及null）
     * @param obj
     * @return
     */
    public static boolean isEmpty(Object obj){
        if(obj == null)
            return true;
        if(obj instanceof String)
            return "".equals(obj.toString().trim()) || "null".equalsIgnoreCase(obj.toString().trim());

        return false;
    }

    /**
     * 多元素空判定（有一个为空则为true）
     * @param objs
     * @return
     */
    public static boolean isAnyEmpty(Object... objs){
        if(objs == null)
            return true;
        for(Object obj : objs){
            if(isEmpty(obj)) return true;
        }
        return false;
    }

    /**
     * 判断字符串相等
     * @param source 被判定对象
     * @param target 目标值
     * @return
     */
    public static boolean equals(Object source,String target){
        if(source != null && target != null){
            return target.equals(source.toString());
        }
        return false;
    }
}
