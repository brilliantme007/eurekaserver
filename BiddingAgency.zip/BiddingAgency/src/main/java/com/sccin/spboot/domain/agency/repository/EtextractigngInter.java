package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etextracting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Created on 2018-12-27 8:54
 *
 * @Author WHLiang
 */
@Repository
public interface EtextractigngInter extends JpaRepository<Etextracting, String>, JpaSpecificationExecutor<Etextracting> {

    /**
     * 根据抽取级别,查询上次招标
     *
     * @return com.sccin.spboot.domain.agency.Etextracting
     * @author WHLiang
     * @date 2018-12-27 19:33
     */
    @Query(value = "SELECT * FROM etextracting where etextracting.flevel='1,2' ORDER BY etextracting.ftime desc LIMIT 1",nativeQuery = true)
    Etextracting queryCust();
}
