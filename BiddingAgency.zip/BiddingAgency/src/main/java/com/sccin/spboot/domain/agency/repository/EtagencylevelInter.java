package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etagencylevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Created on 2018-12-27 8:54
 *
 * @Author WHLiang
 */
@Repository
public interface EtagencylevelInter extends JpaRepository<Etagencylevel, String>, JpaSpecificationExecutor<Etagencylevel> {
}
