package com.sccin.spboot.web.endpoint.dto.result;

import org.slf4j.Logger;

/**
 * Created by CPYF-Yi Mao on 2018-09-27.
 */
public class Result<T> {

    private String status;    //1：成功  2：失败  3：拒绝
    private String message;   //消息提示信息
    private T data;           //数据

    private Result(String status, String message ,T data){
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public boolean checkSuccess(){
        return "1".equals(status);
    }

    public static Result buildSuccess(){
        return new Result("1","","");
    }

    public static <T> Result buildSuccess(T data){
        return new Result("1","",data);
    }

    public static Result buildFailed(String message,Logger logger){
        logger.error(message);
        return new Result("2",message,"");
    }

    public static Result buildReject(String message,Logger logger){
        logger.error(message);
        return new Result("99",message,"");
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() { return data; }

    public void setData(T data) { this.data = data; }
}
