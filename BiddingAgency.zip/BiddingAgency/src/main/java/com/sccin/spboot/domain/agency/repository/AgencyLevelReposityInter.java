package com.sccin.spboot.domain.agency.repository;

import com.sccin.spboot.domain.agency.Etagencylevel;
import com.sccin.spboot.domain.agency.specific.EtagencylevelDao;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author MeiYF
 * 2018/12/27 8:25
 * 库级别的repository
 **/
public interface AgencyLevelReposityInter extends JpaRepository<Etagencylevel, String>, EtagencylevelDao {

	/**
	 * 对输入的库级别信息进行重复性校验
	 * @param fname  库级别名称
	 * @return       返回
	 */
	Etagencylevel findByFname(String fname);
}
