package com.sccin.spboot.web.endpoint.dto.recv;
/**
 * Created by ccs on 2018-10-12.
 */
public class CameraInfo {
    private String projectId;        //项目唯一标识，多个以逗号隔开

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }
}
