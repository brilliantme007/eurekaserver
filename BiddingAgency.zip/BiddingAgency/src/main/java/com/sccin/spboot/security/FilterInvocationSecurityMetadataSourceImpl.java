package com.sccin.spboot.security;

import com.sccin.spboot.utils.Statements;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by developer_hyaci on 2018/8/14.
 */
@Component
public class FilterInvocationSecurityMetadataSourceImpl implements FilterInvocationSecurityMetadataSource {


    @Override
    public Collection<ConfigAttribute> getAttributes(Object o) throws IllegalArgumentException {
        HttpServletRequest request = ((FilterInvocation)o).getRequest();

        //得到用户的请求地址
        String requestUrl = request.getServletPath();

        //请求处于豁免列表内或不需要登录返回null
        if(checkUrl(requestUrl,Statements.IGNORURL) || checkUrl(requestUrl,Arrays.asList(Statements.ALLAUTHS))) {
            return null;
        }

        //登陆即共有权限（返回验证登录）
        if(checkUrl(requestUrl,Statements.LOGINSHAREURLS)){
            return SecurityConfig.createList("NEEDLOGIN");
        }

        //当前请求在权限控制范围内返回验证角色
        Iterator entryIterator = Statements.requestMap.entrySet().iterator();
        Map.Entry entry;
        while(entryIterator.hasNext()){
            entry = (Map.Entry)entryIterator.next();
            if(matches(requestUrl, (String) entry.getKey())) {
                return (Collection)entry.getValue();
            }
        }

        //其他请求不在预计范围内
        return SecurityConfig.createList("NODESIGN");
    }

    @Override
    public Collection<ConfigAttribute> getAllConfigAttributes() {
        return null;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return FilterInvocation.class.isAssignableFrom(aClass);
    }

    /**
     * reqUrl满足checks返回true
     * @param reqUrl
     * @param checkUrls
     * @return
     */
    private boolean checkUrl(String reqUrl,List<String> checkUrls){
        for(String checkUrl : checkUrls){
            if(matches(reqUrl,checkUrl)) return true;
        }
        return false;
    }

    /**
     * reqUrl满足check返回true
     * @param reqUrl
     * @param checkUrl
     * @return
     */
    private boolean matches(String reqUrl,String checkUrl){
        return new AntPathMatcher("/").match(checkUrl,reqUrl);
    }
}
