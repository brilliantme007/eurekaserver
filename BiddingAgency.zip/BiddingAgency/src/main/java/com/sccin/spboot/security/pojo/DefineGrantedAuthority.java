package com.sccin.spboot.security.pojo;

import org.springframework.security.core.GrantedAuthority;

/**
 * Created by CPYF-Yi Mao on 2018-08-28.
 */
public class DefineGrantedAuthority implements GrantedAuthority {

    private String roleCode;
    private String roleName;

    public DefineGrantedAuthority(String roleCode,String roleName){
        this.roleCode = roleCode;
        this.roleName = roleName;
    }

    @Override
    public String getAuthority() {
        return roleCode;
    }

    public String getRoleName() { return roleName; }
}
