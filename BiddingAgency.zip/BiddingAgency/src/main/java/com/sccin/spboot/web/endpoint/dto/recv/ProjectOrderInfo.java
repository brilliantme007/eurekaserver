package com.sccin.spboot.web.endpoint.dto.recv;

import com.sccin.spboot.utils.ValidUtils;

import java.util.List;

/**
 * Created by CPYF-Yi Mao on 2018-09-27.
 */
public class ProjectOrderInfo {

    @ValidUtils.Check(describe = "项目唯一标识")
    private String projectUnique;           //项目唯一标识
    @ValidUtils.Check(describe = "项目名称")
    private String name;                    //项目名称
    @ValidUtils.Check(describe = "项目类型",accepts = {"1","2","3","4","99"})
    private String type;                    //项目类型（1：工程 2：采购 3：国土 4：国资 99：其他）
    private String enterprise;              //所属单位
    private String describle;               //项目描述
    @ValidUtils.Check(describe = "地区编码",regex = ValidUtils.regex.areacode)
    private String aredcode;                //地区编码（标准地区编码号）
    @ValidUtils.Check(describe = "项目类型",not_empty = false,accepts = {"","0","1"})
    private String valid;                   //是否启用项目（默认启用 0：不启用 1：启用）
    @ValidUtils.Check(describe = "预约信息")
    private List<RoomOrderInfo> orders;     //预约信息

    public String getProjectUnique() {
        return projectUnique;
    }

    public void setProjectUnique(String projectUnique) {
        this.projectUnique = projectUnique;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEnterprise() {
        return enterprise;
    }

    public void setEnterprise(String enterprise) {
        this.enterprise = enterprise;
    }

    public String getDescrible() {
        return describle;
    }

    public void setDescrible(String describle) {
        this.describle = describle;
    }

    public String getAredcode() {
        return aredcode;
    }

    public void setAredcode(String aredcode) {
        this.aredcode = aredcode;
    }

    public String getValid() {
        return valid;
    }

    public void setValid(String valid) {
        this.valid = valid;
    }

    public List<RoomOrderInfo> getOrders() {
        return orders;
    }

    public void setOrders(List<RoomOrderInfo> orders) {
        this.orders = orders;
    }
}
