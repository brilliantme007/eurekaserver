package com.sccin.spboot.web.endpoint.exception;

/**
 * Created by CPYF-Yi Mao on 2018/6/7.
 * 拒绝接受服务检查异常
 */
public class RejectAcceptException extends Exception {

    public RejectAcceptException(String msg){
        super(msg);
    }
}
