package com.sccin.spboot.security.config;

import com.sccin.spboot.security.*;
import com.sccin.spboot.utils.Statements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


/**
 * Created by developer_hyaci on 2018/8/14.
 */
@EnableWebSecurity
@Configuration
public class WebSecurityConfig_bak extends WebSecurityConfigurerAdapter {

    @Autowired
    private DefineAuthenticationProvider authenticationProvider;
    @Autowired
    private LoginSuccessHandler successHandler;
    @Autowired
    private LoginFailHandler failHandler;
    @Autowired
    private LogoutSuccessHandler logoutSuccessHandler;
    @Autowired
    private FilterInvocationSecurityMetadataSource securityMetadataSource;
    @Autowired
    private AccessDecisionManager accessDecisionManager;
    @Autowired
    private AccessDeniedHandler accessDeniedHandler;
    @Autowired
    private AuthenticationEntryPoint authenticationEntryPoint;
    @Autowired
    private LoginOtherCheackFilter loginOtherCheackFilter;


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.addFilterBefore(loginOtherCheackFilter, UsernamePasswordAuthenticationFilter.class);

        //解决不允许 iframe嵌入本系统页面
        http.headers().frameOptions().disable();
        //防跨域攻击,理论上所有请求都要严格控制；
        http.csrf()
                .ignoringAntMatchers("/pub/**","/fileInfo/uploadFile")
                ;
        //登陆登出；
        http.formLogin()
                .loginPage(Statements.LOGINURL)
                .usernameParameter("username")
                .passwordParameter("password")
                .permitAll()
                .failureHandler(failHandler)
                .successHandler(successHandler)
                .and()
                .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessHandler(logoutSuccessHandler).permitAll().clearAuthentication(true).invalidateHttpSession(true).deleteCookies("JSESSIONID");


        //授权：
        http.authorizeRequests().antMatchers(Statements.ALLAUTHS)
                .permitAll().anyRequest().authenticated();

        http.authorizeRequests()
                .withObjectPostProcessor(new ObjectPostProcessor<FilterSecurityInterceptor>() {
                        @Override
                        public <O extends FilterSecurityInterceptor> O postProcess(O fsi) {
                            fsi.setAccessDecisionManager(accessDecisionManager);
                            fsi.setSecurityMetadataSource(securityMetadataSource);
                            return fsi;
                        }
                    })
                .and().exceptionHandling()
                .accessDeniedHandler(accessDeniedHandler)
                .authenticationEntryPoint(authenticationEntryPoint);
//        ConcurrentSessionFilter
//        RequestCacheAwareFilter
//        SecurityContextHolderAwareRequestFilter
//        AnonymousAuthenticationFilter
//        SessionManagementFilter
//        ExceptionTranslationFilter
//        FilterSecurityInterceptor
//        SimpleRedirectSessionInformationExpiredStrategy
//        DefaultRedirectStrategy
        //只允许一个用户登录,如果同一个账户两次登录,那么第一个账户将被踢下线,跳转到登录页面,expiredUrl所指向的页面会被重定向到session失效地址；
        http.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(false).expiredUrl("/");
        //SESSION固定攻击保护
        http.sessionManagement().sessionFixation().newSession();
        //SESSION失效
        //http.sessionManagement().invalidSessionUrl(Statements.INVALIDSESSIONURL);
        //不支持
        http.rememberMe().disable();


        /*http.authorizeRequests().withObjectPostProcessor(new ObjectPostProcessor<FilterSecurityInterceptor>() {
            @Override
            public <O extends FilterSecurityInterceptor> O postProcess(O o) {
                o.setSecurityMetadataSource(myFilterInvocationSecurityMetadataSource);
                o.setAccessDecisionManager(myAccessDecisionManager);
                return o;
            }
        }).and().exceptionHandling().accessDeniedHandler(myAccessDeniedHandler);

        http.authorizeRequests()
                .and()
                        //增加一个对验证码进行判断的filte
                .addFilterBefore(validProcessingFilter(),UsernamePasswordAuthenticationFilter.class)
                .formLogin().loginPage(SecUrlConfig.LOGINURL).failureUrl(SecUrlConfig.FAILURL)
                .failureForwardUrl(SecUrlConfig.FAILURL).
                successForwardUrl(SecUrlConfig.SUCCESSURL).permitAll();*/



        /*http.authorizeRequests().antMatchers(DefineSecrityHandle.ALLAUTHS)
                .permitAll().anyRequest().authenticated();*/
        //解决不允许显示在iframe的问题
        //http.headers().frameOptions().disable();

        /*http.headers().disable();
        http.csrf().ignoringAntMatchers("/pub*//**","/fileInfo/uploadFile");
        http.logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessHandler(logoutSuccessHandler).permitAll().clearAuthentication(true).invalidateHttpSession(true);
        //request.getSession().invalidate();
        //只允许一个用户登录,如果同一个账户两次登录,那么第一个账户将被踢下线,跳转到登录页面
        http.sessionManagement().maximumSessions(1).expiredUrl("/login.html");*/



        //配置安全策略
        /*http.authorizeRequests()
*//*                .withObjectPostProcessor(new ObjectPostProcessor<FilterSecurityInterceptor>() {
            @Override
            public <O extends FilterSecurityInterceptor> O postProcess(O o) {
                o.setAccessDecisionManager(myAccessDecisionManager);
                return o;
            }
        })*//*
        .and()
// .addFilterBefore(validProcessingFilter(), UsernamePasswordAuthenticationFilter.class)
        .formLogin()
                .loginPage(Statements.LOGINURL)
                .usernameParameter("userName")
                .passwordParameter("passWord")
                .permitAll()
                .failureHandler(failHandler)
                .successHandler(successHandler)
                .and()
                .logout()
                .permitAll()
                .and()
                .csrf()
                .disable()
                .exceptionHandling()
                .accessDeniedHandler(myAccessDeniedHandler);*/


    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //认证：通过自定义认证过程代理实现
        auth.authenticationProvider(authenticationProvider);
    }

}
