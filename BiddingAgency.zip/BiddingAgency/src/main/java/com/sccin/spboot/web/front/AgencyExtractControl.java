package com.sccin.spboot.web.front;

import com.sccin.spboot.domain.agency.Etagency;
import com.sccin.spboot.domain.agency.Etprojinfo;
import com.sccin.spboot.domain.agency.Rnprojagency;
import com.sccin.spboot.service.front.EtagencyService;
import com.sccin.spboot.service.front.ProjectService;
import com.sccin.spboot.utils.StringUtil;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by WHLiang on 2018/12/26.
 */
@Controller
public class AgencyExtractControl {
    @Autowired
    private ProjectService projectService;

    @Autowired
    private EtagencyService etagencyService;

    /**
     * 代理机构抽取页面
     *
     * @param request request
     * @param model   model
     * @param fid   fid
     * @param assign   assign
     * @return java.lang.String
     * @author WHLiang
     * @date 2018-12-26 19:05
     */
    @RequestMapping(value = {"/extractionAgent.html", "/project/extractionAgent.html"})
    public String extractionAgent(HttpServletRequest request, Model model, @Param("fid") String fid, @Param("assign") String assign) {

        boolean isTender = false;
        boolean canExtra = false;
        String msg = "";
        List<Etagency> allAgency = new ArrayList<>();

        if (StringUtil.isEmpty(fid)) {
            msg = "请到项目管理页面选择项目进行抽取!";
        } else {
            //  唯一标识不为空
            List<Etagency> etagencysNeedExtract = etagencyService.getEtagencysNeedExtract();
            if (etagencysNeedExtract == null || etagencysNeedExtract.isEmpty()) {
                canExtra = false;
                msg = "无可抽取的代理机构!";
            } else {
                String[] fids = fid.split(",");
                List<String> strings = Arrays.asList(fids);
                // 查询这些项目
                List<Etprojinfo> allByFidIn = projectService.getAllByFidIn(strings);
                if (allByFidIn == null || allByFidIn.isEmpty()) {
                    // 项目 不存在
                    canExtra = false;
                    msg = "请到项目管理页面选择项目进行抽取";
                } else {
                    // 项目存在
                    // 判定这些项目中是否存在已经抽取的项目
                    model.addAttribute("projects", allByFidIn);
                    List<Rnprojagency> projAgencyByProjectIds = etagencyService.getProjAgencyByProjectIds(strings);
                    if (projAgencyByProjectIds != null && !projAgencyByProjectIds.isEmpty()) {
                        // 存在已经被抽取项目
                        canExtra = false;
                        msg = "所选项目中存在已经被抽取的项目!";
                    } else {
                        // 项目都没有被抽取
                        int size = allByFidIn.size();
                        Etprojinfo etprojinfo = allByFidIn.get(0);
                        String value = etagencyService.getXmlValueByNameAndAttr(etprojinfo.getFmkeys(), "bidType", "value");
                        if (size == 1 && "1".equals(value)) {
                            // 招标抽取
                            isTender = true;
                            if (StringUtil.isEmpty(assign)) {
                                // 招标分组抽取,原来的抽取逻辑
                                allAgency = etagencyService.tenderGroupResult(etagencysNeedExtract, etprojinfo);
                            } else {
                                // 招标指定抽取,全部能够抽取机构
                                etagencyService.notTenderStep(etagencysNeedExtract,etprojinfo);
                                allAgency = etagencyService.getAll();
                            }
                            canExtra = true;
                        } else {
                            // 非招标
                            canExtra = true;
                            // 招标指定抽取,全部能够抽取机构
                            allAgency = etagencysNeedExtract;
                        }
                    }
                }
            }
        }
        model.addAttribute("isTender",isTender);
        model.addAttribute("canExtra", canExtra);
        model.addAttribute("msg", msg);
        model.addAttribute("allAgency", allAgency);
        if (isTender) {
            return "front/views/app/agency-repository/agency-extraction-zb";
        } else {
            return "front/views/app/agency-repository/agency-extraction";
        }
    }

    /**
     * 代理机构抽取结果(目前的情况来看,就非招标走这儿)
     *
     * @param projectId
     * @return com.sccin.spboot.web.pojo.AjaxReturnBean
     * @author WHLiang
     * @date 2018-12-27 12:21
     */
    @PostMapping("/extractionResult")
    @ResponseBody
    public AjaxReturnBean extractionResult(@Param("projectId") String projectId,@Param("agencyId")String agencyId) {

        if (StringUtil.isEmpty(projectId)) {
            return AjaxReturnBean.createError("传递唯一标识出错!");
        }
        // 实现抽取逻辑,并返回抽取结果
        List<String> strings = Arrays.asList(projectId.split(","));
        List<Rnprojagency> projAgencyByProjectIds = etagencyService.getProjAgencyByProjectIds(strings);
        List<Etprojinfo> allByFidIn = projectService.getAllByFidIn(strings);
        List<Etagency> etagencysNeedExtract = etagencyService.getEtagencysNeedExtract();
        if (projAgencyByProjectIds != null && !projAgencyByProjectIds.isEmpty()) {
            // 已经有抽取结果了
            return AjaxReturnBean.createError("存在已抽取项目!");
        }
        if (allByFidIn == null || allByFidIn.isEmpty()) {
            // 已经有抽取结果了
            return AjaxReturnBean.createError("项目不存在!");
        }
        if (etagencysNeedExtract == null || etagencysNeedExtract.isEmpty()) {
            // 已经有抽取结果了
            return AjaxReturnBean.createError("没有可抽取的代理机构!");
        }
        Etagency etagency = etagencyService.notTenderResult1(etagencysNeedExtract, allByFidIn);
        return AjaxReturnBean.createSuccess(etagency.getFepname());
    }
    /**
     * 代理机构抽取结果(目前的情况来看,就招标走这儿)
     *
     * @param projectId 项目fid
     * @return com.sccin.spboot.web.pojo.AjaxReturnBean
     * @author WHLiang
     * @date 2018-12-27 12:21
     */
    @PostMapping("/extractionResultZb")
    @ResponseBody
    public AjaxReturnBean extractionResultZb(@Param("projectId") String projectId,@Param("agencyId")String agencyId) {

        if (StringUtil.isEmpty(projectId)) {
            return AjaxReturnBean.createError("传递项目唯一标识出错!");
        }
        if (StringUtil.isEmpty(agencyId)){
            return AjaxReturnBean.createError("请选择代理机构!");
        }
        // 实现抽取逻辑,并返回抽取结果
        Rnprojagency projAgencyByProjectIds = etagencyService.getProjAgencyByProjectId(projectId);
        Etprojinfo allByFidIn = projectService.getEtprojinfoByFid(projectId);
        Etagency etagencyById = etagencyService.getEtagencyById(agencyId);
        if (projAgencyByProjectIds != null) {
            // 已经有抽取结果了
            return AjaxReturnBean.createError("存在已抽取项目!");
        }
        if (allByFidIn == null) {
            // 已经有抽取结果了
            return AjaxReturnBean.createError("项目不存在!");
        }
        if (etagencyById == null) {
            // 已经有抽取结果了
            return AjaxReturnBean.createError("代理机构不存在!");
        }
        etagencyService.saveExtraResult(etagencyById,allByFidIn);
        return AjaxReturnBean.createSuccess(etagencyById.getFepname());
    }

}
