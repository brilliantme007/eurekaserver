package com.sccin.spboot.domain.moren.repository;


import com.sccin.spboot.domain.moren.Filedepend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface FiledependReposityInter extends JpaRepository<Filedepend,String>,JpaSpecificationExecutor<Filedepend> {

    List<Filedepend> findByRfileinfoidIn(@Param("fileInfoFids") List<String> fileInfoFids);

    List<Filedepend> findByQuoteuniqueInAndQuotetypeIn(Collection<String> uniques , Collection<Integer> types);
}
