package com.sccin.spboot.web.back;

import com.sccin.spboot.domain.moren.Role;
import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.Userrole;
import com.sccin.spboot.service.back.AreacodeService;
import com.sccin.spboot.service.back.RoleService;
import com.sccin.spboot.service.back.UserService;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.utils.StringUtil;
import com.sccin.spboot.utils.Utility;
import com.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by yx on 2018/8/27.
 */
@Controller
public class UserControl extends GlobalExcaptionHolder{
    /**
     * 人工干预强制登出，操作标识；
     * */
    public static final String PERSIONLOGINOUT="person_logout_flag";

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private AreacodeService areacodeService;
    /***
     * 用户列表界面
     * @return
     */
    @RequestMapping("/user/paramsUser")
    public String userList(@PageableDefault(value = PAGESIZE) Pageable pageable, @Param("username") String username, Model model){
        Sort sort = new Sort(Sort.Direction.DESC, "flasttime");
        pageable = new PageRequest(pageable.getPageNumber(), pageable.getPageSize(), sort);
        Page<User> userPoerPage=userService.queryUserList(username,pageable);
        model.addAttribute("page",pageable.getPageNumber()+1);
        model.addAttribute("total",userPoerPage.getTotalPages());
        if(userPoerPage!=null && userPoerPage.getContent()!=null && userPoerPage.getContent().size()>0){
            model.addAttribute("users",userPoerPage.getContent());
        }else {
            model.addAttribute("users","");
        }
        model.addAttribute("username",username);
        return "back/user/userList";
    }

    @RequestMapping("/user/getRoleAdmins")
    public @ResponseBody
    AjaxReturnBean getAdmins(HttpServletRequest request){
        List<Role> listRole = roleService.queryAllRole();
        List<Map<String,String>> list = new ArrayList<Map<String,String>>();
        for (Role role : listRole) {
            Map<String,String> mapRole = new HashMap<String, String>();
            mapRole.put("frole", role.getCode());
            mapRole.put("frolename", role.getName());
            list.add(mapRole);
        }
        return AjaxReturnBean.createSuccess("",list);
    }

    @RequestMapping("/user/verifyUserFsyslname")
    public @ResponseBody AjaxReturnBean verifyUserFsyslname(@Param("fsyslname") String fsyslname,HttpServletRequest request){
        return AjaxReturnBean.createSuccess("",userService.verifyUserFsyslname(fsyslname));
    }

    /**
     * 根据fid获取用户信息
     * @param fid
     * @return
     */
    @RequestMapping(value = "/user/detailUser")
    public @ResponseBody AjaxReturnBean detailUser(HttpServletRequest request,@Param("fid") String fid) {
        String msg = "";
        boolean fidFlag = fid != null && !fid.trim().equals("");
        if (fidFlag) {
            User user = userService.detailUser(fid);
            String areaCode;    //存在地区
            if(!StringUtils.isEmpty((areaCode= Utility.getFexpendByKey(user.getExpend(),"areaCode")))){
                user.setDataAuth(areaCode);
                user.setAreaName(areacodeService.getAllAreaNameByCode(areaCode));
            }
            return AjaxReturnBean.createSuccess("success",user);
        } else {
            return AjaxReturnBean.createError("用户唯一标识传递失败，请重新传递",null);
        }
    }

    @RequestMapping("/user/addUser")
    @ResponseBody
    public AjaxReturnBean addUser(@Param("id")String id,@Param("name")String name,@Param("loginName")String loginName,
                                  @Param("pasd")String pasd,@Param("role")String role,@Param("realname")String realname,
                                  @Param("email")String email,@Param("phone")String phone,@Param("ca")String ca,
                                  @Param("isvalid")String isvalid,@Param("savePsdFlag")String savePsdFlag,
                                  @Param("areaCode") String areaCode,HttpServletRequest request){
        Map<String, Object> map = new HashMap<String, Object>();
        if("0".equals(savePsdFlag)){
           /* String reg = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$";
            if(!pasd.matches(reg)){
               return AjaxReturnBean.createError("密码应由6-20位字母数字组成",null);
            }*/
            if(pasd.length()>20 && pasd.length() <6){
                return AjaxReturnBean.createError("密码长度应由6-20位",null);
            }
            if(pasd.equals(loginName) || pasd.equals(new StringBuilder(loginName).reverse().toString())){
                return AjaxReturnBean.createError("密码与账号有关，请重新输入!",null);
            }
            boolean isHaveAZ = false;
            boolean isHaveaz = false;
            boolean isHaveNum = false;
            boolean isHaveSpecialChar = false;
            for(int i=0;i<pasd.length();i++){
                if(!isHaveAZ){
                    if(pasd.charAt(i) >= 'A' && pasd.charAt(i) <= 'Z'){
                        isHaveAZ = true;
                        continue;
                    }
                }
                if(!isHaveaz){
                    if(pasd.charAt(i) >= 'a' && pasd.charAt(i) <= 'z'){
                        isHaveaz = true;
                        continue;
                    }
                }
                if(!isHaveNum){
                    if(pasd.charAt(i) >= '0' && pasd.charAt(i) <= '9'){
                        isHaveNum = true;
                        continue;
                    }
                }
            }
            String specialChar = "^.*[(/)|(\\.)|(\\*)|(\\@)|(\\!)|(\\^)|(\\`) |(\\~)| (\\?)|(\\<)|(\\>)|(\\()|(\\))||(\\-)|(\\_)|(\\=)|(\\[)|(\\])|(\\{)|(\\})|(\\:)].*$";
            if(pasd.matches(specialChar)){
                isHaveSpecialChar = true;
            }
            int validateRule = 0;
            if(isHaveaz){
                validateRule +=1;
            }
            if(isHaveAZ){
                validateRule +=1;
            }
            if(isHaveNum){
                validateRule +=1;
            }
            if(isHaveSpecialChar){
                validateRule +=1;
            }
            if(validateRule<2){
                return AjaxReturnBean.createError("密码应该包含至少一个小写字母,一个大写字母,一个数字,一个特殊字符以上规则的两条",null);
            }
        }
        String userId ="";
        List<Userrole> userrole = null;
        List<Role> list = new ArrayList<>();
        if(role!=null && !"".equals(role)){
            String[] arr = role.split("\\?");
            for(int i=0;i<arr.length;i++){
                Role role1 = roleService.querRoleByCode(arr[i]);
                list.add(role1);
            }
        }
        boolean flag;
        if(id!=null && !"".equals(id)){
            //修改
            userId = id;
            User u = userService.findOne(userId);
            if(u!=null){
                u.setName(name);
                u.setLoginame(loginName);
                if("0".equals(savePsdFlag)){
                    BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                    u.setPasd(passwordEncoder.encode(pasd));
                }
                u.setRealname(realname);
                u.setEmail(email);
                u.setPhone(phone);
                u.setCa(ca);
                u.setIsvalid(Integer.parseInt(isvalid));
                u.setIssys(1);
                if(!StringUtils.isEmpty(areaCode)){
                    u.setExpend(Utility.replaceFexpend(u.getExpend(),"areaCode",areaCode));
                }else{
                    u.setExpend(Utility.removeFexpend(u.getExpend(),"areaCode"));
                }
            }
            userrole = roleService.queryUserRoleByUserId(id);
            flag = userService.saveUser(u,list,userrole);
            //若修改用户为当前登陆者须更新用户缓存  2018/08/02
            User securityUser;
            if(flag && userId.equals((securityUser = UserService.getUserFromSession(request)).getId())){
                securityUser.setName(u.getName());
                securityUser.setLoginame(u.getLoginame());
                securityUser.setPasd(u.getPasd());
                securityUser.setRealname(u.getRealname());
                securityUser.setEmail(u.getEmail());
                securityUser.setPhone(u.getPhone());
                securityUser.setCa(u.getCa());
                securityUser.setIsvalid(u.getIsvalid());
                securityUser.setIssys(u.getIssys());
                securityUser.setExpend(u.getExpend());
            }
        }else{
            userId = UUID.randomUUID().toString();
            User u = new User();
            u.setId(userId);
            u.setName(name);
            u.setLoginame(loginName);
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            u.setPasd(passwordEncoder.encode(pasd));
            u.setRealname(realname);
            u.setEmail(email);
            u.setPhone(phone);
            u.setCa(ca);
            u.setIsvalid(Integer.parseInt(isvalid));
            u.setIssys(1);
            u.setFailnum(0);
            if(!StringUtils.isEmpty(areaCode)) u.setExpend(Utility.replaceFexpend(u.getExpend(),"areaCode",areaCode));

            flag = userService.saveUser(u,list);
        }
        if(flag){
            return AjaxReturnBean.createSuccess("保存成功");
        }else{
            return AjaxReturnBean.createError("新增失败");
        }
    }

    @RequestMapping("/user/delUser")
    @ResponseBody
    public AjaxReturnBean delUser(@Param("fid") String fid, HttpServletRequest request){
        //先判断是否能删除 目前不考虑
        if (!StringUtil.isEmpty(fid)){
            //先登出用户
            User selectedUser=userService.findOne(fid);
            if(selectedUser.getFailnum()==99 || Statements.getLoginSessionMapSession(fid)!=null){
                //选中用户正登陆 或者 选中用户在服务端有维护登陆session;
                Statements.getLoginSessionMapSession(fid).setAttribute(PERSIONLOGINOUT, UserService.getUserFromSession(request));
                Statements.getLoginSessionMapSession(fid).invalidate();
            }
            boolean flag = userService.delUser(fid);
            if(flag){
                return AjaxReturnBean.createSuccess("success");
            }else{
                return AjaxReturnBean.createError("用户删除失败，请重试");
            }
        }else{
            return AjaxReturnBean.createError("用户唯一标识传递失败，请重新传递");
        }
    }
}
