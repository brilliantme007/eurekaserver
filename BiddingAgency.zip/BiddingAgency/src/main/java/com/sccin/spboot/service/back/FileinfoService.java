package com.sccin.spboot.service.back;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sccin.spboot.domain.agency.Etagencylevel;
import com.sccin.spboot.domain.moren.Filedepend;
import com.sccin.spboot.domain.moren.Fileinfo;
import com.sccin.spboot.domain.moren.repository.FiledependReposityInter;
import com.sccin.spboot.domain.moren.repository.FileinfoReposityInter;
import com.sccin.spboot.service.front.AgencyLevelService;
import com.sccin.spboot.service.front.EtagencyService;
import com.sccin.spboot.web.pojo.AjaxReturnBean;

@Component("FileinfoService")
public class FileinfoService {


    @Autowired
    private FiledependReposityInter filedependReposityInter;

    @Autowired
    private FileinfoReposityInter fileinfoReposityInter;

    @Autowired
    private EtagencyService etagencyService;

    @Autowired
    private AgencyLevelService agencyLevelService;

    /**
     * 点击文件管理按钮后进入页面的查询 输入条件查询文件
     *
     * @param pageable
     * @param name 文件名
     * @param storename 储存名
     * @param suffix 后缀名
     * @param starTime 起始时间
     * @param endTime 结束时间
     * @return
     * @author meiyufei
     * @time 2018.8.26. 10:56
     */
    public Page<Fileinfo> findFileinfoByPage(Pageable pageable, String name, String storename, String suffix, String starTime, String endTime) {
        return fileinfoReposityInter.findFileinfoByPage(pageable, name, storename, suffix, starTime, endTime);
    }

    /**
     * 点击编辑按钮后根据选择的文件id查询对应的信息
     *
     * @param fid
     * @return
     */
    public Fileinfo findByFid(String fid) {
        return fileinfoReposityInter.findOneById(fid);
    }

    /**
     * 保存编辑后的文件信息
     *
     * @param fileinfo 文件对象
     * @return
     */
    public AjaxReturnBean saveOrUpdateFileInfo(Fileinfo fileinfo) {
        //通用参数校验
        if (StringUtils.isEmpty(fileinfo.getName()) || StringUtils.isEmpty(fileinfo.getStorename())
                || fileinfo.getTime() == null) {
            return AjaxReturnBean.createError("参数校验失败，文件名、储存名、时间不可为空", null);
        }
        //新增
        if (StringUtils.isEmpty(fileinfo.getId())) {
            if (StringUtils.isEmpty(fileinfo.getStoreplace()) || StringUtils.isEmpty(fileinfo.getSuffix())) {
                return AjaxReturnBean.createError("参数校验失败，储存地址、后缀名不可为空", null);
            }
            fileinfo.setId(UUID.randomUUID().toString());
            //修改
        } else {
            Fileinfo sourceFileinfo = fileinfoReposityInter.findOneById(fileinfo.getId());
            if (sourceFileinfo == null) {
                return AjaxReturnBean.createError("文件ID查找失败", null);
            }
            List<Filedepend> depends = filedependReposityInter.findByRfileinfoidIn(Arrays.asList(new String[]{sourceFileinfo.getId()}));
            if (depends.size() > 0) {
                //存在关联的不可修改地址及后缀
                fileinfo.setStoreplace(sourceFileinfo.getStoreplace());
                fileinfo.setSuffix(sourceFileinfo.getSuffix());
            }
        }
        fileinfoReposityInter.save(fileinfo);
        return AjaxReturnBean.createSuccess("文件信息保存成功", null);
    }

    /**
     * 删除文件信息
     *
     * @param fids 对应fid
     */
    public AjaxReturnBean delFileinfo(List<String> fids) {
        //删除不存在关联关系的fid数据
        List<Filedepend> filedepends = filedependReposityInter.findByRfileinfoidIn(fids);
        //可删除缓存
        List<String> ables = new ArrayList<>(fids);
        for (String fid : fids) {
            for (Filedepend filedepend : filedepends) {
                if (fid.equals(filedepend.getRfileinfoid())) {
                    if (ables.contains(fid)) {
                        ables.remove(fid);
                    }
                }
            }
        }

        //删除后并删除文件
        List<Fileinfo> fileinfos = fileinfoReposityInter.findAll(ables);
        fileinfoReposityInter.deleteInBatch(fileinfoReposityInter.findAll(ables));
        File file = null;
        for (Fileinfo fileinfo : fileinfos) {
            file = new File(fileinfo.getStoreplace() + fileinfo.getStorename() + (fileinfo.getSuffix().startsWith(".") ? fileinfo.getSuffix() : "." + fileinfo.getSuffix()));
            if (file.exists() && file.isFile()) {
                file.delete();
            }
        }
        if (ables.size() > 0) {
            return AjaxReturnBean.createSuccess("删除文件信息成功", null);
        }
        return AjaxReturnBean.createError("该文件存在关联信息不可删除", null);
    }

    /***
     * 保存存在id的文件
     * @param info
     */
    public void saveFileInfo(Fileinfo info) {
        fileinfoReposityInter.save(info);
    }

    public Fileinfo findOneBy(String fquotetype, String fquoteunique) {
        return fileinfoReposityInter.findOneBy(fquotetype, fquoteunique);
    }

    /**
     * Excel文件中列位置与字段的映射
     */
    private static Map<Integer, String> indexFieldMap;

    static {
        indexFieldMap = new HashMap<>();
        indexFieldMap.put(0, "findex");
        indexFieldMap.put(1, "fepname");
        indexFieldMap.put(2, "fscc");
        indexFieldMap.put(3, "faddress");
        indexFieldMap.put(4, "fphone");
        indexFieldMap.put(5, "flinkman");
        indexFieldMap.put(6, "fsex");
        indexFieldMap.put(7, "fduty");
        indexFieldMap.put(8, "ragencylevelid");
        // indexFieldMap.put(9, "fstate");
        // indexFieldMap.put(10, "fchoosecount");
        // indexFieldMap.put(11, "fusetime");
    }

    /**
     * 联系人性别在数据库中对应的值
     */
    private static Map<String, Object> sexValueMap;

    static {
        sexValueMap = new HashMap<>();
        sexValueMap.put("男", "1");
        sexValueMap.put("女", "0");
    }

    /**
     * 代理级别在数据库中对应的值
     */
    private static Map<String, Object> levelValueMap;

    /**
     * 导入Excel文件中的数据
     *
     * @param file
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public void importExcelFile(File file) throws Exception {
        try (Workbook sheets = WorkbookFactory.create(file)) {
            Sheet sheet = sheets.getSheetAt(0);
            int lastRowNum = sheet.getLastRowNum();
            for (int i = 1; i <= lastRowNum; i++) {
                Row row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }
                Map<String, Object> rowData = getRowData(row);
                rowData.put("fid", UUID.randomUUID().toString());
                etagencyService.insertAgencyByParam(rowData);
            }
        }
    }

    /**
     * 从一行中读取数据
     *
     * @param row
     * @return
     */
    private Map<String, Object> getRowData(Row row) {
        Set<Map.Entry<Integer, String>> entries = indexFieldMap.entrySet();
        Map<String, Object> map = new HashMap<>();
        for (Map.Entry<Integer, String> entry : entries) {
            int index = entry.getKey();
            Cell cell = row.getCell(index);
            if (cell == null) {
                continue;
            }
            String field = entry.getValue();
            cell.setCellType(CellType.STRING);
            Object value = cell.getStringCellValue();
            if ("findex".equals(field)) {
                // 序号
                value = Integer.valueOf(value.toString());
            } else if ("fsex".equals(field)) {
                // 性别
                value = sexValueMap.get(value);
            } else if ("ragencylevelid".equals(field)) {
                // 代理级别
                if (levelValueMap == null) {
                    levelValueMap = new HashMap<>();
                    List<Etagencylevel> allLevelList = agencyLevelService.getAllLevelList();
                    for (Etagencylevel etagencylevel : allLevelList) {
                        levelValueMap.put(etagencylevel.getFname(), etagencylevel.getFlevel());
                    }
                }
                Object levelValue = levelValueMap.get(value);
                value = agencyLevelService.findIdByLevel(levelValue);
            }
            map.put(field, value);
        }
        return map;
    }

    /**
     * 清空代理级别值的关系
     */
    public void clearLevelValueMap() {
        levelValueMap = null;
    }
}
