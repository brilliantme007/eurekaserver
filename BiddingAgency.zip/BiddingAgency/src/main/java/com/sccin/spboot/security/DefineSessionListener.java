package com.sccin.spboot.security;

import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.repository.UserReposityInter;
import com.sccin.spboot.security.pojo.SecurityUser;
import com.sccin.spboot.service.back.LogsService;
import com.sccin.spboot.utils.Statements;
import com.sccin.spboot.web.front.UlifyLoginControl;
import com.sccin.spboot.web.back.UserControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by developer_hyaci on 2017/10/17.
 */

@Component
public class DefineSessionListener implements HttpSessionListener {

    @Autowired
    private UserReposityInter userReposityInter;
    @Autowired
    private LogsService logService;

    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {
        //session 创建时；
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
        //session 过期时；
        HttpSession session=httpSessionEvent.getSession();
        if(session.getAttribute("SPRING_SECURITY_CONTEXT")!=null){
            //表示用户已登陆
            SecurityContext securityContext = (SecurityContextImpl)session.getAttribute("SPRING_SECURITY_CONTEXT");
            Authentication auth=securityContext.getAuthentication();
            User user=((SecurityUser)auth.getPrincipal()).getLoginUser();
            user.setFailnum(0);
            user.setLogtime(Timestamp.valueOf(LocalDateTime.now()));
            userReposityInter.save(user);
            if(session.getAttribute(LogoutSuccessHandler.NORMALSESSIONCLOSE)!=null){
                //正常退出日志
                logService.logInfo(this.getClass(), 0, user.getLoginame(),"", "", "", user.getName()+"成功登出",user.getName()+"成功登出", true);
            }else if(session.getAttribute(UserControl.PERSIONLOGINOUT)!=null){
                //人工干预强制登出日志
                User handleUser=(User)session.getAttribute(UserControl.PERSIONLOGINOUT);
                logService.logInfo(this.getClass(), 0, user.getLoginame(), "", "", "", "["+handleUser.getName()+"]人工干预,强制登出"+user.getName(), "["+handleUser.getName()+"]人工干预,强制登出"+user.getName(), true);
            }else{
                //没有在session期内正常登出，session已过期时，记录日志
                logService.logInfo(this.getClass(), 0, user.getLoginame(),"", "", "", user.getName()+"未在SESSION有效期内登出，SESSION已过期，系统强制登出", user.getName()+"未在SESSION有效期内登出，SESSION已过期，系统强制登出", true);
            }
            //维护用户的登陆状态；
            Statements.removeLoginSessionMap(user.getId());
            //第三方登录用户
            if(UlifyLoginControl.tokenWithId.containsValue(user.getId())){
                List<String> rmKeys = new ArrayList<>();
                for(Map.Entry<String,String> entries : UlifyLoginControl.tokenWithId.entrySet()){
                    if(user.getId().equals(entries.getValue())) rmKeys.add(entries.getKey());
                }
                for(String rmkey:rmKeys) {
                    UlifyLoginControl.tokenWithId.remove(rmkey);
                }
            }
        }
    }
}
