package com.sccin.spboot.domain.moren.repository;

import com.sccin.spboot.domain.moren.User;
import com.sccin.spboot.domain.moren.specific.UserDao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yx on 2018/8/27.
 */
public class UserReposityInterImpl implements UserDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Page<User> queryUserList(String userName, Pageable pageable) {
        StringBuilder sb= new StringBuilder();
        sb.append("SELECT t1.fid id,t1.floginame loginName,t1.fname fname,t1.femail email, ");
        sb.append(" t1.fisvalid isUse from etuser t1 ");
        sb.append(" WHERE 1=1 ");
        if(userName!=null && !"".equals(userName.trim())){
            sb.append(" and t1.fname like :userName ");
        }
        Query query = entityManager.createNativeQuery(sb.toString());
        if(userName!=null && !"".equals(userName.trim())){
            query.setParameter("userName","%"+userName+"%");
        }
        List<Object []> objs = query.getResultList();
        try{
            List<User> list = new ArrayList<>();
            int total = objs.size();
            if(objs!=null && total>0){
                int pageStart = pageable.getPageNumber() * pageable.getPageSize();
                int pageEnd = pageStart + pageable.getPageSize() < total ? pageStart + pageable.getPageSize() : total;
                for(int i=pageStart;i<pageEnd;i++){
                    Object[] o = objs.get(i);
                    String id = (String)o[0];
                    String loginName = (String)o[1];
                    String name = (String)o[2];
                    String email = (String)o[3];
                    Integer isUse = (Integer) o[4];
                    User u = new User();
                    u.setId(id);
                    u.setLoginame(loginName);
                    u.setName(name);
                    u.setEmail(email);
                    u.setIsvalid(isUse);
                    list.add(u);
                }
            }
            objs = null;
            return new PageImpl<>(list,pageable,total);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public Map<String, String> queryRoleNames(List<String> userIdList) {
        Map<String,String> result = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        sb.append(" SELECT t2.ruserid, t1.fname FROM etrole t1 LEFT JOIN rnuserrole t2 ON t1.fid = t2.rroleid where t2.ruserid in :userIdList ");
        Query cquery = entityManager.createNativeQuery(sb.toString());
        cquery.setParameter("userIdList",userIdList);
        List<Object []> objs = cquery.getResultList();
        if(objs!=null&& objs.size()>0){
            for(int i=0;i<objs.size();i++){
                Object[] o = objs.get(i);
                String id = (String)o[0];
                String fname = (String)o[1];
                if(result.containsKey(id)){
                    String roleName = result.get(id).toString();
                    roleName = roleName+fname+",";
                    result.put(id,roleName);
                }else{
                    result.put(id,fname+",");
                }
            }
        }
        return result;
    }

    @Override
    public List<Map<String,String>> getUserByRoleIds(String roleIds) {
        StringBuilder sb=new StringBuilder();
        sb.append("select etu.fid userid,etu.fname uname,etr.fid roleid from etuser etu,rnuserrole rnu,etrole etr ");
        sb.append("where 1=1 ");
        sb.append("AND etu.fid=rnu.ruserid ");
        sb.append("AND rnu.rroleid=etr.fid ");
        if (roleIds!=null&&!roleIds.equals("")){
            sb.append("AND etr.fid in "+roleIds);
        }
        Query query = entityManager.createNativeQuery(sb.toString());
        List<Object []> objs = query.getResultList();
        List<Map<String,String>> resultList=new ArrayList<>();
        if(objs!=null){
            for(int i=0;i<objs.size();i++){
                Object[] o = objs.get(i);
                Map<String,String> map=new HashMap<>();
                map.put("userid",o[0]!=null?o[0].toString():"");
                map.put("uname",o[1]!=null?o[1].toString():"");
                map.put("roleid",o[2]!=null?o[2].toString():"");

                resultList.add(map);
            }
        }
        return resultList;
    }


    @Override
    public User findUserById(String userId) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT t1.fid id,t1.floginame loginName,t1.fname fname,t1.femail email, ");
        sb.append(" t1.fisvalid isUse,t1.fpasd pasd,t1.fphone phone,t1.fca ca ,t1.fissys issys,t1.frealname realname,t1.fexpend expend from etuser t1 ");
        sb.append(" WHERE t1.fid = :userId ");
        Query query = entityManager.createNativeQuery(sb.toString());
        query.setParameter("userId",userId);
        List<Object []> objs = query.getResultList();
        try{
            User u =new User();
            int total = objs.size();
            if(objs!=null && total>0){
                for(int i=0;i<objs.size();i++){
                    Object[] o = objs.get(i);
                    StringBuilder csb = new StringBuilder();
                    String roleName = "";
                    csb.append("SELECT t1.fcode FROM etrole t1 LEFT JOIN rnuserrole t2 ON t1.fid = t2.rroleid where t2.ruserid = :userId");
                    Query cquery = entityManager.createNativeQuery(csb.toString());
                    cquery.setParameter("userId",userId);
                    List<Object []> cobjs = cquery.getResultList();
                    if(cobjs!=null && cobjs.size()>0){
                        for(int j=0;j<cobjs.size();j++){
                            Object co = cobjs.get(j);
                            roleName += co.toString() + ",";
                        }
                    }
                    String id = (String)o[0];
                    String loginName = (String)o[1];
                    String name = (String)o[2];
                    String email = (String)o[3];
                    Integer isUse = (Integer) o[4];
                    String pasd = (String)o[5];
                    String phone =(String)o[6];
                    String ca = (String)o[7];
                    Integer issys = (Integer)o[8];
                    String realname = (String)o[9];
                    String expend = (String)o[10];
                    u.setId(id);
                    u.setLoginame(loginName);
                    u.setName(name);
                    u.setEmail(email);
                    if(roleName!=null && !"".equals(roleName)){
                        u.setRoleName(roleName.substring(0,roleName.length()-1));
                    }
                    u.setIsvalid(isUse);
                    u.setPasd(pasd);
                    u.setPhone(phone);
                    u.setCa(ca);
                    u.setIssys(issys);
                    u.setRealname(realname);
                    u.setExpend(expend);
                }
            }
            objs = null;
            return u;
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public List<User> getUserByParams(String userName, String uerloginName) {
        StringBuffer sb=new StringBuffer();
        sb.append("SELECT * FROM etuser U WHERE 1=1 ");
        if(uerloginName!=null && !uerloginName.trim().equals("")){
            sb.append("and U.floginame LIKE :loginName ");
        }
        if(userName!=null && !userName.trim().equals("")){
            sb.append("AND U.fname LIKE :userName ");
        }
        Query query = this.entityManager.createNativeQuery(sb.toString());

        if(userName!=null && !userName.trim().equals("")){
            query.setParameter("userName", "%"+userName+"%");
        }
        if(uerloginName!=null && !uerloginName.trim().equals("")){
            query.setParameter("loginName","%"+uerloginName+"%");
        }
        List<User> resultUser = query.getResultList();
        return resultUser;
    }

    @Override
    public List<Map<String,String>> getUserHadAuthority(Map<String,Object> params){
        StringBuilder sb=new StringBuilder();
        sb.append("select distinct etuser.fid fid,etuser.fname fname from etuser,rnuserrole,etrole,rnroleauths,etauthority ");
        sb.append("where 1=1 ");
        sb.append("AND etuser.fid=rnuserrole.ruserid ");
        sb.append("AND rnuserrole.rroleid=etrole.fid ");
        sb.append("AND etrole.fid=rnroleauths.rroleid ");
        sb.append("AND rnroleauths.rauthorityid=etauthority.fid ");
        if(params.get("code")!=null&&!"".equals(params.get("code").toString())){
            sb.append("AND (etauthority.fid='55m854c1-df58-11e5-a511-005056b34d48' or etauthority.furl in ('/mcontent/mcontent.html','/mcontent/saveMcontents/"+params.get("code").toString()+"','/mcontent/editMcontent/"+params.get("code").toString()+".html')) ");
        }
        Query query = entityManager.createNativeQuery(sb.toString());
        List<Object []> objs = query.getResultList();
        List<Map<String,String>> resultList=new ArrayList<>();
        if(objs!=null){
            for(int i=0;i<objs.size();i++){
                Object[] o = objs.get(i);
                Map<String,String> map=new HashMap<>();
                map.put("userid",o[0]!=null?o[0].toString():"");
                map.put("uname",o[1]!=null?o[1].toString():"");
                resultList.add(map);
            }
        }
        return resultList;
    }
}
