/** layuiAdmin.std-v1.2.1 LPPL License By http://www.layui.com/admin/ */
;layui.define(["table", "form", "element","ajaxSetting"], function (e) {
    var t = layui.$, i = layui.table, o = (layui.form, layui.element);
    i.render({
        elem: "#agencyLevel-repository",
        url:  "/loginSelectAgencylevelMess",
        method:"post",
        toolbar: "#table-toolbar",
        title: "库级别管理表",
        cols: [[
            {
                field: "fid", title: "ID",hide:true
            },{
                field: "fname",   title: "库名称",sort: !1
            }, {
                field: "flevel",  title: "库的优先级"
            }, {
                title: "操作",
                align: "center",
                fixed: "right",
                toolbar: "#table-system-order"
            }]]
        ,defaultToolbar: [ 'print', 'exports'],
        page: !0,
        limit: 20,
        text: "对不起，加载出现异常！",
        done: function () {
            //o.render("progress");
        }
    }), i.on("toolbar(agencyLevel-repository)", function (e) {  //新增
        var t = i.checkStatus(e.config.id);
        switch (e.event) {
            case"addnew":
                t.data;
                layer.open({
                    type: 2,
                    title: "新增库级别",
                    content: "/loginagencyLevelAdd.html?"+new Date().getTime(),
                    area: ["550px", "330px"],
                    btn: ["确定", "取消"],
                    yes: function (e, t) {
                        var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                            n = t.find("iframe").contents().find("#" + r);
                        o.layui.form.on("submit(" + r + ")", function (t) {
                            var fname=t.field.fname;
                            var flevel=t.field.flevel;
                            $.post('/loginAddAgencyLev',{fname:fname,flevel:flevel},function (result) {
                                if(result.code==0){
                                    layer.alert(result.msg, {
                                        icon: 1,
                                        skin: 'layer-ext-moon'
                                    });
                                    /*
                                    i.reload('agencyLevel-repository'); 刷新table agencyLevel-repository是table的id
                                    window.location.reload();           刷新页面
                                    */
                                    layer.close(e)
                                    i.render({
                                        elem: "#agencyLevel-repository",
                                        url:  "/loginSelectAgencylevelMess",
                                        method:'post',
                                        toolbar: "#table-toolbar",
                                        title: "库级别管理表",
                                        cols: [[
                                            {
                                                field: "fid", title: "ID",hide:true
                                            },{
                                                field: "fname",   title: "库名称",sort: !1
                                            }, {
                                                field: "flevel",  title: "库的优先级"
                                            }, {
                                                title: "操作",
                                                align: "center",
                                                fixed: "right",
                                                toolbar: "#table-system-order"
                                            }]]
                                        ,defaultToolbar: [ 'print', 'exports'],
                                        page: !0,
                                        limit: 20,
                                        text: "对不起，加载出现异常！",
                                        done: function () {
                                            //o.render("progress");
                                        }
                                    })
                                } else {
                                    layer.alert(result.msg, {
                                        icon: 2,
                                        skin: 'layer-ext-moon'
                                    })
                                }
                            });
                            i.reload("LAY-user-front-submit")
                        }), n.trigger("click")
                    },
                    success: function (e, t) {

                    }
                })
        }
    }), i.on("tool(agencyLevel-repository)", function (e) {  //编辑
        e.data;
        if ("edit" === e.event) {
            t(e.tr);
            var fid=e.data.fid;
            var fname=e.data.fname;
            var flevel=e.data.flevel;
            $.post('/pub/loginGetAgencyMess',{fid:fid,fname:fname,flevel:flevel},function (result) {
                if(result.code==0){
                    layer.open({
                        type: 2,
                        title: "编辑库级别",
                        content: "/loginagencyLevelEdit.html?"+new Date().getTime(),
                        area: ["550px", "330px"],
                        btn: ["确定", "取消"],
                        yes: function (e, t) {
                            var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                                n = t.find("iframe").contents().find("#" + r);
                            o.layui.form.on("submit(" + r + ")", function (t) {
                                var fid=t.field.fid;
                                var fname=t.field.fname;
                                var flevel=t.field.flevel;
                                $.post('/editAgencyLev',{fid:fid,fname:fname,flevel:flevel},function (result) {
                                    if(result.code==0){
                                        layer.alert(result.msg, {
                                            icon: 1,
                                            skin: 'layer-ext-moon'
                                        })
                                        layer.close(e)
                                        i.render({
                                            elem: "#agencyLevel-repository",
                                            url:  "/loginSelectAgencylevelMess",
                                            method:'post',
                                            toolbar: "#table-toolbar",
                                            title: "库级别管理表",
                                            cols: [[
                                                {
                                                    field: "fid", title: "ID",hide:true
                                                },{
                                                    field: "fname",   title: "库名称",sort: !1
                                                }, {
                                                    field: "flevel",  title: "库的优先级"
                                                }, {
                                                    title: "操作",
                                                    align: "center",
                                                    fixed: "right",
                                                    toolbar: "#table-system-order"
                                                }]]
                                            ,defaultToolbar: [ 'print', 'exports'],
                                            page: !0,
                                            limit: 20,
                                            text: "对不起，加载出现异常！",
                                            done: function () {
                                                //o.render("progress");
                                            }
                                        })
                                    } else {
                                        layer.alert(result.msg, {
                                            icon: 2,
                                            skin: 'layer-ext-moon'
                                        })
                                    }
                                });
                                i.reload("LAY-user-front-submit")
                            }), n.trigger("click");
                        },
                        success: function (e, t) {}
                    })
                }
            });
        } else "del" === e.event && layer.confirm("确定要删除该库级别吗？", function (t) { //删除
            $.post('/loginDeleteAgencyLev',{fid:e.data.fid},function (result) {
                if(result.code==0){
                    e.del(),
                    layer.alert(result.msg, {
                        icon: 1,
                        skin: 'layer-ext-moon'
                    }),
                    layer.close(t);
                }else{
                    layer.alert(result.msg, {
                        icon: 2,
                        skin: 'layer-ext-moon'
                    })
                }
            });
        })
    }), e("agencyLevel-repository", {})
});