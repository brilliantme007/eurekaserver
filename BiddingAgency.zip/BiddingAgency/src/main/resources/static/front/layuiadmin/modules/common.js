/** layuiAdmin.std-v1.2.1 LPPL License By http://www.layui.com/admin/ */
;layui.define(["ajaxSetting"],function (e) {
    var i = (layui.$, layui.layer, layui.laytpl, layui.setter, layui.view, layui.admin);
    i.events.logout = function () {
        i.req({
            url: "/logout?"+new Date().getTime(), type: "get", data: {}, done: function (e) {
                i.exit(function () {
                    location.href = "/"
                })
            }
        })
    }, e("common", {})
});