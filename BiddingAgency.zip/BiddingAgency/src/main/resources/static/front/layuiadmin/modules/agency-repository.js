/** layuiAdmin.std-v1.2.1 LPPL License By http://www.layui.com/admin/ */
;layui.define(["table", "form", "element"], function (e) {
    var t = layui.$, i = layui.table, o = (layui.form, layui.element);
    i.render({
        elem: "#agency-repository",
        url: layui.setter.base + "json/agency-repository/demo.js",
        toolbar: "#table-toolbar",
        title: "山西交通控股集团有限公司入围招标代理机构负责人联系表",
        cols: [[
            {
                field: "unique", width: 100, title: "ID", hide: true
            }, {
                field: "number", width: 100, title: "序号", sort: !0
            }, {
                field: "companyName",
                title: "单位名称",
                sort: !1
            }, {
                field: "contact", width: 100, title: "联系人"
            }, {
                field: "gender", width: 100, title: "性别"
            }, {
                field: "post",
                width: 200,
                title: "职务"
            }, {
                field: "phone", width: 200, title: "手机号"
            }, {
                title: "操作",
                align: "center",
                width: 120,
                fixed: "right",
                toolbar: "#table-system-order"
            }]]
        , defaultToolbar: ['print', 'exports'],
        page: !0,
        limit: 20,
        /*        limits: [10, 15, 20, 25, 30],*/
        text: "对不起，加载出现异常！",
        done: function () {
            o.render("progress");
        }
    }), i.on("toolbar(agency-repository)", function (e) {
        var t = i.checkStatus(e.config.id);
        switch (e.event) {
            case"addnew":
                t.data;
                layer.open({
                    type: 2,
                    title: "新增代理机构",
                    content: "/loginagencyedit.html",
                    area: ["550px", "450px"],
                    btn: ["确定", "取消"],
                    yes: function (e, t) {
                        var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                            n = t.find("iframe").contents().find("#" + r);
                        o.layui.form.on("submit(" + r + ")", function (t) {
                            t.field;
                            i.reload("LAY-user-front-submit"), layer.close(e)
                        }), n.trigger("click")
                    },
                    success: function (e, t) {

                    }
                });
                break;
            case "import":
                var import_index = layer.open({
                    type: 2,
                    title: "从Excel文件导入数据",
                    content: "/loginagencyimport.html",
                    area: ["550px", "350px"],
                    resize: false,
                    scrollbar: false,
                    btn: ["导入", "取消"],
                    yes: function (e, t) {
                        var $ = layui.$;
                        // 获取绑定的数据
                        var upload = layui.sessionData("upload");
                        if (!upload.fileId) {
                            return;
                        }
                        var load_index = layer.load(0, {
                            content: "导入中……",
                            end: function () {
                                layer.close(import_index);
                            }
                        });
                        $.post("/fileInfo/importFile", {fileId: upload.fileId}, function (result) {
                            layer.close(load_index);
                            layer.alert(result.msg);
                        });
                        // 清除绑定的数据
                        layui.sessionData("upload", null);
                    },
                    success: function () {

                    }
                });
                break;
        }
    }), i.on("tool(agency-repository)", function (e) {
        e.data;
        if ("edit" === e.event) {
            t(e.tr);
            layer.open({
                type: 2,
                title: "编辑代理机构",
                content: "/loginagencyedit.html",
                area: ["550px", "450px"],
                btn: ["确定", "取消"],
                yes: function (e, t) {
                    var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                        n = t.find("iframe").contents().find("#" + r);
                    o.layui.form.on("submit(" + r + ")", function (t) {

                        t.field;

                        alert("edit。。");

                        i.reload("LAY-user-front-submit"), layer.close(e)

                    }), n.trigger("click");
                },
                success: function (e, t) {
                }
            })
        } else "del" === e.event && layer.confirm("确定要删除该代理机构吗？", function (t) {
            alert('del。。');
            //先删除成功之后，才能提示；
            e.del(), layer.msg("删除成功"), layer.close(t);
        })
    }), e("agency-repository", {})
});