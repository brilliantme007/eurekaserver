/**
 * Created by yx on 2018/12/26.
 */
/** layuiAdmin.std-v1.2.1 LPPL License By http://www.layui.com/admin/ */
;layui.define(["table", "form", "element", "ajaxSetting"], function (e) {
    var t = layui.$, i = layui.table, o = (layui.form, layui.element);
    var jQuery;
    layui.use(['jquery'], function () {
        $ = layui.jquery;
        jQuery = $;
    });
    var fixSex = function () {
        $("[data-field = 'fsex']").children().each(function () {
            if ($(this).text() == '0') {
                $(this).text('女');
            } else if ($(this).text() == '1') {
                $(this).text('男');
            }
        });
    };
    i.render({
        elem: "#agency-repository",
        url: "/agencyList.html",
        method: "post",
        toolbar: "#table-toolbar",
        title: "山西交通控股集团有限公司入围招标代理机构负责人联系表",
        cols: [[
            {
                field: "fid", width: 100, title: "ID", hide: true
            }, {
                field: "findex", width: 70, title: "序号", sort: !0
            }, {
                field: "fepname",
                width: 140,
                title: "单位名称",
                sort: !1
            }, {
                field: "flinkman", width: 100, title: "联系人"
            }, {
                field: "fsex", width: 60, title: "性别"
            }, {
                field: "fduty",
                width: 120,
                title: "职务"
            }, {
                field: "fphone", width: 120, title: "手机号"
            }, {
                field: "fscc", width: 120, title: "社会信用代码"
            }, {
                field: "faddress", width: 280, title: "办公地址"
            }, {
                title: "操作",
                align: "center",
                width: 120,
                fixed: "right",
                toolbar: "#table-system-order"
            }]]
        , defaultToolbar: ['print', 'exports'],
        page: !0,
        limit: 20,
        /*        limits: [10, 15, 20, 25, 30],*/
        text: {
            none: '暂无数据', //默认：无数据。注：该属性为 layui 2.2.5 开始新增
        },
        done: function (res, page, count) {
            fixSex();
            o.render("progress");
        }
    }), i.on("sort(agency-repository)", function () {
        fixSex();
    }), i.on("toolbar(agency-repository)", function (e) {
        var t = i.checkStatus(e.config.id);
        switch (e.event) {
            case"addnew":
                layer.open({
                    type: 2,
                    title: "新增代理机构",
                    content: "/agencyAddOrEdit.html",
                    area: ["550px", "450px"],
                    btn: ["确定", "取消"],
                    yes: function (e, t) {
                        var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                            n = t.find("iframe").contents().find("#" + r);
                        o.layui.form.on("submit(" + r + ")", function (t) {
                            jQuery.ajax({
                                url: "/saveAgency.html",
                                type: "post",
                                data: t.field,
                                success: function (info) {
                                    if (info.code == '00') {
                                        layer.msg(info.msg);
                                        i.reload("LAY-user-front-submit"), layer.close(e);
                                        i.reload('agency-repository');
                                    } else {
                                        layer.msg(info.msg);
                                    }
                                }
                            });
                        }), n.trigger("click")
                    },
                    success: function (e, t) {
                    }
                });
                break;
            case "import":
                var import_index = layer.open({
                    type: 2,
                    title: "从Excel文件导入数据",
                    content: "/agencyImport.html",
                    area: ["550px", "350px"],
                    resize: false,
                    scrollbar: false,
                    btn: ["导入", "取消"],
                    yes: function (e, t) {
                        var $ = layui.$;
                        // 获取绑定的数据
                        var upload = layui.sessionData("upload");
                        if (!upload.fileId) {
                            return;
                        }
                        var load_index = layer.load(0, {
                            content: "导入中……",
                            end: function () {
                                layer.close(import_index);
                            }
                        });
                        $.post("/fileInfo/importFile", {fileId: upload.fileId}, function (result) {
                            layer.close(load_index);
                            if (result.code == "0") {
                                layer.alert(result.msg, {icon: 1});
                                i.reload('agency-repository');
                            } else {
                                layer.alert(result.msg, {icon: 2});
                            }
                        });
                        // 清除绑定的数据
                        layui.sessionData("upload", null);
                    },
                    btn2: function () {
                        // 清除绑定的数据
                        layui.sessionData("upload", null);
                    },
                    cancel: function () {
                        // 清除绑定的数据
                        layui.sessionData("upload", null);
                    },
                    success: function () {

                    }
                });
                break;
        }
    }), i.on("tool(agency-repository)", function (e) {
        if ("edit" === e.event) {
            layer.open({
                type: 2,
                title: "编辑代理机构",
                content: "/agencyAddOrEdit.html?fid=" + e.data.fid,
                area: ["550px", "450px"],
                btn: ["确定", "取消"],
                yes: function (e, t) {
                    var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                        n = t.find("iframe").contents().find("#" + r);
                    o.layui.form.on("submit(" + r + ")", function (t) {
                        jQuery.ajax({
                            url: "/saveAgency.html",
                            type: "post",
                            data: t.field,
                            success: function (info) {
                                if (info.code == '00') {
                                    layer.msg(info.msg),
                                        layer.close(e);
                                    i.reload('agency-repository');
                                } else {
                                    layer.msg(info.msg);
                                }
                            }
                        });

                    }), n.trigger("click");
                },
                success: function (e, t) {
                }
            })
        } else "del" === e.event && layer.confirm("确定要删除该代理机构吗？", function (t) {
            $.post('/deleteAgency.html', {fid: e.data.fid}, function (result) {
                if (result.code == 0) {
                    e.del(),
                        layer.msg(result.msg),
                        layer.close(t);
                } else {
                    layer.msg(result.msg)
                }
            });
        })
    }), e("agency", {})
});