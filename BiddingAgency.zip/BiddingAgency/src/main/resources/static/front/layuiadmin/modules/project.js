/** layuiAdmin.std-v1.2.1 LPPL License By http://www.layui.com/admin/ */
;layui.define(["table", "form", "element", "datefmt", "ajaxSetting"], function (e) {
  var $ = layui.$, i = layui.table, o = (layui.form, layui.element), fmt = layui.datefmt;
  i.render({
    elem: "#project",
    url: "/project/listdata",
    method: 'post',
    /*request: {
      pageName: 'page' //页码的参数名称，默认：page
      ,limitName: 'size' //每页数据量的参数名，默认：limit
    },*/
    toolbar: "#table-toolbar",
    title: "山西交通控股集团有限公司项目表",
    cols: [[
      {type:'checkbox'},
      {
        field: "fid", hide: true
      }, {
        field: "number", width: 100, title: "序号", type: 'numbers'
      }, {
        field: "fprojname", title: "项目名称", sort: true
      }, {
        field: "bidType", width: 100, title: "招采类型", sort: true
      }, {
        field: "isExtracted", width: 120, title: "是否已抽取", sort: true
      }, {
        title: "操作",
        align: "center",
        width: 260,
        fixed: "right",
        toolbar: "#table-system-order"
      }]],
    defaultToolbar: ['print', 'exports'],
    page: !0,
    limit: 10,
    limits: [10, 15, 20, 25, 30],
    text: {
      none: '暂无数据', //默认：无数据。注：该属性为 layui 2.2.5 开始新增
    },
    done: function () {
      o.render("progress");
    }
  }), i.on("toolbar(project)", function (e) {
    var t = i.checkStatus(e.config.id);
    switch (e.event) {
      case"addnew":
        t.data;
        layer.open({
          type: 2,
          title: "新增项目",
          content: "/project/edit.html",
          area: ["550px", "450px"],
          btn: ["确定", "取消"],
          yes: function (e, t) {
            var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
                n = t.find("iframe").contents().find("#" + r);
            o.layui.form.on("submit(" + r + ")", function (t) {
              $.post("/project/save", t.field, function (result) {
                if (result.code !== 0) {
                  layer.msg(result.msg);
                } else {
                  i.reload("project", {
                    where: {
                      "projectName": $('[name="projectName"]').val(),
                      "bidType": $('[name="bidType"]').val()
                    },
                    page: {
                      curr: 1
                    }
                  });
                }
                layer.close(e);
              });
            }), n.trigger("click")
          },
          success: function (e, t) {

          }
        });
        break;
      case"batchextract":
        var j;
        for (j = 0; j < t.data.length && t.data[j].bidType === '非招标'; j++) {}
        if (j < t.data.length) {
          layer.msg("选中行招采类型必须为非招标");
        } else {
          if (t.data.length > 1) {
            var fids = t.data[0].fid;
            for (var k = 1; k < t.data.length; k++) {
              fids += (',' + t.data[k].fid);
            }
            $("#batchExtractA").attr("lay-href", "/project/extractionAgent.html?fid=" + fids);
            $("#batchExtractA").click();
          } else {
           layer.msg("集中抽取需要选择两行或两行以上");
          }
        }
        break;
    }
  }), i.on("tool(project)", function (e) {
    e.data;
    if ("edit" === e.event) {
      $(e.tr);
      layer.open({
        type: 2,
        title: "编辑项目",
        content: "/project/edit.html?fid=" + e.data.fid,
        area: ["550px", "450px"],
        btn: ["确定", "取消"],
        yes: function (e, t) {
          var o = window["layui-layer-iframe" + e], r = "LAY-app-workorder-submit",
              n = t.find("iframe").contents().find("#" + r);
          o.layui.form.on("submit(" + r + ")", function (t) {
            $.post("/project/save", t.field, function (result) {
              if (result.code !== 0) {
                layer.msg(result.msg);
              } else {
                i.reload("project", {
                  where: {
                    "projectName": $('[name="projectName"]').val(),
                    "bidType": $('[name="bidType"]').val()
                  },
                  page: {
                    curr: 1
                  }
                });
              }
              layer.close(e);
            });
          }), n.trigger("click");
        },
        success: function (e, t) {
        }
      })
    } else if ("del" === e.event) {
      var fid = e.data.fid;
      layer.confirm("确定要删除该项目吗？", function (t) {
        $.post("/project/check", {ids: fid}, function (result) {
          if (result.code === 0 && !result.data) {
            $.post("/project/delete", {"ids": fid}, function (result) {
              if (result.code === 0) {
                //先删除成功之后，才能提示；
                e.del(), layer.msg("删除成功！"), layer.close(t);
                i.reload("project", {
                  where: {
                    "projectName": $('[name="projectName"]').val(),
                    "bidType": $('[name="bidType"]').val()
                  },
                  page: {
                    curr: 1
                  }
                });
              } else {
                //删除失败
                layer.msg("删除失败，请稍后再试！"), layer.close(t);
              }
            });
          } else {
            layer.msg("选择的项目关联了抽取结果，无法删除！"), layer.close(t);
          }
        });
      })
    } else if ("extract" === e.event) {
      var fid = e.data.fid;
      $("#extractA").attr("lay-href", "/project/extractionAgent.html?fid=" + fid);
      $("#extractA").click();
    } else if ("pointextract" === e.event) {
      console.log(e.data);
      if (e.data.bidType !== '公开招标') {
        layer.msg("只有公开招标才能指定");
      } else {
        var fid = e.data.fid;
        $("#pointExtractA").attr("lay-href", "/project/extractionAgent.html?assign=1&fid=" + fid);
        $("#pointExtractA").click();
      }
    }
  }), e("project", {})
});