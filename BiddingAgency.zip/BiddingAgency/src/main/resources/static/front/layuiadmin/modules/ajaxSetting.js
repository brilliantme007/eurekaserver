//需要jquery
;layui.define(function (exports) {
    var token = layui.$("meta[name='_csrf']").attr("content");
    var header = layui.$("meta[name='_csrf_header']").attr("content");
    layui.$(document).ajaxSend(function(e, xhr, options) {
        if(header && token) xhr.setRequestHeader(header, token);
    });
    layui.$(document).ajaxComplete(function(event,request,settings){
        var redirect;
        if((redirect = request.getResponseHeader('REDIRECT'))){    //收到重定向指令
            window.location.href = redirect;
        }
    });
    exports('ajaxSetting', {});
});