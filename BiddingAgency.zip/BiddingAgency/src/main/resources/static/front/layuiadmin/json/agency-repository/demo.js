{
  "code": 0
  ,"msg": ""
  ,"count": "12"
  ,"data": [
  {
      "unique": "Q1Q1"
      ,"number": 1
    ,"companyName": "中国中交建设工程咨询有限公司"
    ,"contact": "袁希一"
    ,"gender": "男"
    ,"post": "办事处负责人"
    ,"phone": "18610323802"
  },
  {
      "unique": "Q1Q1"
      ,"number": 2
    ,"companyName": "中大国信工程管理有限公司"
    ,"contact": "段力"
    ,"gender": "女"
    ,"post": "山西办事处负责人"
    ,"phone": "13803468298"
  },
  {"unique": "Q1Q1"
      ,"number": 3
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 4
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 5
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 6
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 7
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 8
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 9
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 10
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 11
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  },
  {"unique": "Q1Q1"
      ,"number": 12
    ,"companyName": "北京中昌工程咨询有限公司"
    ,"contact": "李香真"
    ,"gender": "女"
    ,"post": "项目负责人"
    ,"phone": "18535118003"
  }
  ]
}