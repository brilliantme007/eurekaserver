
$("#powerSearch").click(function () {
    $("#popSearch").slideToggle(300)
});
$("#subSearch").click(function () {
    $("#popSearch").slideUp(300);
});
$(function () {
    //tab警示图标
    $(".tab-warning").prepend('<i class="page-tabs-icon am-icon-info-circle"></i>')
});

$(function () {
    //控制footer位置
    var docHeight = $("body").height(),
        winHeight = $(window).height();
    //console.log(`文档高度：${docHeight}。。。。窗口高度：${winHeight}`);

    if(winHeight>docHeight){
        $("body,html").css({
           "height":"100%"
        });
        $(".footer").css({
            "position":"absolute",
            "bottom":0,
            "width":"100%"
        })
    }else {
        $(".footer").css({
            "position":"relative"
        })
    }

    //子菜单激活显示
    $(".sub-active").parents("ul").show();

    //右侧容器高度
    $('.tpl-content-wrapper').height(winHeight - 100).css({
        'overflow':'auto'
    })

});


// 侧边菜单开关
$('.menu-toggle').on('click', function () {
    if ($('.left-sidebar').hasClass('active')) {
        $('.tpl-content-wrapper').removeClass('active');
        $('.left-sidebar').removeClass('active');
        $('.header').removeClass('active');
        $(this).removeClass("icon-shink-20").addClass("icon-weibiaoti26")
    } else {
        $('.left-sidebar').addClass('active');
        $('.tpl-content-wrapper').addClass('active');
        $('.header').addClass('active');
        $(this).removeClass("icon-weibiaoti26").addClass("icon-shink-20")
    }
});





// 侧边菜单
$('.sidebar-nav-sub-title').on('click', function () {
    $('.sidebar-nav-sub').slideUp(80)
        .end()
        .find('.sidebar-nav-sub-ico').removeClass('sidebar-nav-sub-ico-rotate');
    var nextSub = $(this).next('.sidebar-nav-sub');
    if (nextSub.is(':hidden')) {
        nextSub.slideToggle(80)
            .end()
            .find('.sidebar-nav-sub-ico').toggleClass('sidebar-nav-sub-ico-rotate');
    }
});
//计算leftside高度
var headerHight = $(".header").height();
var leftHeight = $(document).height() - headerHight;
$(".left-sidebar").height(leftHeight);

//计算menu高度
var windowHeight = $(window).height();
$(".left-sidebar").height(windowHeight - headerHight );

//计算地区码表的高 row-left
var containerFluidHeight = $(".container-fluid").height();
var rowContentHeight = windowHeight - headerHight - containerFluidHeight-80;
$(".row-left").height(rowContentHeight);
var areaCodeHeadHeight = $(".areaCode-head").height();
$(".areaCode-body").height(rowContentHeight-areaCodeHeadHeight-22);

// 地区码表展开
//$(".areaCode-body .sidebar-nav").find("li:eq(0)").addClass("active").next("li").css("margin-top","10px");
$('.areaCode-body > .sidebar-nav > .sidebar-nav-link > .areaCode-plus').on('click', function () {
    $('.areaCode-ul').slideUp(80);
    $('.iconfont.areaCode-plus').removeClass("am-icon-minus-square-o").addClass("am-icon-plus-square-o");
    var nextSub = $(this).siblings('.areaCode-ul');
    if(nextSub.is(':hidden')){
        nextSub.slideToggle(80);
        $(this).removeClass("am-icon-plus-square-o").addClass("am-icon-minus-square-o");
    }else{
        $(this).removeClass("am-icon-minus-square-o").addClass("am-icon-plus-square-o");
    }
});
$(".sidebar-nav-sub > .sidebar-nav-link > a").on('click',function () {
    $(".sidebar-nav-sub > .sidebar-nav-link > a").removeClass("active");
    $(this).addClass("active");
});


$(function () {
    //table foot 单元格合并
    $(".tfoot-outer").each(function () {
        var th_length = $(this).parents("table").find("thead > tr > td").length;
        $(this).attr("colspan", th_length);
    });
    //计算leftside高度
    var headerHight = $(".header").height();
    var leftHeight = $(document).height() - headerHight;
    $(".left-sidebar").height(leftHeight);

    //计算menu高度
    var windowHeight = $(window).height();
    $(".left-sidebar").height(windowHeight - headerHight );
    /*$("#leftMenuBox").sticky({
        top: 70,
        theme:"light-thick"
    });*/


    //右下浮动
    var blockSidebar = "<div class='block-sidebar'><a href='javascript:void(0)' class='gotop'><i class='iconfont icon-top'></i></a></div>";
    $(blockSidebar).appendTo("body");
    $(window).scroll(function (e) {
        var scrollTop = $(window).scrollTop();
        if (scrollTop > 200) {
            $(".block-sidebar").fadeIn();
        } else {
            $(".block-sidebar").fadeOut();
        }
    });
    $(document).on('click', ".gotop",function () {
        $("body,html").animate({"scrollTop": 0})
    });

    //table横向滚动条
    if($(".table-body.mCustomScrollbar").length > 0){
        $(".table-body").mCustomScrollbar({
            axis: "x",
            autoExpandScrollbar: true,
            advanced: {autoExpandHorizontalScroll: true}
        });
    }

    //角色选择
    $(".info-wrap-role input").on('click', function () {
        var icheck = '<i class="checked"></i>';
        if ($(this).is(':checked')) {
            //加入勾选样式
            $(".info-wrap-role label").removeClass("active-label").find("i.checked").remove();
            $(this).prev('label').addClass("active-label").prepend(icheck);

            //点击非会员显示地区
            if (!$('#sccin_member').is(':checked')) {
                $('.area-hide').slideDown();
            } else {
                $('.area-hide').slideUp();
            }

        } else {
            return false;
        }
    });


    //步骤
    $(".step-bar.active").prevUntil().addClass("complate");
    var stepItem = $(".step-wrap .step-bar");
    var stepsNumber = stepItem.length;
    stepItem.width(100 / stepsNumber + "%");
    stepItem.each(function (e) {
        var index=$(this).index();
        $(this).find(".step-point").text(index + 1);
    })

});


//table 宽度拖动
function widthDrag() {
    var tTD; //用来存储当前更改宽度的Table Cell,避免快速移动鼠标的问题
    var table = document.getElementById("widthDragable");
    for (j = 0; j < table.rows[0].cells.length; j++) {
        table.rows[0].cells[j].onmousedown = function () {
//记录单元格
            tTD = this;
            if (event.offsetX > tTD.offsetWidth - 10) {
                tTD.mouseDown = true;
                tTD.oldX = event.x;
                tTD.oldWidth = tTD.offsetWidth;
            }
//记录Table宽度
//table = tTD; while (table.tagName != ‘TABLE') table = table.parentElement;
//tTD.tableWidth = table.offsetWidth;
        };
        table.rows[0].cells[j].onmouseup = function () {
//结束宽度调整
            if (tTD == undefined) tTD = this;
            tTD.mouseDown = false;
            tTD.style.cursor = 'default';
        };
        table.rows[0].cells[j].onmousemove = function (element) {

//更改鼠标样式
            if (event.offsetX > this.offsetWidth - 10)
                this.style.cursor = 'col-resize';
            else
                this.style.cursor = 'default';
//取出暂存的Table Cell
            if (tTD == undefined) tTD = this;
//调整宽度
            if (tTD.mouseDown != null && tTD.mouseDown == true) {
                tTD.style.cursor = 'default';
                if (tTD.oldWidth + (event.x - tTD.oldX) > 0)
                    tTD.width = tTD.oldWidth + (event.x - tTD.oldX);
//调整列宽
                tTD.style.width = tTD.width;
                tTD.style.cursor = 'col-resize';
//调整该列中的每个Cell

                table = tTD;
                while (table.tagName != 'TABLE') table = table.parentElement;
                for (j = 0; j < table.rows.length; j++) {
                    table.rows[j].cells[tTD.cellIndex].width = tTD.width;
                }
//调整整个表
//table.width = tTD.tableWidth + (tTD.offsetWidth – tTD.oldWidth);
//table.style.width = table.width;
            }
        };
    }
}
$(function () {
    if($("#widthDragable").length>0){
        widthDrag();
    }

});



/*var tabHeight=function () {
    var $win_w = $(window).width();
    var $tabs = $(".page-tabs-controler-wrap a");
        if($win_w<1351){
            $tabs.each(function () {
                $(this).css({
                    height:"50px",
                    width:"10%"
                });
            });
        }else {
            $tabs.each(function () {
                $(this).css({
                    height:"30px",
                    width:"auto"
                });
            });
        }
    };
$(window).resize(function () {
    tabHeight()
})*/


//滚动插件
;(function($, window, document,undefined) {
    //定义Beautifier的构造函数
    var Beautifier = function(ele, opt) {
        this.$element = ele,
        this.defaults = {
            'interval': 3000, //间隔
            'height': 24, //高度
            "controler":false
        },
        this.options = $.extend({}, this.defaults, opt);
    };
    //定义Beautifier的方法
    Beautifier.prototype = {
        beautify: function() {
            var $ele = this.$element,
                $opt = this.options;
            $ele.height($opt.height+"px");


            //执行滚动
            var funcSlidUp = function () {
                var $ul = $ele.find("ul"),
                    $li = $ul.find("li");
                $ul.css({
                    "position":"relative"
                });
                console.log("up");
                $ul.animate({
                    "top":"-"+$opt.height+"px"
                },function () {
                    //滚动完毕则把第一个li添加到最后面，并且把ui的top设置0
                    $li.eq(0).appendTo($ul);
                    $ul.css({"top":0})
                });
            };
            var funcSlidDown = function () {
                var $ul = $ele.find("ul"),
                    $li = $ul.find("li");
                $ul.css({
                    "position":"relative"
                });
                console.log("down");
                $li.eq(-1).prependTo($ul);
                $ul.css({"top":-$opt.height+"px"});
                $ul.animate({
                    "top":0
                });
            };

            var interVal = setInterval(funcSlidUp,$opt.interval);
            $ele.on("mouseenter",function (e) {
                clearInterval(interVal);
            }).on("mouseleave",function (e) {
                interVal = setInterval(funcSlidUp,$opt.interval);
            });

            if($opt.controler){
                $ele.append("<div class='controler'><a href='javascript:void(0)' class='up am-icon-angle-up'></a><a href='javascript:void(0)' class='down am-icon-angle-down'></a></div>");
                var $up=$ele.find(".up"),
                    $down=$ele.find(".down");
                $up.on('click',function (e) {
                    funcSlidUp()
                });
                $down.on('click',function (e) {
                    funcSlidDown()
                })
            }
        }
    };
    //在插件中使用Beautifier对象
    $.fn.linkSlider = function(options) {
        //创建Beautifier的实体
        var beautifier = new Beautifier(this, options);
        //调用其方法
        return beautifier.beautify();
    }


})(jQuery, window, document);

//打印
//myDiv为需要打印的元素ID
function printpage(myDiv){
    //隐藏按钮
    $(myDiv).find('.am-btn').hide();
    //获取打印区域代码
    var newstr = $(myDiv).html();
    var oldstr = $('body').html();

    $('body').html(newstr);
    window.print();

    $(document).find('body').html(oldstr);
    $(myDiv).find('.am-btn').show();
    return false;

}

$('#printBtn').on({
    click:function () {
        printpage('#needprint')
    }
});

//倒计时
var interval = 1000;
function ShowCountDown(divname,endyear,endmonth,endday,endhour,endminute,endsecend){
    if(!document.getElementById(divname)) return false;
    var now = new Date();
    var seconds = 1000;
    var minutes = seconds*60;
    var hours = minutes*60;
    var days = hours*24;
    var years = days*365;

    //获取终止时间距离1970 年 1 月 1的毫秒数
    var endTime = new Date(endyear, endmonth-1, endday).getTime()+endhour*hours+endminute*minutes+endsecend*seconds;
    var leftTime=endTime-now.getTime();
    var leftsecond = parseInt(leftTime/1000);
    var leftdays=Math.floor(leftsecond/(60*60*24));
    var lefthours=Math.floor((leftsecond-leftdays*24*60*60)/3600);
    var leftminutes=Math.floor((leftsecond-leftdays*24*60*60-lefthours*3600)/60);
    var leftseconds=Math.floor(leftsecond-leftdays*24*60*60-lefthours*3600-leftminutes*60);
    var cc = document.getElementById(divname);
    cc.innerHTML = "<b>"+leftdays+"</b> 天 <b>"+lefthours+"</b> 时 <b>"+leftminutes+"</b> 分 <b>"+leftseconds+"</b> 秒"
    if(leftTime<0){
        cc.innerHTML = "<b>开始了</b>";
        document.getElementsByClassName("videobox")[0].style.display='block';
        document.getElementsByClassName("hourglass-wrap")[0].style.display='none';
    }
}

//模拟时间为10秒后
var now = new Date(),
    endyear = now.getFullYear(),
    endmonth = now.getMonth()+1,
    endday = now.getDate(),
    endhour = now.getHours(),
    endminute = now.getMinutes(),
    endsecend = now.getSeconds();
window.setInterval(function(){ShowCountDown('CountDown',endyear,endmonth,endday,endhour,endminute,endsecend+10);}, interval);//设置终止年月日时分秒


//档案管理背景高度
$(".file-showbox").height($(window).height()-200);

//档案管理子菜单收缩
$(".file-catalog-wrap .level-1").on('click',function(){
    $(this).next(".submenu").slideToggle();
    $(this).toggleClass("open")
});

$(function () {
    $("li.active").parents(".submenu").show().prev().addClass("open");
});







