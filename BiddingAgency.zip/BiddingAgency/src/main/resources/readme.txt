application.properties 通常用于框架中通用配置；
defineSys.properties 本系统特定用到的一些配置；

每个配置文件中，单行配置项上都有特定注释，有不明白的及时询问；

============application.properties===================
proj.sys.define.projName                                         项目在页签上呈现的名称；

spring.jpa.show-sql                                              日志记录是否记录执行SQL，在正式使用时设置为false;
                                                                 将该值设为false之后也要将logback.xml中以下部分注释掉 注释标记没<!-- 内容区-->
<logger name="org.hibernate.type.descriptor.sql.BasicBinder" level="TRACE" />
<logger name="org.hibernate.type.descriptor.sql.BasicExtractor" level="TRACE" />
<logger name="org.hibernate.SQL" level="DEBUG" />
<logger name="org.hibernate.engine.QueryParameters" level="DEBUG" />
<logger name="org.hibernate.engine.query.HQLQueryPlan" level="DEBUG" />
                                                                  日志文件的使用必须在logback.xml中以下字串中设定绝对路径
<property name="LOG_PATH" value="H:/testLog" />


proj.sys.define.versionNo=1.0.0.1                                 版本号

spring.datasource.*相关配置                                        数据库相关配置；


============application.properties===================

============defineSys.properties===================
proj.sys.define.thridURL=http://192.168.0.218:7070/UserService.svc?wsdl   用户体系提供的WSDL
proj.sys.define.soapHeadUserName=sccin_ZJJS                               接口调用约定的用户名
proj.sys.define.soapHeadPassWord=1234qwerfdsa                             接口调用约定的密码
proj.sys.define.thirdUserName=OperationUserName                           约定值（现阶段不会变更）
proj.sys.define.thirdPassWord=OperationPwd                                约定值（现阶段不会变更）

proj.sys.define.ulifyLoginDomain=http://192.168.1.85:6000                 用户体系统一身份认证主域名
proj.sys.define.ulifySystemid=2c7cfb52-e16d-4581-b18a-38dbaa091070        视频监控系统在用户体系中系统唯一标识
proj.sys.define.ulifyAreaid=510600                                        系统所在的地区；


============defineSys.properties===================